#!/usr/bin/env python3
"""
DataPresenter Complete - Launch Script
"""
import os
import sys
import subprocess
import time
import webbrowser
from pathlib import Path

def check_python_version():
    if sys.version_info < (3, 8):
        print("❌ Python 3.8+ required.")
        return False
    print(f"✅ Python {sys.version.split()[0]} detected")
    return True

def install_dependencies():
    print("📦 Installing dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Dependencies installed")
        return True
    except subprocess.CalledProcessError:
        print("❌ Failed to install dependencies")
        return False

def create_directories():
    directories = ['static', 'temp', 'uploads', 'charts']
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
    print("✅ Directories created")

def start_server():
    print("\n🚀 Starting DataPresenter Complete...")
    print("🌐 Server: http://localhost:8000")

    def open_browser():
        time.sleep(3)
        try:
            webbrowser.open("http://localhost:8000")
            print("🌐 Browser opened")
        except:
            print("🌐 Please open http://localhost:8000")

    import threading
    browser_thread = threading.Thread(target=open_browser)
    browser_thread.daemon = True
    browser_thread.start()

    try:
        subprocess.run([sys.executable, "main.py"])
    except KeyboardInterrupt:
        print("\n🛑 Server stopped")

def main():
    print("=" * 60)
    print("📊 DATAPRESENTER COMPLETE SYSTEM 📊")
    print("=" * 60)

    if not check_python_version():
        return

    create_directories()

    if not install_dependencies():
        return

    start_server()

if __name__ == "__main__":
    main()
