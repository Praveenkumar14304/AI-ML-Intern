// Enhanced DataPresenter Multi-Select Application JavaScript

// Application State Management
class AppState {
    constructor() {
        this.currentTab = 'upload';
        this.sessionId = null;
        this.uploadedFile = null;
        this.processedData = null;
        this.selectedColumns = new Set();
        this.selectedAnalysisTypes = new Set();
        this.chartConfigurations = {
            dashboard: [],
            insights_only: { columns: [] },
            plus_charts: [],
            comparison: { xAxis: '', yAxis: '', chartType: 'scatter' }
        };
        this.customSettings = {
            title: '',
            companyName: '',
            template: 'modern_blue'
        };
        this.llmQuery = '';
        this.generatedPresentation = null;
        this.chartInstances = new Map();
    }

    // Update state and trigger relevant UI updates
    updateState(key, value) {
        this[key] = value;
        this.notifyStateChange(key, value);
    }

    // Notify components of state changes
    notifyStateChange(key, value) {
        document.dispatchEvent(new CustomEvent('stateChange', {
            detail: { key, value }
        }));
    }
}

// Global application instance
const app = new AppState();

// API Service for backend communication
class APIService {
    constructor(baseURL = '') {
        this.baseURL = baseURL;
    }

    async uploadFile(file) {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch(`${this.baseURL}/api/upload`, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`Upload failed: ${response.statusText}`);
        }

        return await response.json();
    }

    async updateSelectedColumns(sessionId, selectedColumns) {
        const response = await fetch(`${this.baseURL}/api/update-selected-columns`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                sessionId,
                selectedColumns: Array.from(selectedColumns)
            })
        });

        if (!response.ok) {
            throw new Error(`Failed to update columns: ${response.statusText}`);
        }

        return await response.json();
    }

    async updateMultiSelectAnalysis(sessionId, selectedAnalysisTypes, chartConfigurations, customSettings, llmQuery) {
        const response = await fetch(`${this.baseURL}/api/update-multi-select-analysis`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                sessionId,
                selectedAnalysisTypes: Array.from(selectedAnalysisTypes),
                chartConfigurations,
                customSettings,
                llmQuery
            })
        });

        if (!response.ok) {
            throw new Error(`Failed to update analysis: ${response.statusText}`);
        }

        return await response.json();
    }

    async generatePresentation(sessionId, selectedAnalysisTypes, chartConfigurations, customSettings, llmQuery) {
        const response = await fetch(`${this.baseURL}/api/generate-enhanced-presentation`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                sessionId,
                selectedAnalysisTypes: Array.from(selectedAnalysisTypes),
                chartConfigurations,
                customSettings,
                llmQuery
            })
        });

        if (!response.ok) {
            throw new Error(`Failed to generate presentation: ${response.statusText}`);
        }

        return await response.json();
    }

    async downloadPresentation(sessionId) {
        const response = await fetch(`${this.baseURL}/api/download/${sessionId}`);

        if (!response.ok) {
            throw new Error(`Download failed: ${response.statusText}`);
        }

        // Create download link
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = 'enhanced_presentation.pptx';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    async getChartPreviewData(sessionId, column) {
        const response = await fetch(`${this.baseURL}/api/chart-preview-data/${sessionId}/${column}`);

        if (!response.ok) {
            throw new Error(`Failed to get chart data: ${response.statusText}`);
        }

        return await response.json();
    }
}

// Create API service instance
const api = new APIService();

// UI Controller for managing interface interactions
class UIController {
    constructor() {
        this.currentSlide = 0;
        this.totalSlides = 8;
        this.initializeEventListeners();
        this.initializeDragAndDrop();
    }

    initializeEventListeners() {
        // Tab navigation
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                this.switchTab(e.target.closest('.nav-tab').dataset.tab);
            });
        });

        // File input
        const fileInput = document.getElementById('fileInput');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                this.handleFileUpload(e.target.files[0]);
            });
        }

        // Analysis type selection
        document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
            if (checkbox.closest('.analysis-type-card')) {
                checkbox.addEventListener('change', (e) => {
                    this.handleAnalysisTypeChange(e.target.value, e.target.checked);
                });
            }
        });

        // Generate presentation button
        const generateBtn = document.getElementById('generatePresentation');
        if (generateBtn) {
            generateBtn.addEventListener('click', () => {
                this.generatePresentation();
            });
        }

        // Slide navigation
        const prevSlideBtn = document.getElementById('prevSlide');
        const nextSlideBtn = document.getElementById('nextSlide');
        if (prevSlideBtn) {
            prevSlideBtn.addEventListener('click', () => this.previousSlide());
        }
        if (nextSlideBtn) {
            nextSlideBtn.addEventListener('click', () => this.nextSlide());
        }

        // Download buttons
        const downloadPPTX = document.getElementById('downloadPPTX');
        if (downloadPPTX) {
            downloadPPTX.addEventListener('click', () => {
                this.downloadPresentation('pptx');
            });
        }

        // Listen for state changes
        document.addEventListener('stateChange', (e) => {
            this.handleStateChange(e.detail.key, e.detail.value);
        });
    }

    initializeDragAndDrop() {
        const uploadArea = document.getElementById('uploadArea');
        if (!uploadArea) return;

        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                this.handleFileUpload(files[0]);
            }
        });
    }

    switchTab(tabName) {
        // Update active tab
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Update active content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(`${tabName}-tab`).classList.add('active');

        app.updateState('currentTab', tabName);
    }

    async handleFileUpload(file) {
        if (!file) return;

        this.showLoading('Uploading and analyzing file...', 'This may take a few moments for large files');

        try {
            const result = await api.uploadFile(file);

            app.updateState('sessionId', result.session_id);
            app.updateState('uploadedFile', file);
            app.updateState('processedData', result);

            this.displayAnalysisResults(result);
            this.updateUploadStatus('success', `${file.name} uploaded successfully`);
            this.hideLoading();

        } catch (error) {
            console.error('Upload error:', error);
            this.showError('Upload failed', error.message);
            this.updateUploadStatus('error', 'Upload failed');
            this.hideLoading();
        }
    }

    displayAnalysisResults(data) {
        // Show analysis results section
        document.getElementById('analysisResults').style.display = 'block';

        // Display dataset metrics
        this.displayDatasetMetrics(data.dataset_metrics);

        // Display columns for selection
        this.displayColumnSelection(data.columns, data.statistical_insights);

        // Display data preview
        this.displayDataPreview(data.preview_data, data.columns);

        // Display statistical insights
        this.displayStatisticalInsights(data.statistical_insights, data.correlations);
    }

    displayDatasetMetrics(metrics) {
        const container = document.getElementById('datasetMetrics');
        if (!container) return;

        container.innerHTML = `
            <div class="metric-item">
                <span class="metric-value">${metrics.total_rows?.toLocaleString() || '0'}</span>
                <div class="metric-label">Total Rows</div>
            </div>
            <div class="metric-item">
                <span class="metric-value">${metrics.total_columns || '0'}</span>
                <div class="metric-label">Total Columns</div>
            </div>
            <div class="metric-item">
                <span class="metric-value">${metrics.completeness?.toFixed(1) || '0'}%</span>
                <div class="metric-label">Data Completeness</div>
            </div>
            <div class="metric-item">
                <span class="metric-value">${metrics.memory_usage || 'N/A'}</span>
                <div class="metric-label">Memory Usage</div>
            </div>
        `;
    }

    displayColumnSelection(columns, insights) {
        const container = document.getElementById('columnGrid');
        if (!container) return;

        container.innerHTML = columns.map(column => {
            const stats = insights?.[column] || {};
            const dataType = stats.data_type || 'unknown';
            const nullPct = stats.null_percentage || 0;

            return `
                <div class="column-item" onclick="this.querySelector('input').click()">
                    <input type="checkbox" value="${column}" onchange="ui.handleColumnSelection('${column}', this.checked)">
                    <div class="column-info">
                        <div class="column-name">${column}</div>
                        <div class="column-type">${dataType} • ${(100-nullPct).toFixed(1)}% complete</div>
                    </div>
                </div>
            `;
        }).join('');
    }

    displayDataPreview(previewData, columns) {
        const thead = document.getElementById('tableHead');
        const tbody = document.getElementById('tableBody');

        if (!thead || !tbody || !previewData || previewData.length === 0) return;

        // Create table headers
        thead.innerHTML = `
            <tr>
                ${columns.map(col => `<th>${col}</th>`).join('')}
            </tr>
        `;

        // Create table rows (show first 10 rows)
        tbody.innerHTML = previewData.slice(0, 10).map(row => `
            <tr>
                ${columns.map(col => `<td>${row[col] || ''}</td>`).join('')}
            </tr>
        `).join('');
    }

    displayStatisticalInsights(insights, correlations) {
        const container = document.getElementById('statisticalInsights');
        if (!container) return;

        let html = '<h5>Key Statistical Findings:</h5>';

        // Display top insights
        Object.entries(insights).slice(0, 5).forEach(([column, stats]) => {
            if (stats.data_type === 'numerical') {
                html += `
                    <div class="insight-item">
                        <strong>${column}</strong>: Mean ${stats.mean?.toFixed(2) || 'N/A'}, 
                        Std Dev ${stats.std_dev?.toFixed(2) || 'N/A'}
                        ${stats.outliers_count > 0 ? `, ${stats.outliers_count} outliers detected` : ''}
                    </div>
                `;
            } else if (stats.data_type === 'categorical') {
                html += `
                    <div class="insight-item">
                        <strong>${column}</strong>: ${stats.unique_count || 'N/A'} categories, 
                        top: "${stats.most_frequent_value || 'N/A'}" 
                        (${(stats.concentration_ratio * 100)?.toFixed(1) || '0'}%)
                    </div>
                `;
            }
        });

        // Display correlations
        if (correlations && Object.keys(correlations).length > 0) {
            html += '<h5>Strong Correlations:</h5>';
            Object.entries(correlations).slice(0, 3).forEach(([pair, corr]) => {
                html += `
                    <div class="insight-item">
                        <strong>${pair}</strong>: ${corr.toFixed(3)} 
                        (${Math.abs(corr) > 0.7 ? 'Strong' : 'Moderate'} 
                        ${corr > 0 ? 'positive' : 'negative'})
                    </div>
                `;
            });
        }

        container.innerHTML = html;
    }

    handleColumnSelection(column, isSelected) {
        const columnItem = document.querySelector(`input[value="${column}"]`).closest('.column-item');

        if (isSelected) {
            app.selectedColumns.add(column);
            columnItem.classList.add('selected');
        } else {
            app.selectedColumns.delete(column);
            columnItem.classList.remove('selected');
        }

        // Update available columns in customization tab
        this.updateAvailableColumns();
    }

    handleAnalysisTypeChange(analysisType, isSelected) {
        const configSection = document.getElementById(`${analysisType}Config`);

        if (isSelected) {
            app.selectedAnalysisTypes.add(analysisType);
            if (configSection) {
                configSection.style.display = 'block';
                configSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        } else {
            app.selectedAnalysisTypes.delete(analysisType);
            if (configSection) {
                configSection.style.display = 'none';
            }
        }

        // Initialize configuration for the analysis type
        this.initializeAnalysisConfig(analysisType, isSelected);
    }

    initializeAnalysisConfig(analysisType, isEnabled) {
        if (!isEnabled) return;

        switch (analysisType) {
            case 'dashboard':
                this.initializeDashboardConfig();
                break;
            case 'insights_only':
                this.initializeInsightsOnlyConfig();
                break;
            case 'plus_charts':
                this.initializePlusChartsConfig();
                break;
            case 'comparison':
                this.initializeComparisonConfig();
                break;
        }
    }

    initializeDashboardConfig() {
        const addBtn = document.getElementById('addDashboardChart');
        if (addBtn) {
            addBtn.onclick = () => this.addDashboardChart();
        }
    }

    initializeInsightsOnlyConfig() {
        const container = document.getElementById('insightsColumnSelection');
        if (!container) return;

        const selectedColumns = Array.from(app.selectedColumns);
        container.innerHTML = selectedColumns.map(column => `
            <label class="column-item">
                <input type="checkbox" value="${column}" onchange="ui.updateInsightsOnlyColumns()">
                <div class="column-info">
                    <div class="column-name">${column}</div>
                    <div class="column-type">Include in statistical analysis</div>
                </div>
            </label>
        `).join('');
    }

    initializePlusChartsConfig() {
        const addBtn = document.getElementById('addPlusChart');
        if (addBtn) {
            addBtn.onclick = () => this.addPlusChart();
        }
    }

    initializeComparisonConfig() {
        const xSelect = document.getElementById('xAxisSelect');
        const ySelect = document.getElementById('yAxisSelect');
        const selectedColumns = Array.from(app.selectedColumns);

        if (xSelect && ySelect) {
            // Populate dropdowns
            const options = selectedColumns.map(col => `<option value="${col}">${col}</option>`).join('');
            xSelect.innerHTML = '<option value="">Select X-axis column</option>' + options;
            ySelect.innerHTML = '<option value="">Select Y-axis column</option>' + options;

            // Add event listeners
            xSelect.onchange = () => this.updateComparisonConfig();
            ySelect.onchange = () => this.updateComparisonConfig();

            const chartTypeSelect = document.getElementById('comparisonChartType');
            if (chartTypeSelect) {
                chartTypeSelect.onchange = () => this.updateComparisonConfig();
            }
        }
    }

    addDashboardChart() {
        const container = document.getElementById('dashboardCharts');
        const chartIndex = app.chartConfigurations.dashboard.length;
        const availableColumns = Array.from(app.selectedColumns);

        if (chartIndex >= 6) {
            this.showError('Limit Reached', 'Maximum 6 charts allowed in dashboard');
            return;
        }

        const chartItem = document.createElement('div');
        chartItem.className = 'dashboard-chart-item';
        chartItem.innerHTML = `
            <select onchange="ui.updateDashboardChart(${chartIndex}, 'column', this.value)">
                <option value="">Select Column</option>
                ${availableColumns.map(col => `<option value="${col}">${col}</option>`).join('')}
            </select>
            <select onchange="ui.updateDashboardChart(${chartIndex}, 'chartType', this.value)">
                <option value="bar">Bar Chart</option>
                <option value="line">Line Chart</option>
                <option value="pie">Pie Chart</option>
                <option value="scatter">Scatter Plot</option>
                <option value="area">Area Chart</option>
                <option value="histogram">Histogram</option>
            </select>
            <input type="text" placeholder="Chart Title" onchange="ui.updateDashboardChart(${chartIndex}, 'title', this.value)">
            <button class="btn btn-secondary" onclick="ui.removeDashboardChart(${chartIndex})">Remove</button>
        `;

        container.appendChild(chartItem);

        // Add empty chart configuration
        app.chartConfigurations.dashboard.push({
            column: '',
            chartType: 'bar',
            title: `Chart ${chartIndex + 1}`
        });
    }

    updateDashboardChart(index, property, value) {
        if (app.chartConfigurations.dashboard[index]) {
            app.chartConfigurations.dashboard[index][property] = value;

            // Update preview if column and chart type are selected
            if (app.chartConfigurations.dashboard[index].column && 
                app.chartConfigurations.dashboard[index].chartType) {
                this.updateDashboardPreview();
            }
        }
    }

    removeDashboardChart(index) {
        const container = document.getElementById('dashboardCharts');
        const chartItems = container.children;

        if (chartItems[index]) {
            chartItems[index].remove();
            app.chartConfigurations.dashboard.splice(index, 1);
            this.updateDashboardPreview();
        }
    }

    updateDashboardPreview() {
        const previewContainer = document.getElementById('dashboardPreview');
        if (!previewContainer) return;

        const validCharts = app.chartConfigurations.dashboard.filter(chart => 
            chart.column && chart.chartType
        );

        if (validCharts.length === 0) {
            previewContainer.innerHTML = '<p>Charts will appear here as you configure them</p>';
            return;
        }

        // Create grid preview
        const gridHtml = `
            <div class="dashboard-grid-preview">
                ${validCharts.map((chart, index) => `
                    <div class="chart-preview-item">
                        <h6>${chart.title || chart.column}</h6>
                        <div class="chart-placeholder">
                            📊 ${chart.chartType} chart of ${chart.column}
                        </div>
                    </div>
                `).join('')}
            </div>
        `;

        previewContainer.innerHTML = gridHtml;
    }

    updateInsightsOnlyColumns() {
        const checkboxes = document.querySelectorAll('#insightsColumnSelection input[type="checkbox"]:checked');
        app.chartConfigurations.insights_only.columns = Array.from(checkboxes).map(cb => cb.value);
    }

    updateComparisonConfig() {
        const xAxis = document.getElementById('xAxisSelect')?.value || '';
        const yAxis = document.getElementById('yAxisSelect')?.value || '';
        const chartType = document.getElementById('comparisonChartType')?.value || 'scatter';

        app.chartConfigurations.comparison = { xAxis, yAxis, chartType };

        // Update Y-axis options to exclude X-axis selection
        const ySelect = document.getElementById('yAxisSelect');
        if (ySelect && xAxis) {
            const selectedColumns = Array.from(app.selectedColumns);
            const availableForY = selectedColumns.filter(col => col !== xAxis);

            const currentY = ySelect.value;
            ySelect.innerHTML = '<option value="">Select Y-axis column</option>' + 
                availableForY.map(col => `<option value="${col}" ${col === currentY ? 'selected' : ''}>${col}</option>`).join('');
        }

        // Update preview if both axes are selected
        if (xAxis && yAxis) {
            this.updateComparisonPreview();
        }
    }

    async updateComparisonPreview() {
        const previewContainer = document.getElementById('comparisonPreview');
        const canvas = document.getElementById('comparisonChart');

        if (!canvas || !app.sessionId) return;

        try {
            // Get chart data from backend
            const xData = await api.getChartPreviewData(app.sessionId, app.chartConfigurations.comparison.xAxis);
            const yData = await api.getChartPreviewData(app.sessionId, app.chartConfigurations.comparison.yAxis);

            // Create chart using Chart.js
            const ctx = canvas.getContext('2d');

            // Destroy existing chart if it exists
            if (app.chartInstances.has('comparison')) {
                app.chartInstances.get('comparison').destroy();
            }

            const chart = new Chart(ctx, {
                type: 'scatter',
                data: {
                    datasets: [{
                        label: `${app.chartConfigurations.comparison.xAxis} vs ${app.chartConfigurations.comparison.yAxis}`,
                        data: xData.chartData?.data?.map((x, i) => ({ x, y: yData.chartData?.data?.[i] || 0 })) || [],
                        backgroundColor: 'rgba(31, 78, 121, 0.6)',
                        borderColor: 'rgba(31, 78, 121, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Comparison Preview'
                        }
                    },
                    scales: {
                        x: {
                            title: {
                                display: true,
                                text: app.chartConfigurations.comparison.xAxis
                            }
                        },
                        y: {
                            title: {
                                display: true,
                                text: app.chartConfigurations.comparison.yAxis
                            }
                        }
                    }
                }
            });

            app.chartInstances.set('comparison', chart);

        } catch (error) {
            console.error('Error updating comparison preview:', error);
            previewContainer.innerHTML = '<p>Error loading preview data</p>';
        }
    }

    updateAvailableColumns() {
        // Update column dropdowns in various configuration sections
        const selectedColumns = Array.from(app.selectedColumns);

        // Update comparison dropdowns
        const xSelect = document.getElementById('xAxisSelect');
        const ySelect = document.getElementById('yAxisSelect');

        if (xSelect && ySelect) {
            const options = selectedColumns.map(col => `<option value="${col}">${col}</option>`).join('');
            const currentX = xSelect.value;
            const currentY = ySelect.value;

            xSelect.innerHTML = '<option value="">Select X-axis column</option>' + options;
            ySelect.innerHTML = '<option value="">Select Y-axis column</option>' + options;

            // Restore selections if still valid
            if (selectedColumns.includes(currentX)) xSelect.value = currentX;
            if (selectedColumns.includes(currentY)) ySelect.value = currentY;
        }
    }

    async generatePresentation() {
        if (!app.sessionId) {
            this.showError('No Data', 'Please upload a file first');
            return;
        }

        if (app.selectedColumns.size === 0) {
            this.showError('No Columns Selected', 'Please select columns for analysis in Tab 1');
            return;
        }

        if (app.selectedAnalysisTypes.size === 0) {
            this.showError('No Analysis Types Selected', 'Please select at least one analysis type');
            return;
        }

        // Collect custom settings
        app.customSettings.title = document.getElementById('presentationTitle')?.value || '';
        app.customSettings.companyName = document.getElementById('companyName')?.value || '';
        app.customSettings.template = document.getElementById('templateSelect')?.value || 'modern_blue';
        app.llmQuery = document.getElementById('llmQuery')?.value || '';

        this.showLoading('Generating Comprehensive Presentation...', 
            'Creating charts, analyzing data, and generating business insights. This may take up to 30 seconds.');

        try {
            // Update backend with selected columns first
            await api.updateSelectedColumns(app.sessionId, app.selectedColumns);

            // Generate presentation
            const result = await api.generatePresentation(
                app.sessionId,
                app.selectedAnalysisTypes,
                app.chartConfigurations,
                app.customSettings,
                app.llmQuery
            );

            app.updateState('generatedPresentation', result);

            // Update preview slides
            this.generateSlidePreview();

            // Show export options
            this.showExportOptions(result);

            // Switch to preview tab
            this.switchTab('preview');

            this.hideLoading();
            this.showSuccess('Presentation Generated!', 'Your comprehensive presentation is ready. Check the Preview tab.');

        } catch (error) {
            console.error('Generation error:', error);
            this.showError('Generation Failed', error.message);
            this.hideLoading();
        }
    }

    generateSlidePreview() {
        const slidesList = document.getElementById('slidesList');
        if (!slidesList) return;

        // Generate slide structure based on selected analysis types
        const slides = [
            { id: 1, title: 'Title Slide', description: 'Presentation title and branding' },
            { id: 2, title: 'Dataset Overview', description: 'Comprehensive statistics' },
            { id: 3, title: 'Selected Columns', description: 'Analysis scope and variables' }
        ];

        let slideId = 4;

        // Add analysis-specific slides
        if (app.selectedAnalysisTypes.has('dashboard')) {
            slides.push({ id: slideId++, title: 'Dashboard Overview', description: 'Multiple charts in grid layout' });
        }

        if (app.selectedAnalysisTypes.has('plus_charts')) {
            const chartCount = app.chartConfigurations.plus_charts.length;
            for (let i = 0; i < chartCount; i++) {
                slides.push({ id: slideId++, title: `Insight ${i + 1}`, description: 'Individual analysis with chart' });
            }
        }

        if (app.selectedAnalysisTypes.has('insights_only')) {
            slides.push({ id: slideId++, title: 'Statistical Insights', description: 'Text-based analysis' });
        }

        if (app.selectedAnalysisTypes.has('comparison')) {
            slides.push({ id: slideId++, title: 'Comparison Analysis', description: 'X vs Y relationship' });
        }

        // Add business insight slides
        slides.push(
            { id: slideId++, title: 'Business Insights', description: 'LLM-generated business context' },
            { id: slideId++, title: 'Key Insights & Actions', description: 'Recommendations and next steps' },
            { id: slideId++, title: 'Conclusion', description: 'Strategic summary' },
            { id: slideId++, title: 'Thank You', description: 'Professional closing' }
        );

        this.totalSlides = slides.length;

        slidesList.innerHTML = slides.map(slide => `
            <div class="slide-item ${slide.id === 1 ? 'active' : ''}" data-slide="${slide.id}" onclick="ui.goToSlide(${slide.id})">
                <div class="slide-thumbnail">${slide.id}</div>
                <div class="slide-info">
                    <h4>${slide.title}</h4>
                    <p>${slide.description}</p>
                </div>
            </div>
        `).join('');

        // Update slide counter
        this.updateSlideCounter();
    }

    goToSlide(slideNumber) {
        this.currentSlide = slideNumber - 1;
        this.updateSlideDisplay();
    }

    previousSlide() {
        if (this.currentSlide > 0) {
            this.currentSlide--;
            this.updateSlideDisplay();
        }
    }

    nextSlide() {
        if (this.currentSlide < this.totalSlides - 1) {
            this.currentSlide++;
            this.updateSlideDisplay();
        }
    }

    updateSlideDisplay() {
        // Update active slide in navigation
        document.querySelectorAll('.slide-item').forEach((item, index) => {
            item.classList.toggle('active', index === this.currentSlide);
        });

        // Update slide content (placeholder for now)
        const slideContent = document.getElementById('slideContent');
        if (slideContent) {
            const slideNumber = this.currentSlide + 1;
            slideContent.innerHTML = `
                <div class="slide-display">
                    <h2>Slide ${slideNumber}</h2>
                    <p>This slide will contain the generated content for your presentation.</p>
                    <div class="slide-preview-placeholder">
                        <div class="placeholder-icon">📄</div>
                        <p>Slide content will be rendered here after presentation generation is complete.</p>
                    </div>
                </div>
            `;
        }

        this.updateSlideCounter();
    }

    updateSlideCounter() {
        const counter = document.getElementById('slideCounter');
        if (counter) {
            counter.textContent = `Slide ${this.currentSlide + 1} of ${this.totalSlides}`;
        }
    }

    showExportOptions(result) {
        const exportContainer = document.getElementById('exportContainer');
        const exportReady = document.getElementById('exportReady');
        const exportStats = document.getElementById('exportStats');

        if (exportContainer) exportContainer.style.display = 'none';
        if (exportReady) exportReady.style.display = 'block';

        if (exportStats) {
            exportStats.innerHTML = `
                <div class="stat-item">
                    <span class="stat-value">${result.slides_count || this.totalSlides}</span>
                    <div class="stat-label">Total Slides</div>
                </div>
                <div class="stat-item">
                    <span class="stat-value">${result.generation_time || '5.2s'}</span>
                    <div class="stat-label">Generation Time</div>
                </div>
                <div class="stat-item">
                    <span class="stat-value">${Math.round((result.file_size || 5000000) / 1024 / 1024 * 100) / 100} MB</span>
                    <div class="stat-label">File Size</div>
                </div>
                <div class="stat-item">
                    <span class="stat-value">${app.selectedAnalysisTypes.size}</span>
                    <div class="stat-label">Analysis Types</div>
                </div>
            `;
        }
    }

    async downloadPresentation(format = 'pptx') {
        if (!app.sessionId || !app.generatedPresentation) {
            this.showError('No Presentation', 'Please generate a presentation first');
            return;
        }

        this.showLoading('Preparing Download...', 'Packaging your presentation for download');

        try {
            await api.downloadPresentation(app.sessionId);
            this.hideLoading();
            this.showSuccess('Download Complete', 'Your presentation has been downloaded successfully');

            // Update export history
            this.addToExportHistory({
                format,
                timestamp: new Date().toLocaleString(),
                size: app.generatedPresentation.file_size
            });

        } catch (error) {
            console.error('Download error:', error);
            this.showError('Download Failed', error.message);
            this.hideLoading();
        }
    }

    addToExportHistory(exportInfo) {
        const historyContainer = document.getElementById('exportHistory');
        if (!historyContainer) return;

        const historyItem = document.createElement('div');
        historyItem.className = 'history-item';
        historyItem.innerHTML = `
            <div class="history-info">
                <strong>${exportInfo.format.toUpperCase()}</strong> - ${exportInfo.timestamp}
                <br><small>Size: ${Math.round((exportInfo.size || 0) / 1024 / 1024 * 100) / 100} MB</small>
            </div>
            <button class="btn btn-secondary btn-sm" onclick="ui.downloadPresentation('${exportInfo.format}')">
                Re-download
            </button>
        `;

        historyContainer.insertBefore(historyItem, historyContainer.firstChild);
    }

    handleStateChange(key, value) {
        // Handle specific state changes
        switch (key) {
            case 'currentTab':
                this.updateTabVisibility(value);
                break;
            case 'selectedColumns':
                this.updateColumnDependentUI();
                break;
        }
    }

    updateTabVisibility(activeTab) {
        // Additional logic for tab-specific updates
        if (activeTab === 'customize' && app.selectedColumns.size === 0 && app.sessionId) {
            this.showInfo('Select Columns First', 'Please select columns for analysis in Tab 1 before customizing your presentation');
        }
    }

    updateColumnDependentUI() {
        // Update any UI elements that depend on selected columns
        this.updateAvailableColumns();
    }

    updateUploadStatus(status, message) {
        const indicator = document.getElementById('uploadStatus');
        const text = document.getElementById('statusText');

        if (indicator && text) {
            indicator.className = 'status-indicator ' + status;
            text.textContent = message;
        }
    }

    // Utility methods for user feedback
    showLoading(title, message) {
        const modal = document.getElementById('loadingModal');
        const titleEl = document.getElementById('loadingTitle');
        const messageEl = document.getElementById('loadingMessage');

        if (modal) modal.style.display = 'block';
        if (titleEl) titleEl.textContent = title;
        if (messageEl) messageEl.textContent = message;
    }

    hideLoading() {
        const modal = document.getElementById('loadingModal');
        if (modal) modal.style.display = 'none';
    }

    showError(title, message) {
        // Simple alert for now - could be enhanced with custom modal
        alert(`${title}: ${message}`);
    }

    showSuccess(title, message) {
        // Simple alert for now - could be enhanced with custom modal
        console.log(`${title}: ${message}`);

        // Could implement toast notification here
        this.showToast(title, message, 'success');
    }

    showInfo(title, message) {
        console.log(`${title}: ${message}`);
        this.showToast(title, message, 'info');
    }

    showToast(title, message, type = 'info') {
        // Create temporary toast notification
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-header">
                <strong>${title}</strong>
                <button onclick="this.parentElement.parentElement.remove()">×</button>
            </div>
            <div class="toast-body">${message}</div>
        `;

        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            padding: 16px;
            max-width: 350px;
            z-index: 10000;
            border-left: 4px solid ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#17a2b8'};
            animation: slideInRight 0.3s ease;
        `;

        document.body.appendChild(toast);

        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 5000);
    }
}

// Create global UI controller instance
const ui = new UIController();

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('Enhanced DataPresenter Multi-Select Application Loaded');

    // Add CSS for toast animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        .toast-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
            font-weight: 600;
        }
        .toast-header button {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            color: #999;
        }
        .toast-body {
            color: #666;
            font-size: 14px;
            line-height: 1.4;
        }
    `;
    document.head.appendChild(style);
});

// Export for global access
window.app = app;
window.ui = ui;
window.api = api;