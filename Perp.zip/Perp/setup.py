#!/usr/bin/env python3
"""
DataPresenter Complete - Automated Setup
"""
import os
import sys
import shutil
from pathlib import Path

def setup_system():
    print("🚀 Setting up DataPresenter Complete System")
    print("=" * 50)

    # Copy frontend files to backend static directory
    frontend_static = Path("frontend/static")
    backend_static = Path("backend/static")

    if frontend_static.exists():
        if backend_static.exists():
            shutil.rmtree(backend_static)
        shutil.copytree(frontend_static, backend_static)
        print("✅ Frontend files copied to backend")

    # Create directories
    directories = ["backend/temp", "backend/uploads", "backend/charts"]
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
    print("✅ Directories created")

    print("\n🎉 Setup completed!")
    print("\n🚀 To start the application:")
    print("   cd backend")
    print("   python run.py")
    print("\n🌐 Then open: http://localhost:8000")

if __name__ == "__main__":
    setup_system()
