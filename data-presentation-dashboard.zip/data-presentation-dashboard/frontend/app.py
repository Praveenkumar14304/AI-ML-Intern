import streamlit as st
import requests
import pandas as pd
import json
import time
from datetime import datetime

# Page configuration
st.set_page_config(
    page_title="Data Presentation Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# API base URL
API_BASE = "http://localhost:8000"

# Initialize session state
if 'current_tab' not in st.session_state:
    st.session_state.current_tab = "Upload"
if 'upload_data' not in st.session_state:
    st.session_state.upload_data = None
if 'selected_columns' not in st.session_state:
    st.session_state.selected_columns = []
if 'presentation_data' not in st.session_state:
    st.session_state.presentation_data = None

# Sidebar navigation
st.sidebar.title("Data Presentation Dashboard")
tabs = ["Upload", "Template", "Preview", "Export", "History"]
current_tab = st.sidebar.radio("Navigate", tabs, index=tabs.index(st.session_state.current_tab))

# Update current tab
st.session_state.current_tab = current_tab

# Upload Tab
if current_tab == "Upload":
    st.header("📤 Upload Your Data")
    
    uploaded_file = st.file_uploader("Choose a CSV or Excel file", type=['csv', 'xlsx', 'xls'])
    
    if uploaded_file is not None:
        # Send file to backend
        files = {"file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type)}
        with st.spinner("Processing your file..."):
            response = requests.post(f"{API_BASE}/upload/", files=files)
            
            if response.status_code == 200:
                data = response.json()
                st.session_state.upload_data = data
                
                # Display stats
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Rows", f"{data['row_count']:,}")
                with col2:
                    st.metric("Columns", data['column_count'])
                with col3:
                    st.metric("Null Values", data['null_count'])
                with col4:
                    st.metric("PII Detected", data['pii_count'])
                
                # Show preview
                st.subheader("Data Preview")
                st.dataframe(pd.DataFrame(data['preview_data']))
                
                # Column selection
                st.subheader("Column Selection")
                
                # Auto-PII toggle
                auto_pii = st.toggle("Auto-PII Removal", value=True)
                
                # Display columns with info
                selected_columns = []
                for col_info in data['columns_info']:
                    col1, col2 = st.columns([0.1, 0.9])
                    with col1:
                        selected = st.checkbox(
                            "", 
                            value=not col_info['is_pii'] or not auto_pii,
                            key=col_info['name']
                        )
                    with col2:
                        if col_info['is_pii']:
                            st.markdown(f"**{col_info['name']}** ⚠️ (PII detected)")
                        else:
                            st.markdown(f"**{col_info['name']}**")
                        
                        st.caption(f"Type: {col_info['dtype']} | Nulls: {col_info['null_count']} | Unique: {col_info['unique_count']}")
                    
                    if selected:
                        selected_columns.append(col_info['name'])
                
                st.session_state.selected_columns = selected_columns
                
                # Auto-select if no columns selected
                if not selected_columns and st.button("Auto-select Best Columns"):
                    selected_columns = auto_select_columns(data['columns_info'])
                    st.session_state.selected_columns = selected_columns
                    st.rerun()
                
                if selected_columns:
                    st.success(f"Selected {len(selected_columns)} columns: {', '.join(selected_columns)}")
                    
                    # Analyze button
                    if st.button("Analyze Data", type="primary"):
                        with st.spinner("Analyzing data..."):
                            # Prepare data for analysis
                            analysis_data = {
                                "selected_columns": selected_columns,
                                "statistics": data
                            }
                            
                            # Send to backend
                            response = requests.post(f"{API_BASE}/analyze/", json=analysis_data)
                            
                            if response.status_code == 200:
                                analysis_result = response.json()
                                st.session_state.analysis_result = analysis_result
                                st.success("Analysis completed!")
                                
                                # Navigate to next tab
                                st.session_state.current_tab = "Template"
                                st.rerun()
                            else:
                                st.error("Error analyzing data")
            else:
                st.error("Error uploading file")

# Template Tab
elif current_tab == "Template":
    st.header("🎨 Choose Your Template")
    
    if 'upload_data' not in st.session_state or st.session_state.upload_data is None:
        st.warning("Please upload data first")
        st.stop()
    
    # Template selection
    template_type = st.radio(
        "Select Template Type",
        ["Built-in", "Custom Upload"]
    )
    
    if template_type == "Built-in":
        # Built-in template options
        col1, col2, col3, col4 = st.columns(4)
        templates = ["Modern", "Corporate", "Analytical", "Creative"]
        selected_template = None
        
        with col1:
            if st.button("Modern"):
                selected_template = "modern"
        with col2:
            if st.button("Corporate"):
                selected_template = "corporate"
        with col3:
            if st.button("Analytical"):
                selected_template = "analytical"
        with col4:
            if st.button("Creative"):
                selected_template = "creative"
        
        if selected_template:
            st.session_state.selected_template = selected_template
            st.success(f"Selected {selected_template} template")
    
    else:
        # Custom template upload
        custom_template = st.file_uploader("Upload your PowerPoint template", type=['pptx'])
        if custom_template is not None:
            st.session_state.custom_template = custom_template
            st.success("Custom template uploaded")
    
    # Presentation options
    st.subheader("Presentation Options")
    
    col1, col2 = st.columns(2)
    with col1:
        tone = st.selectbox(
            "Tone",
            ["Analytical", "Descriptive", "Executive Summary"]
        )
    with col2:
        insight_type = st.selectbox(
            "Insight Type",
            ["Insights only", "Charts only", "Insights and Charts"]
        )
    
    custom_instructions = st.text_area("Custom Instructions (Optional)")
    
    # Advanced customization
    with st.expander("Advanced Customization (Optional)"):
        col1, col2 = st.columns(2)
        with col1:
            file_name = st.text_input("File Name", placeholder="Auto-generated if empty")
            company_name = st.text_input("Company Name")
        with col2:
            company_logo = st.file_uploader("Company Logo", type=['png', 'jpg', 'jpeg'])
    
    # Generate presentation button
    if st.button("Generate Presentation", type="primary"):
        with st.spinner("Generating presentation..."):
            # Prepare presentation data
            presentation_data = {
                "selected_columns": st.session_state.selected_columns,
                "statistics": st.session_state.upload_data,
                "tone": tone,
                "insight_type": insight_type,
                "custom_instructions": custom_instructions,
                "template": st.session_state.get('selected_template', 'modern'),
                "file_name": file_name,
                "company_name": company_name
            }
            
            # Send to backend
            response = requests.post(f"{API_BASE}/generate-presentation/", json=presentation_data)
            
            if response.status_code == 200:
                result = response.json()
                st.session_state.presentation_data = result
                st.session_state.current_tab = "Preview"
                st.rerun()
            else:
                st.error("Error generating presentation")

# Continue with other tabs (Preview, Export, History)...