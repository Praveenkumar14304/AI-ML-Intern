import google.generativeai as genai
import json
from backend.config import settings

# Configure GenAI
genai.configure(api_key=settings.GOOGLE_API_KEY)

def generate_insights(column_selection: dict) -> dict:
    """
    Generate insights using Google GenAI based on selected columns
    """
    try:
        # Prepare prompt for GenAI
        prompt = prepare_llm_prompt(column_selection)
        
        # Call GenAI
        model = genai.GenerativeModel('gemini-pro')
        response = model.generate_content(prompt)
        
        # Parse response
        insights = parse_llm_response(response.text)
        
        return insights
    
    except Exception as e:
        # Fallback to basic insights if AI fails
        return generate_basic_insights(column_selection)

def prepare_llm_prompt(column_selection: dict) -> str:
    """
    Prepare a structured prompt for the LLM
    """
    prompt = f"""
    Create a comprehensive presentation based on the following data insights.
    
    COLUMNS SELECTED:
    {json.dumps(column_selection['selected_columns'], indent=2)}
    
    DATA STATISTICS:
    {json.dumps(column_selection['statistics'], indent=2)}
    
    PRESENTATION REQUIREMENTS:
    - Tone: {column_selection.get('tone', 'Analytical')}
    - Insight Type: {column_selection.get('insight_type', 'Comprehensive')}
    - Custom Instructions: {column_selection.get('custom_instructions', 'None')}
    
    Please structure the presentation with the following slides:
    1. Title Slide
    2. Dataset Overview
    3. Selected Columns Analysis
    4. Individual Column Insights (one per column)
    5. Correlation Analysis
    6. Business Impact
    7. Conclusion
    
    For each insight slide, provide:
    - A title
    - 3-5 bullet points of key insights
    - Recommended visualization type
    - Brief explanation of why this visualization is appropriate
    
    Return your response in JSON format.
    """
    
    return prompt

def parse_llm_response(response_text: str) -> dict:
    """
    Parse the LLM response into a structured format
    """
    try:
        # Extract JSON from response
        json_start = response_text.find('{')
        json_end = response_text.rfind('}') + 1
        json_str = response_text[json_start:json_end]
        
        return json.loads(json_str)
    except:
        # Fallback if JSON parsing fails
        return {
            "slides": [
                {
                    "title": "Data Insights Presentation",
                    "content": ["Failed to parse AI response", "Using default template"],
                    "visualization": "none",
                    "visualization_reason": "Error in response parsing"
                }
            ]
        }

def generate_basic_insights(column_selection: dict) -> dict:
    """
    Generate basic insights as fallback when AI fails
    """
    insights = {
        "slides": [
            {
                "title": "Data Analysis Presentation",
                "content": [
                    "Automatically generated presentation",
                    f"Analyzing {len(column_selection['selected_columns'])} columns",
                    "Basic statistical insights provided"
                ],
                "visualization": "none",
                "visualization_reason": "Default presentation"
            }
        ]
    }
    
    # Add a slide for each column
    for col in column_selection['selected_columns']:
        insights["slides"].append({
            "title": f"{col} Analysis",
            "content": [
                f"Analysis of {col} column",
                "Basic trends and patterns",
                "Statistical summary"
            ],
            "visualization": "bar",
            "visualization_reason": "Standard visualization for this data type"
        })
    
    # Add conclusion slide
    insights["slides"].append({
        "title": "Conclusion",
        "content": [
            "Summary of key findings",
            "Recommendations for further analysis",
            "Limitations of this analysis"
        ],
        "visualization": "none",
        "visualization_reason": "Conclusion slide"
    })
    
    return insights