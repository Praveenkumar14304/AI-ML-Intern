import pandas as pd
import numpy as np
from typing import Dict, Any
import json

def process_data_file(file_path: str) -> Dict[str, Any]:
    """
    Process uploaded data file and return statistics and preview
    """
    try:
        # Read file based on extension
        if file_path.endswith('.csv'):
            df = pd.read_csv(file_path)
        elif file_path.endswith(('.xlsx', '.xls')):
            df = pd.read_excel(file_path)
        else:
            raise ValueError("Unsupported file format")
        
        # Calculate basic statistics
        row_count, col_count = df.shape
        null_count = df.isnull().sum().sum()
        
        # Detect PII columns
        pii_columns = detect_pii_columns(df)
        
        # Get column information
        columns_info = []
        for col in df.columns:
            col_info = {
                "name": col,
                "dtype": str(df[col].dtype),
                "null_count": int(df[col].isnull().sum()),
                "unique_count": int(df[col].nunique()),
                "is_pii": col in pii_columns
            }
            columns_info.append(col_info)
        
        # Get sample data for preview
        preview_data = df.head(10).to_dict(orient='records')
        
        return {
            "success": True,
            "row_count": row_count,
            "column_count": col_count,
            "null_count": null_count,
            "pii_count": len(pii_columns),
            "pii_columns": pii_columns,
            "preview_data": preview_data,
            "columns_info": columns_info
        }
    
    except Exception as e:
        return {"success": False, "error": str(e)}

def detect_pii_columns(df: pd.DataFrame) -> list:
    """
    Detect columns that might contain Personally Identifiable Information
    """
    pii_columns = []
    
    for col in df.columns:
        col_data = df[col].dropna().astype(str)
        
        # Check for email patterns
        if col_data.str.contains(r'@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}').any():
            pii_columns.append(col)
            continue
            
        # Check for phone number patterns
        if col_data.str.contains(r'(\+\d{1,2}\s?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}').any():
            pii_columns.append(col)
            continue
            
        # Check for ID patterns (e.g., SSN)
        if col_data.str.contains(r'\d{3}-\d{2}-\d{4}').any():
            pii_columns.append(col)
    
    return pii_columns

def auto_select_columns(df: pd.DataFrame, columns_info: list) -> list:
    """
    Automatically select the most relevant columns for analysis
    """
    # Priority: datetime > categorical > numerical
    datetime_cols = [col for col in columns_info if 'date' in col['name'].lower() or 'time' in col['name'].lower()]
    categorical_cols = [col for col in columns_info if col['dtype'] == 'object' and col['name'] not in datetime_cols]
    numerical_cols = [col for col in columns_info if col['dtype'] in ['int64', 'float64']]
    
    selected_columns = []
    
    # Add datetime columns (max 1)
    if datetime_cols:
        selected_columns.append(datetime_cols[0]['name'])
    
    # Add categorical columns (max 3)
    categorical_cols.sort(key=lambda x: x['unique_count'], reverse=True)
    for col in categorical_cols[:3]:
        selected_columns.append(col['name'])
    
    # Add numerical columns (max 2)
    numerical_cols.sort(key=lambda x: x['unique_count'], reverse=True)
    for col in numerical_cols[:2]:
        selected_columns.append(col['name'])
    
    # If we don't have enough columns, add more of other types
    if len(selected_columns) < 6:
        remaining_slots = 6 - len(selected_columns)
        
        # Add more numerical if available
        if len(numerical_cols) > 2:
            for col in numerical_cols[2:2+remaining_slots]:
                selected_columns.append(col['name'])
                remaining_slots -= 1
                if remaining_slots == 0:
                    break
        
        # Add more categorical if available
        if remaining_slots > 0 and len(categorical_cols) > 3:
            for col in categorical_cols[3:3+remaining_slots]:
                selected_columns.append(col['name'])
                remaining_slots -= 1
                if remaining_slots == 0:
                    break
    
    return selected_columns[:6]  # Return max 6 columns