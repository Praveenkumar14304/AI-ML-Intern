from fastapi import FastAPI, File, UploadFile, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import shutil
import os
from typing import List

from backend.config import settings
from backend.database.database import get_db, SessionLocal
from backend.schemas.presentation_schema import PresentationCreate, PresentationResponse
from backend.services.presentation_service import create_presentation, get_presentation, get_recent_presentations
from backend.data_processor import process_data_file
from backend.ai_handler import generate_insights
from backend.template_manager import extract_template_design, apply_template_to_presentation
from backend.presentation_builder import build_presentation
from backend.history_manager import save_to_history, get_history

app = FastAPI(title=settings.PROJECT_NAME, version=settings.PROJECT_VERSION)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    try:
        # Save uploaded file temporarily
        file_path = f"temp_{file.filename}"
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # Process the file
        result = process_data_file(file_path)
        
        # Clean up
        os.remove(file_path)
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")

@app.post("/analyze/")
async def analyze_data(column_selection: dict):
    try:
        # Generate insights using GenAI
        insights = generate_insights(column_selection)
        return {"insights": insights}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error analyzing data: {str(e)}")

@app.post("/generate-presentation/")
async def generate_presentation(presentation_data: dict, db: SessionLocal = Depends(get_db)):
    try:
        # Create presentation
        presentation = create_presentation(db, presentation_data)
        
        # Build the presentation file
        file_path = build_presentation(presentation_data)
        
        # Save to history
        save_to_history(db, presentation, file_path)
        
        return {"success": True, "file_path": file_path, "presentation_id": presentation.id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating presentation: {str(e)}")

@app.get("/presentations/")
async def get_presentations(limit: int = 5, db: SessionLocal = Depends(get_db)):
    try:
        presentations = get_recent_presentations(db, limit)
        return presentations
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching presentations: {str(e)}")

@app.get("/download/{presentation_id}")
async def download_presentation(presentation_id: int, db: SessionLocal = Depends(get_db)):
    try:
        presentation = get_presentation(db, presentation_id)
        if not presentation:
            raise HTTPException(status_code=404, detail="Presentation not found")
        
        return FileResponse(
            presentation.file_path,
            media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
            filename=f"presentation_{presentation_id}.pptx"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error downloading presentation: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)