"""
Pytest configuration and fixtures for AI/ML PPT Generator tests
"""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path
import tempfile
import uuid
import asyncio
from unittest.mock import Mock, AsyncMock

from backend.utils.storage import StorageManager
from backend.ml.data_analyzer import MLDataAnalyzer
from backend.ml.chart_generator import ChartGenerator
from backend.ppt.generator import PPTGenerator
from tests import TestDataGenerator, cleanup_temp_files

@pytest.fixture(scope="session")
def event_loop():
    """Create event loop for async tests"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture(scope="session", autouse=True)
def setup_test_environment():
    """Setup test environment"""
    # Create test directories
    test_dirs = [
        Path("tests/data"),
        Path("tests/temp"),
        Path("tests/output")
    ]
    
    for test_dir in test_dirs:
        test_dir.mkdir(parents=True, exist_ok=True)
    
    yield
    
    # Cleanup after all tests
    cleanup_temp_files()

@pytest.fixture
def sample_csv_file():
    """Create sample CSV file for testing"""
    file_path = TestDataGenerator.create_sample_csv()
    yield file_path
    
    # Cleanup
    if file_path.exists():
        file_path.unlink()

@pytest.fixture
def sample_excel_file():
    """Create sample Excel file for testing"""
    file_path = TestDataGenerator.create_sample_excel()
    yield file_path
    
    # Cleanup
    if file_path.exists():
        file_path.unlink()

@pytest.fixture
def large_dataset_file():
    """Create large dataset for performance testing"""
    file_path = TestDataGenerator.create_large_dataset(1000)  # Smaller for tests
    yield file_path
    
    # Cleanup
    if file_path.exists():
        file_path.unlink()

@pytest.fixture
def pii_dataset_file():
    """Create dataset with PII data"""
    file_path = TestDataGenerator.create_pii_dataset()
    yield file_path
    
    # Cleanup
    if file_path.exists():
        file_path.unlink()

@pytest.fixture
def sample_dataframe():
    """Create sample DataFrame for testing"""
    return pd.DataFrame({
        'numeric_col': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        'categorical_col': ['A', 'B', 'A', 'C', 'B', 'A', 'C', 'B', 'A', 'C'],
        'datetime_col': pd.date_range('2023-01-01', periods=10),
        'text_col': [f'Text value {i}' for i in range(10)],
        'nullable_col': [1, 2, None, 4, None, 6, 7, None, 9, 10]
    })

@pytest.fixture
def mock_storage_manager():
    """Create mock storage manager"""
    storage = Mock(spec=StorageManager)
    storage.save_uploaded_file.return_value = "/mock/path/file.csv"
    storage.save_metadata.return_value = None
    storage.load_metadata.return_value = {
        'dataset_id': 'test_id',
        'filename': 'test.csv',
        'rows': 100,
        'columns': 5
    }
    return storage

@pytest.fixture
def mock_data_analyzer():
    """Create mock data analyzer"""
    analyzer = Mock(spec=MLDataAnalyzer)
    analyzer.analyze_dataset = AsyncMock(return_value={
        'column_analysis': {
            'test_column': {
                'type': 'numeric',
                'mean': 50.0,
                'std': 10.0,
                'null_percentage': 0.0
            }
        },
        'correlations': {
            'strong_correlations': []
        },
        'insights': ['Test insight']
    })
    return analyzer

@pytest.fixture
def mock_chart_generator():
    """Create mock chart generator"""
    generator = Mock(spec=ChartGenerator)
    generator.generate_chart.return_value = "/mock/path/chart.png"
    generator.select_optimal_chart.return_value = "histogram"
    return generator

@pytest.fixture
def mock_ppt_generator():
    """Create mock PowerPoint generator"""
    generator = Mock(spec=PPTGenerator)
    generator.create_presentation.return_value = Mock()
    generator.save_presentation.return_value = "/mock/path/presentation.pptx"
    generator.get_slide_count.return_value = 8
    return generator

@pytest.fixture
def test_config():
    """Test configuration dictionary"""
    return {
        'template': 'corporate_blue',
        'story_mode': 'executive',
        'content_style': 'insights_charts',
        'title': 'Test Presentation',
        'selected_columns': ['numeric_col', 'categorical_col'],
        'auto_remove_pii': True,
        'include_charts': True,
        'include_insights': True,
        'brand_assets': {}
    }

@pytest.fixture
def sample_analysis_results():
    """Sample analysis results for testing"""
    return {
        'dataset_summary': {
            'rows': 1000,
            'columns': 5,
            'null_percentage': 2.5,
            'memory_usage_mb': 0.5
        },
        'column_analysis': {
            'revenue': {
                'type': 'numeric',
                'mean': 75000,
                'median': 72000,
                'std': 15000,
                'min': 45000,
                'max': 120000,
                'null_percentage': 0.0,
                'unique_count': 856,
                'skewness': 0.3,
                'kurtosis': -0.2
            },
            'department': {
                'type': 'categorical',
                'unique_count': 4,
                'top_value': 'Engineering',
                'top_percentage': 35.0,
                'null_percentage': 1.2,
                'entropy': 1.8
            }
        },
        'correlations': {
            'strong_correlations': [
                {
                    'column1': 'revenue',
                    'column2': 'experience',
                    'pearson_correlation': 0.82,
                    'spearman_correlation': 0.79,
                    'strength': 'strong'
                }
            ],
            'correlation_summary': {
                'total_pairs': 10,
                'strong_correlations_count': 1
            }
        },
        'anomalies': {
            'revenue': {
                'anomaly_percentage': 3.2,
                'iqr_anomalies': 32,
                'z_score_anomalies': 15
            }
        },
        'insights': [
            'High data quality with 97.5% completeness',
            'Strong correlation between revenue and experience'
        ]
    }

@pytest.fixture
def mock_file_upload():
    """Mock file upload object"""
    mock_file = Mock()
    mock_file.filename = "test_data.csv"
    mock_file.size = 1024 * 1024  # 1MB
    mock_file.read = AsyncMock(return_value=b"mock,csv,content\n1,2,3")
    mock_file.seek = AsyncMock()
    return mock_file

# Test markers
def pytest_configure(config):
    """Configure pytest markers"""
    config.addinivalue_line("markers", "unit: Unit tests")
    config.addinivalue_line("markers", "integration: Integration tests")
    config.addinivalue_line("markers", "slow: Slow running tests")
    config.addinivalue_line("markers", "api: API endpoint tests")
    config.addinivalue_line("markers", "ml: Machine learning tests")
    config.addinivalue_line("markers", "ppt: PowerPoint generation tests")

# Test utilities
class TestHelpers:
    """Helper functions for tests"""
    
    @staticmethod
    def create_temp_file(content: str, suffix: str = ".csv") -> Path:
        """Create temporary file with content"""
        temp_file = Path(tempfile.mktemp(suffix=suffix))
        with open(temp_file, 'w') as f:
            f.write(content)
        return temp_file
    
    @staticmethod
    def assert_dataframe_equal(df1: pd.DataFrame, df2: pd.DataFrame):
        """Assert DataFrames are equal with better error messages"""
        try:
            pd.testing.assert_frame_equal(df1, df2)
        except AssertionError as e:
            pytest.fail(f"DataFrames are not equal: {str(e)}")
    
    @staticmethod
    def assert_file_exists(file_path: Path):
        """Assert file exists with clear error message"""
        if not file_path.exists():
            pytest.fail(f"File does not exist: {file_path}")
    
    @staticmethod
    def assert_json_structure(data: dict, expected_keys: list):
        """Assert JSON has expected structure"""
        missing_keys = [key for key in expected_keys if key not in data]
        if missing_keys:
            pytest.fail(f"Missing keys in JSON: {missing_keys}")

@pytest.fixture
def test_helpers():
    """Provide test helper functions"""
    return TestHelpers
