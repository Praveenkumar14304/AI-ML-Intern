"""
Test cases for file upload functionality
"""

import pytest
import pandas as pd
from pathlib import Path
from unittest.mock import Mock, patch, AsyncMock

from backend.api.upload import UploadHandler, handle_file_upload
from backend.ml.pii_detector import EnhancedPIIDetector


class TestUploadHandler:
    """Test cases for UploadHandler"""
    
    def test_init(self):
        """Test UploadHandler initialization"""
        handler = UploadHandler()
        
        assert handler.storage_manager is not None
        assert handler.pii_detector is not None
        assert handler.data_analyzer is not None
        assert handler.max_file_size == 50 * 1024 * 1024
        assert len(handler.allowed_types) > 0
        assert len(handler.allowed_extensions) > 0
    
    @pytest.mark.asyncio
    async def test_handle_upload_csv_success(self, mock_file_upload, mock_storage_manager):
        """Test successful CSV file upload"""
        handler = UploadHandler()
        handler.storage_manager = mock_storage_manager
        
        # Mock background tasks
        background_tasks = Mock()
        background_tasks.add_task = Mock()
        
        with patch.object(handler, '_validate_file') as mock_validate, \
             patch.object(handler, '_load_dataset') as mock_load, \
             patch.object(handler, '_analyze_dataset') as mock_analyze:
            
            mock_validate.return_value = {'valid': True, 'error': None}
            mock_load.return_value = (pd.DataFrame({'col1': [1, 2, 3]}), {'success': True})
            mock_analyze.return_value = {'pii_results': {'removed_columns': []}}
            
            result = await handler.handle_upload(mock_file_upload, background_tasks)
            
            assert result['success'] is True
            assert 'dataset_id' in result
            assert 'upload_id' in result
            assert result['filename'] == 'test_data.csv'
    
    @pytest.mark.asyncio
    async def test_handle_upload_invalid_file(self, mock_file_upload):
        """Test upload with invalid file"""
        handler = UploadHandler()
        
        background_tasks = Mock()
        
        with patch.object(handler, '_validate_file') as mock_validate:
            mock_validate.return_value = {'valid': False, 'error': 'Invalid file type'}
            
            with pytest.raises(Exception):
                await handler.handle_upload(mock_file_upload, background_tasks)
    
    @pytest.mark.asyncio
    async def test_validate_file_success(self, mock_file_upload):
        """Test successful file validation"""
        handler = UploadHandler()
        
        result = await handler._validate_file(mock_file_upload)
        
        assert result['valid'] is True
        assert result['error'] is None
    
    @pytest.mark.asyncio
    async def test_validate_file_no_filename(self):
        """Test file validation with no filename"""
        handler = UploadHandler()
        
        mock_file = Mock()
        mock_file.filename = None
        
        result = await handler._validate_file(mock_file)
        
        assert result['valid'] is False
        assert 'filename' in result['error']
    
    @pytest.mark.asyncio
    async def test_validate_file_invalid_extension(self):
        """Test file validation with invalid extension"""
        handler = UploadHandler()
        
        mock_file = Mock()
        mock_file.filename = "test.txt"
        mock_file.read = AsyncMock(return_value=b"test content")
        mock_file.seek = AsyncMock()
        
        result = await handler._validate_file(mock_file)
        
        assert result['valid'] is False
        assert 'extension' in result['error']
    
    @pytest.mark.asyncio
    async def test_validate_file_too_large(self):
        """Test file validation with file too large"""
        handler = UploadHandler()
        
        mock_file = Mock()
        mock_file.filename = "test.csv"
        mock_file.read = AsyncMock(return_value=b"x" * (51 * 1024 * 1024))  # 51MB
        mock_file.seek = AsyncMock()
        
        result = await handler._validate_file(mock_file)
        
        assert result['valid'] is False
        assert 'too large' in result['error']
    
    @pytest.mark.asyncio
    async def test_load_dataset_csv(self, sample_csv_file):
        """Test loading CSV dataset"""
        handler = UploadHandler()
        
        df, result = await handler._load_dataset(str(sample_csv_file), "test.csv")
        
        assert result['success'] is True
        assert df is not None
        assert len(df) > 0
        assert len(df.columns) > 0
    
    @pytest.mark.asyncio
    async def test_load_dataset_excel(self, sample_excel_file):
        """Test loading Excel dataset"""
        handler = UploadHandler()
        
        df, result = await handler._load_dataset(str(sample_excel_file), "test.xlsx")
        
        assert result['success'] is True
        assert df is not None
        assert len(df) > 0
        assert len(df.columns) > 0
    
    @pytest.mark.asyncio
    async def test_load_dataset_nonexistent(self):
        """Test loading non-existent dataset"""
        handler = UploadHandler()
        
        df, result = await handler._load_dataset("/nonexistent/file.csv", "file.csv")
        
        assert result['success'] is False
        assert df is None
        assert 'error' in result
    
    @pytest.mark.asyncio
    async def test_analyze_dataset(self, sample_dataframe):
        """Test dataset analysis"""
        handler = UploadHandler()
        
        with patch.object(handler.data_analyzer, 'analyze_column') as mock_analyze_col, \
             patch.object(handler.pii_detector, 'detect_with_overrides') as mock_pii:
            
            mock_analyze_col.return_value = {
                'type': 'numeric',
                'mean': 5.5,
                'null_percentage': 10.0
            }
            mock_pii.return_value = {'removed_columns': []}
            
            result = await handler._analyze_dataset(sample_dataframe, "test_id")
            
            assert 'column_analysis' in result
            assert 'pii_results' in result
            assert 'data_quality' in result
            assert result['dataset_id'] == "test_id"
    
    def test_calculate_data_quality_score(self, sample_dataframe):
        """Test data quality score calculation"""
        handler = UploadHandler()
        
        analysis = {
            'basic_stats': {'null_percentage': 5.0},
            'column_analysis': {
                'col1': {'type': 'numeric'},
                'col2': {'type': 'categorical'}
            }
        }
        
        quality_score = handler._calculate_data_quality_score(sample_dataframe, analysis)
        
        assert 'scores' in quality_score
        assert 'overall_score' in quality_score
        assert 'grade' in quality_score
        assert 0 <= quality_score['overall_score'] <= 100
    
    def test_get_quality_grade(self):
        """Test quality grade assignment"""
        handler = UploadHandler()
        
        assert handler._get_quality_grade(95) == 'A'
        assert handler._get_quality_grade(85) == 'B'
        assert handler._get_quality_grade(75) == 'C'
        assert handler._get_quality_grade(65) == 'D'
        assert handler._get_quality_grade(55) == 'F'
    
    def test_generate_recommendations(self, sample_dataframe):
        """Test recommendation generation"""
        handler = UploadHandler()
        
        analysis = {
            'basic_stats': {'null_percentage': 15.0},
            'pii_results': {'removed_count': 2},
            'column_analysis': {
                'numeric_col': {'type': 'numeric'},
                'text_col': {'type': 'text'}
            }
        }
        
        recommendations = handler._generate_recommendations(sample_dataframe, analysis)
        
        assert isinstance(recommendations, list)
        assert len(recommendations) > 0
        
        # Check that high null percentage generates recommendation
        null_recommendations = [r for r in recommendations if 'missing' in r.lower()]
        assert len(null_recommendations) > 0


class TestPIIDetection:
    """Test cases for PII detection functionality"""
    
    def test_pii_detector_initialization(self):
        """Test PII detector initialization"""
        detector = EnhancedPIIDetector()
        
        assert detector.pii_keywords is not None
        assert len(detector.pii_keywords) > 0
    
    def test_detect_pii_columns_with_pii(self, pii_dataset_file):
        """Test PII detection with dataset containing PII"""
        detector = EnhancedPIIDetector()
        df = pd.read_csv(pii_dataset_file)
        
        pii_columns = detector.detect_pii(df)
        
        assert len(pii_columns) > 0
        
        # Check that email column is detected
        email_detected = any(col['name'] == 'email' for col in pii_columns)
        assert email_detected
        
        # Check that SSN column is detected
        ssn_detected = any(col['name'] == 'ssn' for col in pii_columns)
        assert ssn_detected
    
    def test_detect_pii_columns_without_pii(self, sample_dataframe):
        """Test PII detection with clean dataset"""
        detector = EnhancedPIIDetector()
        
        pii_columns = detector.detect_pii(sample_dataframe)
        
        # Should detect no PII in sample dataframe
        assert len(pii_columns) == 0


@pytest.mark.api
class TestUploadAPI:
    """Test cases for upload API endpoints"""
    
    @pytest.mark.asyncio
    async def test_handle_file_upload_success(self, mock_file_upload, mock_storage_manager):
        """Test successful API file upload"""
        background_tasks = Mock()
        background_tasks.add_task = Mock()
        
        with patch('backend.api.upload.UploadHandler') as mock_handler_class:
            mock_handler = Mock()
            mock_handler.handle_upload = AsyncMock(return_value={
                'success': True,
                'dataset_id': 'test_id'
            })
            mock_handler_class.return_value = mock_handler
            
            result = await handle_file_upload(mock_file_upload, background_tasks)
            
            assert result['success'] is True
            assert 'dataset_id' in result
    
    @pytest.mark.asyncio
    async def test_handle_file_upload_failure(self, mock_file_upload):
        """Test API file upload failure"""
        background_tasks = Mock()
        
        with patch('backend.api.upload.UploadHandler') as mock_handler_class:
            mock_handler = Mock()
            mock_handler.handle_upload = AsyncMock(side_effect=Exception("Upload failed"))
            mock_handler_class.return_value = mock_handler
            
            with pytest.raises(Exception):
                await handle_file_upload(mock_file_upload, background_tasks)


@pytest.mark.integration
class TestUploadIntegration:
    """Integration tests for upload functionality"""
    
    @pytest.mark.asyncio
    async def test_full_upload_workflow(self, sample_csv_file, test_helpers):
        """Test complete upload workflow"""
        handler = UploadHandler()
        background_tasks = Mock()
        background_tasks.add_task = Mock()
        
        # Create mock file upload
        with open(sample_csv_file, 'rb') as f:
            file_content = f.read()
        
        mock_file = Mock()
        mock_file.filename = sample_csv_file.name
        mock_file.size = len(file_content)
        mock_file.read = AsyncMock(return_value=file_content)
        mock_file.seek = AsyncMock()
        
        # Mock storage manager to avoid actual file operations
        with patch.object(handler, 'storage_manager') as mock_storage:
            mock_storage.save_uploaded_file.return_value = str(sample_csv_file)
            mock_storage.save_metadata.return_value = None
            mock_storage.file_exists.return_value = False
            
            result = await handler.handle_upload(mock_file, background_tasks)
            
            assert result['success'] is True
            assert 'dataset_id' in result
            assert 'upload_id' in result
            assert result['filename'] == sample_csv_file.name
            assert result['rows'] > 0
            assert result['columns'] > 0
