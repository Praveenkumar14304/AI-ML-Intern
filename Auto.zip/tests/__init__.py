"""
Test Suite for AI/ML Data to PowerPoint Generator
Comprehensive testing framework with fixtures and utilities
"""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path
import tempfile
import uuid
from datetime import datetime
import json

# Test configuration
TEST_DATA_PATH = Path(__file__).parent / "data"
TEMP_DIR = Path(tempfile.gettempdir()) / "aiml_ppt_tests"

# Create test directories
TEST_DATA_PATH.mkdir(exist_ok=True)
TEMP_DIR.mkdir(exist_ok=True)

# Test constants
SAMPLE_CSV_CONTENT = """name,age,salary,department,hire_date
John Doe,30,75000,Engineering,2020-01-15
Jane Smith,25,65000,Marketing,2021-03-10
Bob Johnson,35,85000,Engineering,2019-06-01
Alice Brown,28,70000,Sales,2020-09-20
Charlie Wilson,32,80000,Marketing,2018-11-05"""

SAMPLE_EXCEL_DATA = {
    'revenue': [100000, 120000, 95000, 140000, 110000],
    'quarter': ['Q1', 'Q2', 'Q3', 'Q4', 'Q1'],
    'region': ['North', 'South', 'East', 'West', 'North'],
    'product_id': [1001, 1002, 1003, 1004, 1005],
    'conversion_rate': [0.12, 0.15, 0.09, 0.18, 0.14]
}

# Test fixtures and utilities
class TestDataGenerator:
    """Generates test data for various scenarios"""
    
    @staticmethod
    def create_sample_csv(file_path: Path = None) -> Path:
        """Create sample CSV file"""
        if file_path is None:
            file_path = TEMP_DIR / f"test_data_{uuid.uuid4().hex[:8]}.csv"
        
        with open(file_path, 'w') as f:
            f.write(SAMPLE_CSV_CONTENT)
        
        return file_path
    
    @staticmethod
    def create_sample_excel(file_path: Path = None) -> Path:
        """Create sample Excel file"""
        if file_path is None:
            file_path = TEMP_DIR / f"test_data_{uuid.uuid4().hex[:8]}.xlsx"
        
        df = pd.DataFrame(SAMPLE_EXCEL_DATA)
        df.to_excel(file_path, index=False)
        
        return file_path
    
    @staticmethod
    def create_large_dataset(rows: int = 10000, file_path: Path = None) -> Path:
        """Create large dataset for performance testing"""
        if file_path is None:
            file_path = TEMP_DIR / f"large_test_data_{uuid.uuid4().hex[:8]}.csv"
        
        np.random.seed(42)  # For reproducibility
        
        data = {
            'id': range(1, rows + 1),
            'value1': np.random.normal(100, 20, rows),
            'value2': np.random.exponential(50, rows),
            'category': np.random.choice(['A', 'B', 'C', 'D'], rows),
            'date': pd.date_range('2020-01-01', periods=rows, freq='H'),
            'flag': np.random.choice([True, False], rows)
        }
        
        df = pd.DataFrame(data)
        df.to_csv(file_path, index=False)
        
        return file_path
    
    @staticmethod
    def create_pii_dataset(file_path: Path = None) -> Path:
        """Create dataset with PII data for testing detection"""
        if file_path is None:
            file_path = TEMP_DIR / f"pii_test_data_{uuid.uuid4().hex[:8]}.csv"
        
        pii_data = {
            'customer_id': [f'CUST_{i:04d}' for i in range(1, 101)],
            'email': [f'user{i}@example.com' for i in range(1, 101)],
            'phone': [f'555-{i:04d}' for i in range(1000, 1100)],
            'first_name': [f'FirstName{i}' for i in range(1, 101)],
            'revenue': np.random.uniform(1000, 50000, 100),
            'product_category': np.random.choice(['Electronics', 'Clothing', 'Books'], 100),
            'purchase_date': pd.date_range('2023-01-01', periods=100),
            'ssn': [f'{i:03d}-{i:02d}-{i:04d}' for i in range(1, 101)]
        }
        
        df = pd.DataFrame(pii_data)
        df.to_csv(file_path, index=False)
        
        return file_path

# Cleanup utility
def cleanup_temp_files():
    """Clean up temporary test files"""
    import shutil
    
    if TEMP_DIR.exists():
        shutil.rmtree(TEMP_DIR)
        TEMP_DIR.mkdir(exist_ok=True)

# Test configuration
pytest_plugins = []
