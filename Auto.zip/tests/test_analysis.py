"""
Test cases for data analysis functionality
"""

import pytest
import pandas as pd
import numpy as np
from unittest.mock import Mock, patch, AsyncMock

from backend.ml.data_analyzer import MLDataAnalyzer
from backend.api.analysis import AnalysisHandler


class TestMLDataAnalyzer:
    """Test cases for MLDataAnalyzer"""
    
    def test_initialization(self):
        """Test analyzer initialization"""
        analyzer = MLDataAnalyzer()
        
        assert analyzer.scaler is not None
        assert analyzer.label_encoders == {}
        assert analyzer.analysis_results == {}
    
    def test_detect_column_type_numeric(self):
        """Test numeric column type detection"""
        analyzer = MLDataAnalyzer()
        
        numeric_series = pd.Series([1, 2, 3, 4, 5])
        column_type = analyzer.detect_column_type(numeric_series)
        
        assert column_type == 'numeric'
    
    def test_detect_column_type_categorical(self):
        """Test categorical column type detection"""
        analyzer = MLDataAnalyzer()
        
        categorical_series = pd.Series(['A', 'B', 'A', 'C', 'B'])
        column_type = analyzer.detect_column_type(categorical_series)
        
        assert column_type == 'categorical'
    
    def test_detect_column_type_datetime(self):
        """Test datetime column type detection"""
        analyzer = MLDataAnalyzer()
        
        datetime_series = pd.Series(pd.date_range('2023-01-01', periods=5))
        column_type = analyzer.detect_column_type(datetime_series)
        
        assert column_type == 'datetime'
    
    def test_detect_column_type_text(self):
        """Test text column type detection"""
        analyzer = MLDataAnalyzer()
        
        text_series = pd.Series(['This is a long text string'] * 5)
        column_type = analyzer.detect_column_type(text_series)
        
        assert column_type in ['text_long', 'text_medium']
    
    @pytest.mark.asyncio
    async def test_analyze_column_numeric(self):
        """Test numeric column analysis"""
        analyzer = MLDataAnalyzer()
        
        numeric_data = pd.Series([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        analysis = await analyzer.analyze_column(numeric_data, 'numeric')
        
        assert analysis['type'] == 'numeric'
        assert 'mean' in analysis
        assert 'median' in analysis
        assert 'std' in analysis
        assert 'min' in analysis
        assert 'max' in analysis
        assert analysis['mean'] == 5.5
        assert analysis['min'] == 1
        assert analysis['max'] == 10
    
    @pytest.mark.asyncio
    async def test_analyze_column_categorical(self):
        """Test categorical column analysis"""
        analyzer = MLDataAnalyzer()
        
        categorical_data = pd.Series(['A', 'B', 'A', 'C', 'B', 'A'])
        analysis = await analyzer.analyze_column(categorical_data, 'categorical')
        
        assert analysis['type'] == 'categorical'
        assert 'top_value' in analysis
        assert 'top_count' in analysis
        assert 'unique_count' in analysis
        assert analysis['top_value'] == 'A'
        assert analysis['unique_count'] == 3
    
    @pytest.mark.asyncio
    async def test_analyze_dataset(self, sample_dataframe):
        """Test complete dataset analysis"""
        analyzer = MLDataAnalyzer()
        
        results = await analyzer.analyze_dataset(sample_dataframe)
        
        assert 'dataset_summary' in results
        assert 'column_analysis' in results
        assert 'insights' in results
        
        # Check dataset summary
        summary = results['dataset_summary']
        assert summary['rows'] == len(sample_dataframe)
        assert summary['columns'] == len(sample_dataframe.columns)
        
        # Check column analysis
        column_analysis = results['column_analysis']
        assert len(column_analysis) == len(sample_dataframe.columns)
        
        # Check specific column analysis
        assert 'numeric_col' in column_analysis
        assert column_analysis['numeric_col']['type'] == 'numeric'
    
    def test_calculate_correlations_success(self):
        """Test correlation calculation with valid data"""
        analyzer = MLDataAnalyzer()
        
        # Create correlated data
        np.random.seed(42)
        df = pd.DataFrame({
            'x': np.random.normal(0, 1, 100),
            'y': np.random.normal(0, 1, 100)
        })
        df['z'] = df['x'] * 0.8 + np.random.normal(0, 0.2, 100)  # Strong correlation with x
        
        correlations = analyzer.calculate_correlations(df)
        
        assert 'pearson_matrix' in correlations
        assert 'spearman_matrix' in correlations
        assert 'strong_correlations' in correlations
        assert 'correlation_summary' in correlations
    
    def test_calculate_correlations_insufficient_data(self):
        """Test correlation calculation with insufficient data"""
        analyzer = MLDataAnalyzer()
        
        df = pd.DataFrame({'single_col': [1, 2, 3]})
        
        # Should handle single column gracefully
        try:
            correlations = analyzer.calculate_correlations(df)
            # If no exception, should return empty or error result
            assert correlations is not None
        except Exception:
            # Exception is acceptable for insufficient data
            pass
    
    def test_perform_clustering(self):
        """Test clustering analysis"""
        analyzer = MLDataAnalyzer()
        
        # Create clusterable data
        np.random.seed(42)
        cluster1 = np.random.multivariate_normal([0, 0], [[1, 0], [0, 1]], 50)
        cluster2 = np.random.multivariate_normal([3, 3], [[1, 0], [0, 1]], 50)
        data = np.vstack([cluster1, cluster2])
        
        df = pd.DataFrame(data, columns=['x', 'y'])
        
        clustering_result = analyzer.perform_clustering(df)
        
        assert 'cluster_labels' in clustering_result
        assert 'n_clusters' in clustering_result
        assert 'cluster_centers' in clustering_result
        assert 'cluster_stats' in clustering_result
        
        # Should identify 2-3 clusters
        assert clustering_result['n_clusters'] >= 2
    
    def test_detect_anomalies(self):
        """Test anomaly detection"""
        analyzer = MLDataAnalyzer()
        
        # Create data with outliers
        np.random.seed(42)
        normal_data = np.random.normal(0, 1, 95)
        outliers = np.array([10, -10, 15, -15, 20])  # Clear outliers
        data = np.concatenate([normal_data, outliers])
        
        df = pd.DataFrame({'values': data})
        
        anomalies = analyzer.detect_anomalies(df)
        
        assert 'values' in anomalies
        assert 'z_score_anomalies' in anomalies['values']
        assert 'iqr_anomalies' in anomalies['values']
        assert 'anomaly_percentage' in anomalies['values']
        
        # Should detect the outliers we added
        assert anomalies['values']['iqr_anomalies'] > 0
    
    def test_generate_insights(self):
        """Test insight generation"""
        analyzer = MLDataAnalyzer()
        
        analysis_results = {
            'dataset_summary': {
                'rows': 1000,
                'columns': 5
            },
            'column_analysis': {
                'col1': {'type': 'numeric', 'null_percentage': 0},
                'col2': {'type': 'numeric', 'null_percentage': 25}
            },
            'correlations': {
                'strong_correlations': [
                    {'column1': 'col1', 'column2': 'col2', 'pearson_correlation': 0.8}
                ]
            }
        }
        
        insights = analyzer.generate_insights(analysis_results)
        
        assert isinstance(insights, list)
        assert len(insights) > 0
        
        # Should generate insights about data quality and correlations
        insight_text = ' '.join(insights).lower()
        assert any(word in insight_text for word in ['correlation', 'data', 'analysis'])


class TestAnalysisHandler:
    """Test cases for AnalysisHandler"""
    
    def test_initialization(self):
        """Test handler initialization"""
        handler = AnalysisHandler()
        
        assert handler.storage_manager is not None
        assert handler.data_analyzer is not None
        assert handler.chart_generator is not None
    
    @pytest.mark.asyncio
    async def test_analyze_dataset_success(self, sample_analysis_results):
        """Test successful dataset analysis"""
        handler = AnalysisHandler()
        
        # Mock dependencies
        with patch.object(handler, '_load_dataset') as mock_load, \
             patch.object(handler, '_comprehensive_analysis') as mock_analyze, \
             patch.object(handler.storage_manager, 'save_analysis_results') as mock_save:
            
            mock_load.return_value = (pd.DataFrame({'col1': [1, 2, 3]}), {'dataset_id': 'test'})
            mock_analyze.return_value = sample_analysis_results
            mock_save.return_value = None
            
            result = await handler.analyze_dataset('test_id', ['col1'], 'comprehensive')
            
            assert result['dataset_id'] == 'test_id'
            assert 'analysis_timestamp' in result
            assert 'analyzed_columns' in result
    
    @pytest.mark.asyncio
    async def test_analyze_dataset_not_found(self):
        """Test dataset analysis with non-existent dataset"""
        handler = AnalysisHandler()
        
        with patch.object(handler, '_load_dataset') as mock_load:
            mock_load.return_value = (None, None)
            
            with pytest.raises(Exception):  # Should raise HTTPException
                await handler.analyze_dataset('nonexistent_id')
    
    @pytest.mark.asyncio
    async def test_get_column_analysis(self, sample_dataframe):
        """Test column-specific analysis"""
        handler = AnalysisHandler()
        
        with patch.object(handler, '_load_dataset') as mock_load, \
             patch.object(handler.data_analyzer, 'detect_column_type') as mock_detect_type, \
             patch.object(handler.data_analyzer, 'analyze_column') as mock_analyze_col:
            
            mock_load.return_value = (sample_dataframe, {'dataset_id': 'test'})
            mock_detect_type.return_value = 'numeric'
            mock_analyze_col.return_value = {
                'type': 'numeric',
                'mean': 5.5,
                'std': 3.0
            }
            
            result = await handler.get_column_analysis('test_id', 'numeric_col')
            
            assert result['dataset_id'] == 'test_id'
            assert result['column_name'] == 'numeric_col'
            assert 'analysis' in result
            assert 'insights' in result
    
    @pytest.mark.asyncio
    async def test_generate_column_chart(self, sample_dataframe):
        """Test chart generation for column"""
        handler = AnalysisHandler()
        
        with patch.object(handler, '_load_dataset') as mock_load, \
             patch.object(handler.data_analyzer, 'detect_column_type') as mock_detect_type, \
             patch.object(handler.chart_generator, 'select_optimal_chart') as mock_select_chart, \
             patch.object(handler.chart_generator, 'generate_chart') as mock_generate:
            
            mock_load.return_value = (sample_dataframe, {'dataset_id': 'test'})
            mock_detect_type.return_value = 'numeric'
            mock_select_chart.return_value = 'histogram'
            mock_generate.return_value = '/path/to/chart.png'
            
            result = await handler.generate_column_chart('test_id', 'numeric_col', 'auto')
            
            assert result['success'] is True
            assert result['chart_path'] == '/path/to/chart.png'
            assert result['chart_type'] == 'histogram'
    
    @pytest.mark.asyncio
    async def test_get_data_preview(self, sample_dataframe):
        """Test data preview functionality"""
        handler = AnalysisHandler()
        
        with patch.object(handler, '_load_dataset') as mock_load:
            mock_load.return_value = (sample_dataframe, {'dataset_id': 'test'})
            
            result = await handler.get_data_preview('test_id', ['numeric_col'], 5)
            
            assert result['dataset_id'] == 'test_id'
            assert 'preview_data' in result
            assert result['displayed_rows'] <= 5
            assert len(result['column_names']) == 1
    
    def test_load_dataset_success(self, sample_csv_file):
        """Test successful dataset loading"""
        handler = AnalysisHandler()
        
        # Mock storage manager
        with patch.object(handler.storage_manager, 'load_metadata') as mock_load_meta:
            mock_load_meta.return_value = {
                'dataset_id': 'test',
                'file_path': str(sample_csv_file),
                'filename': 'test.csv'
            }
            
            df, metadata = handler._load_dataset('test_id')
            
            assert df is not None
            assert len(df) > 0
            assert metadata is not None
    
    def test_load_dataset_not_found(self):
        """Test dataset loading with non-existent dataset"""
        handler = AnalysisHandler()
        
        with patch.object(handler.storage_manager, 'load_metadata') as mock_load_meta:
            mock_load_meta.return_value = None
            
            df, metadata = handler._load_dataset('nonexistent_id')
            
            assert df is None
            assert metadata is None


@pytest.mark.integration
class TestAnalysisIntegration:
    """Integration tests for analysis functionality"""
    
    @pytest.mark.asyncio
    async def test_complete_analysis_workflow(self, sample_dataframe):
        """Test complete analysis workflow"""
        analyzer = MLDataAnalyzer()
        
        # Perform complete analysis
        results = await analyzer.analyze_dataset(sample_dataframe)
        
        # Verify all components are present
        assert 'dataset_summary' in results
        assert 'column_analysis' in results
        assert 'insights' in results
        
        # Verify data quality
        summary = results['dataset_summary']
        assert summary['rows'] == len(sample_dataframe)
        assert summary['columns'] == len(sample_dataframe.columns)
        assert summary['null_percentage'] >= 0
        
        # Verify column analysis
        column_analysis = results['column_analysis']
        for col in sample_dataframe.columns:
            assert col in column_analysis
            assert 'type' in column_analysis[col]
            assert 'null_percentage' in column_analysis[col]
        
        # Verify insights
        insights = results['insights']
        assert isinstance(insights, list)
        assert len(insights) >= 0
    
    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_large_dataset_analysis(self, large_dataset_file):
        """Test analysis with large dataset"""
        analyzer = MLDataAnalyzer()
        
        # Load large dataset
        df = pd.read_csv(large_dataset_file)
        
        # Should handle large dataset efficiently
        results = await analyzer.analyze_dataset(df)
        
        assert 'dataset_summary' in results
        assert results['dataset_summary']['rows'] == len(df)
        
        # Check that analysis completed for all columns
        column_analysis = results['column_analysis']
        assert len(column_analysis) == len(df.columns)
