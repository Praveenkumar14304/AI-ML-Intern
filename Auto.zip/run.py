#!/usr/bin/env python3
"""
AI/ML Data to PowerPoint Application Launcher
Enhanced with PII Override and Dynamic Preview Toggle
"""
import os
import sys
import subprocess
import threading
import time
import webbrowser
from pathlib import Path

def setup_directories():
    """Create necessary directories for local storage"""
    directories = [
        "data/uploads",
        "data/generated", 
        "data/charts",
        "data/thumbnails",
        "data/history",
        "logs"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
    
    print("✅ Local storage directories created")

def start_backend():
    """Start FastAPI backend server"""
    print("🚀 Starting FastAPI backend on http://127.0.0.1:8000")
    try:
        import uvicorn
        uvicorn.run(
            "backend.main:app",
            host="127.0.0.1",
            port=8000,
            reload=False,
            log_level="info"
        )
    except Exception as e:
        print(f"❌ Backend startup failed: {e}")

def start_frontend():
    """Start Streamlit frontend"""
    print("🎨 Starting Streamlit frontend on http://127.0.0.1:8501")
    
    time.sleep(3)  # Wait for backend
    
    try:
        subprocess.run([
            sys.executable, "-m", "streamlit", "run", 
            "frontend/app.py",
            "--server.port", "8501",
            "--server.headless", "false"
        ])
    except Exception as e:
        print(f"❌ Frontend startup failed: {e}")

def main():
    """Main application launcher"""
    print("🤖 AI/ML Data to PowerPoint Application")
    print("=" * 60)
    print("Enhanced with PII Override & Dynamic Preview Toggle")
    print("=" * 60)
    
    setup_directories()
    
    # Start backend in thread
    backend_thread = threading.Thread(target=start_backend, daemon=True)
    backend_thread.start()
    
    # Wait and open browser
    time.sleep(5)
    webbrowser.open("http://localhost:8501")
    
    # Start frontend (blocking)
    start_frontend()

if __name__ == "__main__":
    main()
