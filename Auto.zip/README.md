# 🤖 AI/ML Data to PowerPoint Generator

## Enhanced Production-Ready Application

Transform your data into professional presentations with advanced AI/ML analysis, featuring enhanced PII protection and dynamic preview capabilities.

### ✨ Key Features

#### 🛡️ Enhanced PII Protection
- **Auto-detection** with multiple methods (keyword, pattern, statistical)
- **Manual override** options for false positives
- **Detailed explanations** for each removal decision
- **Confidence scoring** for detection accuracy

#### 📊 Dynamic Dataset Preview
- **Toggle view** between all columns and selected columns
- **Real-time updates** based on column selection
- **Enhanced metadata** display with statistics
- **Quick analysis** preview for insights

#### 🎨 Professional Theme
- **Black/Orange/White** corporate styling
- **Responsive design** for all screen sizes
- **Modern animations** and hover effects
- **Accessible UI** with proper contrast

#### 🤖 AI/ML Analysis Engine
- **Advanced statistical analysis** with outlier detection
- **Intelligent chart selection** based on data characteristics
- **Automated insight generation** using ML algorithms
- **Professional visualization** with themed charts

### 🚀 Quick Start

1. **Install Dependencies**
pip install -r requirements.txt
pyth

2. **Run Application**
python run.py

3. **Access Application**
   - Frontend: http://localhost:8501
   - Backend API: http://localhost:8000

### 📁 Project Structure


### 🔧 Usage Workflow

1. **Upload Data** - Drag and drop CSV/Excel files
2. **Review PII Detection** - Check auto-removed columns, override if needed
3. **Select Columns** - Choose analysis columns with dynamic preview
4. **Configure Template** - Set story mode, theme, and customizations
5. **Generate & Preview** - Create presentation and review slides
6. **Export** - Download as PowerPoint (.pptx) or PDF format

### 🛡️ Security Features

- **Local storage only** - No data leaves your machine
- **Advanced PII detection** - Multiple detection methods
- **Override capabilities** - Manual control over privacy decisions
- **Audit logging** - Track all data processing activities

### 🔧 Troubleshooting

**Port already in use:**
pkill -f "uvicorn"
p

**Missing dependencies:**
pip install --upgrade pip
pip install -r requirem


**spaCy model issues:**
python -m spacy download en_core_web_sm --force


---

**🚀 Ready to transform your data into professional presentations!**

