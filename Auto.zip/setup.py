from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="aiml-data-to-ppt",
    version="2.0.0",
    author="AI/ML Team",
    author_email="team@aiml-ppt.com",
    description="AI/ML powered data to PowerPoint presentation generator",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/aiml-team/data-to-ppt",
    project_urls={
        "Bug Tracker": "https://github.com/aiml-team/data-to-ppt/issues",
        "Documentation": "https://github.com/aiml-team/data-to-ppt/wiki",
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Business",
        "Topic :: Office/Business :: Office Suites",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "streamlit>=1.28.1",
        "fastapi>=0.104.1",
        "uvicorn>=0.24.0",
        "pandas>=2.1.3",
        "numpy>=1.24.3",
        "scikit-learn>=1.3.2",
        "matplotlib>=3.8.2",
        "seaborn>=0.13.0",
        "python-pptx>=0.6.23",
        "textblob>=0.17.1",
        "spacy>=3.7.2",
        "wordcloud>=1.9.2",
        "openpyxl>=3.1.2",
        "requests>=2.31.0",
        "python-multipart>=0.0.6",
        "python-dotenv>=1.0.0",
        "pydantic>=2.5.0",
        "Pillow>=10.1.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.3",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.5.0",
        ],
        "test": [
            "pytest>=7.4.3",
            "pytest-cov>=4.1.0",
            "pytest-mock>=3.11.1",
        ],
    },
    entry_points={
        "console_scripts": [
            "aiml-ppt=run:main",
        ],
    },
)
