"""
ML-powered data analysis engine with advanced statistical capabilities
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from scipy import stats
from typing import Dict, List, Any, Tuple
import warnings
warnings.filterwarnings('ignore')

class MLDataAnalyzer:
    """Advanced ML-powered data analysis with statistical insights"""
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.analysis_results = {}
    
    async def initialize_models(self):
        """Initialize ML models and components"""
        print("🤖 ML Data Analyzer initialized")
    
    def analyze_dataset(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Perform comprehensive ML analysis on dataset"""
        
        results = {
            'dataset_summary': self._get_dataset_summary(df),
            'column_analysis': {},
            'correlations': {},
            'clusters': {},
            'anomalies': {},
            'insights': []
        }
        
        # Analyze each column
        for col in df.columns:
            col_type = self.detect_column_type(df[col])
            results['column_analysis'][col] = self.analyze_column(df[col], col_type)
        
        # Advanced analysis for numeric columns
        numeric_cols = [col for col in df.columns if pd.api.types.is_numeric_dtype(df[col])]
        if len(numeric_cols) > 1:
            results['correlations'] = self.calculate_correlations(df[numeric_cols])
            results['clusters'] = self.perform_clustering(df[numeric_cols])
            results['anomalies'] = self.detect_anomalies(df[numeric_cols])
        
        # Generate insights
        results['insights'] = self.generate_insights(results)
        
        return results
    
    def detect_column_type(self, series: pd.Series) -> str:
        """Enhanced column type detection"""
        
        # Remove nulls for analysis
        clean_series = series.dropna()
        
        if len(clean_series) == 0:
            return 'empty'
        
        # Check if datetime
        if pd.api.types.is_datetime64_any_dtype(series):
            return 'datetime'
        
        # Try parsing as datetime
        try:
            pd.to_datetime(clean_series.head(10), errors='raise')
            return 'datetime'
        except:
            pass
        
        # Check if numeric
        if pd.api.types.is_numeric_dtype(clean_series):
            # Determine if continuous or categorical
            unique_ratio = clean_series.nunique() / len(clean_series)
            if unique_ratio < 0.05 and clean_series.nunique() < 20:
                return 'categorical_numeric'
            elif clean_series.dtype in ['int64', 'int32'] and unique_ratio < 0.1:
                return 'ordinal'
            else:
                return 'numeric'
        
        # Check if boolean
        unique_vals = set(clean_series.astype(str).str.lower().unique())
        if unique_vals.issubset({'true', 'false', '1', '0', 'yes', 'no', 't', 'f'}):
            return 'boolean'
        
        # Check text characteristics
        if clean_series.dtype == 'object':
            avg_length = clean_series.astype(str).str.len().mean()
            has_spaces = clean_series.astype(str).str.contains(' ').sum() / len(clean_series) > 0.3
            
            if avg_length > 50 and has_spaces:
                return 'text_long'
            elif avg_length > 15 and has_spaces:
                return 'text_medium'
            elif clean_series.nunique() / len(clean_series) > 0.8:
                return 'text_unique'
            else:
                return 'categorical'
        
        return 'categorical'
    
    def analyze_column(self, series: pd.Series, col_type: str) -> Dict[str, Any]:
        """Analyze individual column based on type"""
        
        analysis = {
            'type': col_type,
            'count': len(series),
            'null_count': series.isnull().sum(),
            'null_percentage': (series.isnull().sum() / len(series)) * 100,
            'unique_count': series.nunique(),
            'duplicate_count': len(series) - series.nunique(),
        }
        
        # Clean data for analysis
        clean_series = series.dropna()
        
        if len(clean_series) == 0:
            return analysis
        
        # Type-specific analysis
        if col_type in ['numeric', 'ordinal']:
            analysis.update(self._analyze_numeric_column(clean_series))
        elif col_type in ['categorical', 'categorical_numeric', 'boolean']:
            analysis.update(self._analyze_categorical_column(clean_series))
        elif col_type == 'datetime':
            analysis.update(self._analyze_datetime_column(clean_series))
        elif col_type in ['text_long', 'text_medium', 'text_unique']:
            analysis.update(self._analyze_text_column(clean_series))
        
        return analysis
    
    def _analyze_numeric_column(self, series: pd.Series) -> Dict[str, Any]:
        """Analyze numeric column with statistical measures"""
        
        try:
            return {
                'mean': float(series.mean()),
                'median': float(series.median()),
                'mode': float(series.mode().iloc[0]) if not series.mode().empty else None,
                'std': float(series.std()),
                'variance': float(series.var()),
                'min': float(series.min()),
                'max': float(series.max()),
                'range': float(series.max() - series.min()),
                'q1': float(series.quantile(0.25)),
                'q3': float(series.quantile(0.75)),
                'iqr': float(series.quantile(0.75) - series.quantile(0.25)),
                'skewness': float(series.skew()),
                'kurtosis': float(series.kurtosis()),
                'outliers_count': self._count_outliers(series),
                'distribution': self._analyze_distribution(series)
            }
        except Exception as e:
            return {'error': str(e)}
    
    def _analyze_categorical_column(self, series: pd.Series) -> Dict[str, Any]:
        """Analyze categorical column"""
        
        value_counts = series.value_counts()
        
        return {
            'top_value': str(value_counts.index[0]) if not value_counts.empty else None,
            'top_count': int(value_counts.iloc[0]) if not value_counts.empty else 0,
            'top_percentage': float((value_counts.iloc[0] / len(series)) * 100) if not value_counts.empty else 0,
            'categories': min(10, len(value_counts)),
            'entropy': self._calculate_entropy(value_counts),
            'concentration': float(value_counts.iloc[0] / value_counts.sum()) if not value_counts.empty else 0,
            'value_distribution': value_counts.head(10).to_dict()
        }
    
    def _analyze_datetime_column(self, series: pd.Series) -> Dict[str, Any]:
        """Analyze datetime column"""
        
        try:
            dt_series = pd.to_datetime(series)
            
            return {
                'min_date': str(dt_series.min()),
                'max_date': str(dt_series.max()),
                'date_range_days': (dt_series.max() - dt_series.min()).days,
                'most_common_year': int(dt_series.dt.year.mode().iloc[0]) if not dt_series.dt.year.mode().empty else None,
                'most_common_month': int(dt_series.dt.month.mode().iloc[0]) if not dt_series.dt.month.mode().empty else None,
                'most_common_day': int(dt_series.dt.day.mode().iloc[0]) if not dt_series.dt.day.mode().empty else None,
                'weekday_distribution': dt_series.dt.day_name().value_counts().to_dict(),
                'monthly_distribution': dt_series.dt.month_name().value_counts().to_dict()
            }
        except Exception as e:
            return {'error': str(e)}
    
    def _analyze_text_column(self, series: pd.Series) -> Dict[str, Any]:
        """Analyze text column"""
        
        text_series = series.astype(str)
        
        return {
            'avg_length': float(text_series.str.len().mean()),
            'min_length': int(text_series.str.len().min()),
            'max_length': int(text_series.str.len().max()),
            'total_words': int(text_series.str.split().str.len().sum()),
            'avg_words': float(text_series.str.split().str.len().mean()),
            'common_words': self._get_common_words(text_series),
            'language_detected': self._detect_language(text_series),
            'sentiment_score': self._analyze_sentiment(text_series)
        }
    
    def calculate_correlations(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Calculate correlations between numeric columns"""
        
        try:
            # Pearson correlation
            pearson_corr = df.corr(method='pearson')
            
            # Spearman correlation (rank-based)
            spearman_corr = df.corr(method='spearman')
            
            # Find strong correlations
            strong_correlations = []
            for i in range(len(pearson_corr.columns)):
                for j in range(i+1, len(pearson_corr.columns)):
                    col1, col2 = pearson_corr.columns[i], pearson_corr.columns[j]
                    pearson_val = pearson_corr.iloc[i, j]
                    spearman_val = spearman_corr.iloc[i, j]
                    
                    if abs(pearson_val) > 0.5:  # Strong correlation threshold
                        strong_correlations.append({
                            'column1': col1,
                            'column2': col2,
                            'pearson_correlation': float(pearson_val),
                            'spearman_correlation': float(spearman_val),
                            'strength': 'strong' if abs(pearson_val) > 0.7 else 'moderate'
                        })
            
            return {
                'pearson_matrix': pearson_corr.to_dict(),
                'spearman_matrix': spearman_corr.to_dict(),
                'strong_correlations': strong_correlations,
                'correlation_summary': {
                    'total_pairs': len(pearson_corr.columns) * (len(pearson_corr.columns) - 1) // 2,
                    'strong_correlations_count': len([c for c in strong_correlations if c['strength'] == 'strong']),
                    'moderate_correlations_count': len([c for c in strong_correlations if c['strength'] == 'moderate'])
                }
            }
        
        except Exception as e:
            return {'error': str(e)}
    
    def perform_clustering(self, df: pd.DataFrame, n_clusters: int = 3) -> Dict[str, Any]:
        """Perform K-means clustering on numeric data"""
        
        try:
            # Prepare data
            df_scaled = self.scaler.fit_transform(df.fillna(df.mean()))
            
            # Perform clustering
            kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
            cluster_labels = kmeans.fit_predict(df_scaled)
            
            # Calculate cluster characteristics
            df_with_clusters = df.copy()
            df_with_clusters['cluster'] = cluster_labels
            
            cluster_stats = []
            for cluster_id in range(n_clusters):
                cluster_data = df_with_clusters[df_with_clusters['cluster'] == cluster_id]
                
                stats_dict = {
                    'cluster_id': cluster_id,
                    'size': len(cluster_data),
                    'percentage': (len(cluster_data) / len(df)) * 100,
                    'characteristics': {}
                }
                
                # Calculate mean for each feature in this cluster
                for col in df.columns:
                    stats_dict['characteristics'][col] = {
                        'mean': float(cluster_data[col].mean()),
                        'std': float(cluster_data[col].std())
                    }
                
                cluster_stats.append(stats_dict)
            
            return {
                'cluster_labels': cluster_labels.tolist(),
                'n_clusters': n_clusters,
                'cluster_centers': kmeans.cluster_centers_.tolist(),
                'inertia': float(kmeans.inertia_),
                'cluster_stats': cluster_stats
            }
        
        except Exception as e:
            return {'error': str(e)}
    
    def detect_anomalies(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Detect anomalies using statistical methods"""
        
        try:
            anomalies = {}
            
            for col in df.columns:
                series = df[col].dropna()
                
                # Z-score method
                z_scores = np.abs(stats.zscore(series))
                z_anomalies = np.where(z_scores > 3)[0].tolist()
                
                # IQR method
                Q1 = series.quantile(0.25)
                Q3 = series.quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                
                iqr_anomalies = series[(series < lower_bound) | (series > upper_bound)].index.tolist()
                
                anomalies[col] = {
                    'z_score_anomalies': len(z_anomalies),
                    'iqr_anomalies': len(iqr_anomalies),
                    'z_score_indices': z_anomalies[:10],  # Show first 10
                    'iqr_indices': iqr_anomalies[:10],    # Show first 10
                    'anomaly_percentage': (len(iqr_anomalies) / len(series)) * 100
                }
            
            return anomalies
        
        except Exception as e:
            return {'error': str(e)}
    
    def generate_insights(self, analysis_results: Dict[str, Any]) -> List[str]:
        """Generate business insights from analysis results"""
        
        insights = []
        
        # Dataset-level insights
        dataset_summary = analysis_results.get('dataset_summary', {})
        if dataset_summary.get('rows', 0) > 1000:
            insights.append(f"Large dataset with {dataset_summary['rows']:,} rows provides robust analysis foundation")
        
        # Column-level insights
        column_analysis = analysis_results.get('column_analysis', {})
        numeric_columns = [col for col, info in column_analysis.items() if info.get('type') == 'numeric']
        
        if len(numeric_columns) > 3:
            insights.append(f"Rich dataset with {len(numeric_columns)} numeric variables enables advanced statistical analysis")
        
        # Correlation insights
        correlations = analysis_results.get('correlations', {})
        strong_corr = correlations.get('strong_correlations', [])
        if strong_corr:
            insights.append(f"Found {len(strong_corr)} strong correlations indicating potential relationships between variables")
        
        # Data quality insights
        high_null_columns = [col for col, info in column_analysis.items() 
                           if info.get('null_percentage', 0) > 20]
        if high_null_columns:
            insights.append(f"Data quality attention needed: {len(high_null_columns)} columns have >20% missing values")
        
        # Anomaly insights
        anomalies = analysis_results.get('anomalies', {})
        if anomalies:
            high_anomaly_cols = [col for col, info in anomalies.items() 
                               if info.get('anomaly_percentage', 0) > 5]
            if high_anomaly_cols:
                insights.append(f"Anomaly detection identified unusual patterns in {len(high_anomaly_cols)} variables")
        
        return insights
    
    def _get_dataset_summary(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Get high-level dataset summary"""
        
        return {
            'rows': len(df),
            'columns': len(df.columns),
            'memory_usage_mb': df.memory_usage(deep=True).sum() / 1024 / 1024,
            'total_null_values': df.isnull().sum().sum(),
            'null_percentage': (df.isnull().sum().sum() / (len(df) * len(df.columns))) * 100,
            'numeric_columns': len(df.select_dtypes(include=[np.number]).columns),
            'categorical_columns': len(df.select_dtypes(include=['object']).columns),
            'datetime_columns': len(df.select_dtypes(include=['datetime']).columns)
        }
    
    def _count_outliers(self, series: pd.Series) -> int:
        """Count outliers using IQR method"""
        Q1 = series.quantile(0.25)
        Q3 = series.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        return len(series[(series < lower_bound) | (series > upper_bound)])
    
    def _analyze_distribution(self, series: pd.Series) -> str:
        """Analyze distribution shape"""
        skewness = series.skew()
        kurtosis = series.kurtosis()
        
        if abs(skewness) < 0.5:
            skew_desc = "approximately symmetric"
        elif skewness > 0.5:
            skew_desc = "right-skewed"
        else:
            skew_desc = "left-skewed"
        
        if kurtosis > 3:
            kurt_desc = "heavy-tailed"
        elif kurtosis < -1:
            kurt_desc = "light-tailed"
        else:
            kurt_desc = "normal-tailed"
        
        return f"{skew_desc}, {kurt_desc}"
    
    def _calculate_entropy(self, value_counts: pd.Series) -> float:
        """Calculate entropy for categorical distribution"""
        probabilities = value_counts / value_counts.sum()
        return float(-np.sum(probabilities * np.log2(probabilities + 1e-10)))
    
    def _get_common_words(self, text_series: pd.Series) -> List[str]:
        """Get most common words from text"""
        try:
            from collections import Counter
            all_text = ' '.join(text_series.astype(str))
            words = all_text.lower().split()
            # Filter out common stop words
            stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'}
            filtered_words = [word for word in words if word not in stop_words and len(word) > 2]
            return [word for word, count in Counter(filtered_words).most_common(10)]
        except:
            return []
    
    def _detect_language(self, text_series: pd.Series) -> str:
        """Simple language detection"""
        try:
            sample_text = ' '.join(text_series.head(10).astype(str))
            # Simple heuristic - could be enhanced with proper language detection
            if len(sample_text) > 50:
                return "english"  # Default assumption
            return "unknown"
        except:
            return "unknown"
    
    def _analyze_sentiment(self, text_series: pd.Series) -> float:
        """Basic sentiment analysis"""
        try:
            from textblob import TextBlob
            sentiments = []
            for text in text_series.head(100):  # Sample first 100 for performance
                blob = TextBlob(str(text))
                sentiments.append(blob.sentiment.polarity)
            return float(np.mean(sentiments)) if sentiments else 0.0
        except:
            return 0.0
    
    def health_check(self) -> bool:
        """Health check for data analyzer"""
        return True
