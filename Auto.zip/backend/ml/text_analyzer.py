"""
Text Analysis Module for NLP tasks
"""
import pandas as pd
import numpy as np
from typing import List, Dict, Any
import re
from collections import Counter

class TextAnalyzer:
    """Analyzes text data for insights and patterns"""
    
    def __init__(self):
        self.stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 
            'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 
            'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
            'will', 'would', 'could', 'should', 'may', 'might', 'must',
            'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 
            'it', 'we', 'they', 'me', 'him', 'her', 'us', 'them'
        }
    
    def analyze_text_column(self, series: pd.Series) -> Dict[str, Any]:
        """Comprehensive text analysis"""
        
        text_data = series.dropna().astype(str)
        
        analysis = {
            'basic_stats': self._get_basic_text_stats(text_data),
            'word_analysis': self._analyze_words(text_data),
            'sentiment_analysis': self._analyze_sentiment(text_data),
            'pattern_analysis': self._analyze_patterns(text_data),
            'language_detection': self._detect_language(text_data)
        }
        
        return analysis
    
    def _get_basic_text_stats(self, text_data: pd.Series) -> Dict[str, Any]:
        """Get basic text statistics"""
        
        lengths = text_data.str.len()
        word_counts = text_data.str.split().str.len()
        
        return {
            'total_texts': len(text_data),
            'total_characters': int(lengths.sum()),
            'avg_length': float(lengths.mean()),
            'median_length': float(lengths.median()),
            'min_length': int(lengths.min()),
            'max_length': int(lengths.max()),
            'total_words': int(word_counts.sum()),
            'avg_words': float(word_counts.mean()),
            'median_words': float(word_counts.median()),
            'empty_texts': int((lengths == 0).sum()),
            'unique_texts': int(text_data.nunique())
        }
    
    def _analyze_words(self, text_data: pd.Series) -> Dict[str, Any]:
        """Analyze word patterns and frequency"""
        
        # Combine all text
        all_text = ' '.join(text_data.tolist()).lower()
        
        # Clean and tokenize
        words = re.findall(r'\b[a-zA-Z]+\b', all_text)
        
        # Filter out stop words
        meaningful_words = [word for word in words 
                          if word not in self.stop_words and len(word) > 2]
        
        # Get word frequency
        word_freq = Counter(meaningful_words)
        
        return {
            'total_words': len(words),
            'unique_words': len(set(words)),
            'meaningful_words': len(meaningful_words),
            'vocabulary_diversity': len(set(meaningful_words)) / len(meaningful_words) if meaningful_words else 0,
            'most_common_words': dict(word_freq.most_common(20)),
            'avg_word_length': np.mean([len(word) for word in meaningful_words]) if meaningful_words else 0
        }
    
    def _analyze_sentiment(self, text_data: pd.Series) -> Dict[str, Any]:
        """Basic sentiment analysis"""
        
        try:
            from textblob import TextBlob
            
            sentiments = []
            for text in text_data.head(100):  # Sample for performance
                blob = TextBlob(str(text))
                sentiments.append({
                    'polarity': blob.sentiment.polarity,
                    'subjectivity': blob.sentiment.subjectivity
                })
            
            polarities = [s['polarity'] for s in sentiments]
            subjectivities = [s['subjectivity'] for s in sentiments]
            
            # Classify sentiments
            positive = sum(1 for p in polarities if p > 0.1)
            negative = sum(1 for p in polarities if p < -0.1)
            neutral = len(polarities) - positive - negative
            
            return {
                'avg_polarity': float(np.mean(polarities)),
                'avg_subjectivity': float(np.mean(subjectivities)),
                'sentiment_distribution': {
                    'positive': positive,
                    'negative': negative,
                    'neutral': neutral,
                    'positive_pct': (positive / len(polarities)) * 100,
                    'negative_pct': (negative / len(polarities)) * 100,
                    'neutral_pct': (neutral / len(polarities)) * 100
                }
            }
        
        except ImportError:
            # Fallback simple sentiment analysis
            return self._simple_sentiment_analysis(text_data)
    
    def _simple_sentiment_analysis(self, text_data: pd.Series) -> Dict[str, Any]:
        """Simple rule-based sentiment analysis"""
        
        positive_words = {
            'good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic',
            'love', 'like', 'enjoy', 'happy', 'pleased', 'satisfied',
            'best', 'perfect', 'awesome', 'brilliant', 'outstanding'
        }
        
        negative_words = {
            'bad', 'terrible', 'awful', 'horrible', 'hate', 'dislike',
            'angry', 'frustrated', 'disappointed', 'worst', 'poor',
            'annoying', 'useless', 'boring', 'confusing', 'difficult'
        }
        
        sentiments = []
        
        for text in text_data.head(100):
            words = set(re.findall(r'\b[a-zA-Z]+\b', str(text).lower()))
            
            pos_count = len(words.intersection(positive_words))
            neg_count = len(words.intersection(negative_words))
            
            if pos_count > neg_count:
                sentiment = 'positive'
            elif neg_count > pos_count:
                sentiment = 'negative'
            else:
                sentiment = 'neutral'
            
            sentiments.append(sentiment)
        
        sentiment_counts = Counter(sentiments)
        total = len(sentiments)
        
        return {
            'sentiment_distribution': {
                'positive': sentiment_counts.get('positive', 0),
                'negative': sentiment_counts.get('negative', 0),
                'neutral': sentiment_counts.get('neutral', 0),
                'positive_pct': (sentiment_counts.get('positive', 0) / total) * 100,
                'negative_pct': (sentiment_counts.get('negative', 0) / total) * 100,
                'neutral_pct': (sentiment_counts.get('neutral', 0) / total) * 100
            }
        }
    
    def _analyze_patterns(self, text_data: pd.Series) -> Dict[str, Any]:
        """Analyze text patterns"""
        
        pattern_analysis = {}
        
        # Email patterns
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails_found = sum(1 for text in text_data if re.search(email_pattern, str(text)))
        
        # Phone patterns
        phone_pattern = r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'
        phones_found = sum(1 for text in text_data if re.search(phone_pattern, str(text)))
        
        # URL patterns
        url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        urls_found = sum(1 for text in text_data if re.search(url_pattern, str(text)))
        
        # Number patterns
        number_pattern = r'\b\d+\b'
        texts_with_numbers = sum(1 for text in text_data if re.search(number_pattern, str(text)))
        
        # Capitalization patterns
        all_caps = sum(1 for text in text_data if str(text).isupper() and len(str(text)) > 2)
        all_lower = sum(1 for text in text_data if str(text).islower() and len(str(text)) > 2)
        
        return {
            'emails_detected': emails_found,
            'phones_detected': phones_found,
            'urls_detected': urls_found,
            'texts_with_numbers': texts_with_numbers,
            'all_caps_texts': all_caps,
            'all_lower_texts': all_lower,
            'special_characters': self._count_special_characters(text_data)
        }
    
    def _count_special_characters(self, text_data: pd.Series) -> Dict[str, int]:
        """Count special characters in text"""
        
        special_chars = {'!', '?', '@', '#', '$', '%', '&', '*'}
        char_counts = Counter()
        
        for text in text_data:
            for char in str(text):
                if char in special_chars:
                    char_counts[char] += 1
        
        return dict(char_counts.most_common(10))
    
    def _detect_language(self, text_data: pd.Series) -> Dict[str, Any]:
        """Simple language detection"""
        
        # Sample text for analysis
        sample_text = ' '.join(text_data.head(50).astype(str))
        
        # Simple heuristics for English detection
        english_indicators = {
            'the', 'and', 'or', 'a', 'an', 'is', 'are', 'was', 'were',
            'this', 'that', 'with', 'for', 'from', 'they', 'have'
        }
        
        words = set(re.findall(r'\b[a-zA-Z]+\b', sample_text.lower()))
        english_matches = len(words.intersection(english_indicators))
        
        # Determine likely language
        if english_matches >= 5:
            likely_language = 'english'
            confidence = min(0.95, english_matches / 10)
        else:
            likely_language = 'unknown'
            confidence = 0.5
        
        return {
            'detected_language': likely_language,
            'confidence': confidence,
            'total_words_analyzed': len(words),
            'english_indicators_found': english_matches
        }
    
    def extract_keywords(self, text_data: pd.Series, max_keywords: int = 20) -> List[str]:
        """Extract keywords from text data"""
        
        # Combine all text
        all_text = ' '.join(text_data.astype(str).tolist()).lower()
        
        # Clean and tokenize
        words = re.findall(r'\b[a-zA-Z]+\b', all_text)
        
        # Filter meaningful words
        meaningful_words = [
            word for word in words 
            if word not in self.stop_words 
            and len(word) > 3 
            and word.isalpha()
        ]
        
        # Get frequency and return top keywords
        word_freq = Counter(meaningful_words)
        return [word for word, count in word_freq.most_common(max_keywords)]
    
    def generate_text_summary(self, analysis_results: Dict[str, Any]) -> List[str]:
        """Generate summary insights from text analysis"""
        
        insights = []
        
        basic_stats = analysis_results.get('basic_stats', {})
        word_analysis = analysis_results.get('word_analysis', {})
        sentiment = analysis_results.get('sentiment_analysis', {})
        
        # Basic statistics insights
        if basic_stats.get('avg_length', 0) > 100:
            insights.append("Text entries are relatively long, suggesting detailed content")
        elif basic_stats.get('avg_length', 0) < 20:
            insights.append("Text entries are short, possibly labels or categories")
        
        # Vocabulary insights
        diversity = word_analysis.get('vocabulary_diversity', 0)
        if diversity > 0.7:
            insights.append("High vocabulary diversity indicates rich, varied content")
        elif diversity < 0.3:
            insights.append("Low vocabulary diversity suggests repetitive or standardized content")
        
        # Sentiment insights
        sentiment_dist = sentiment.get('sentiment_distribution', {})
        if sentiment_dist.get('positive_pct', 0) > 60:
            insights.append("Overall sentiment is predominantly positive")
        elif sentiment_dist.get('negative_pct', 0) > 60:
            insights.append("Overall sentiment is predominantly negative")
        else:
            insights.append("Sentiment distribution is balanced across positive, negative, and neutral")
        
        return insights
