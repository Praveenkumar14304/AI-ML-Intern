"""
AI-Powered Insights Generator
Generates intelligent business insights from data analysis results
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Tuple, Optional
from datetime import datetime
import re
from collections import Counter
from ..utils.logger import setup_logger

logger = setup_logger(__name__)

class InsightsGenerator:
    """Generates AI-powered insights from analysis results"""
    
    def __init__(self):
        self.insight_templates = {
            'data_quality': {
                'high': "Excellent data quality with {completeness:.1f}% completeness enables reliable analysis",
                'medium': "Good data quality ({completeness:.1f}% complete) with some areas for improvement",
                'low': "Data quality concerns detected - {completeness:.1f}% completeness may impact analysis reliability"
            },
            'distribution': {
                'normal': "Variable '{column}' shows approximately normal distribution, suitable for parametric analysis",
                'skewed_right': "Variable '{column}' is right-skewed, indicating potential outliers or extreme values",
                'skewed_left': "Variable '{column}' is left-skewed, suggesting concentration at higher values",
                'uniform': "Variable '{column}' shows uniform distribution, indicating consistent spread of values"
            },
            'correlation': {
                'strong_positive': "Strong positive correlation ({correlation:.2f}) between '{col1}' and '{col2}' suggests direct relationship",
                'strong_negative': "Strong negative correlation ({correlation:.2f}) between '{col1}' and '{col2}' indicates inverse relationship",
                'moderate': "Moderate correlation ({correlation:.2f}) between '{col1}' and '{col2}' suggests potential dependency",
                'weak': "Weak correlation ({correlation:.2f}) between '{col1}' and '{col2}' indicates limited direct relationship"
            },
            'anomaly': {
                'high': "Significant anomalies detected in '{column}' ({count} outliers) require investigation",
                'medium': "Moderate number of outliers in '{column}' ({count}) may indicate data entry issues",
                'low': "Few outliers detected in '{column}' ({count}) within normal range for this data type"
            },
            'clustering': {
                'distinct': "{clusters} distinct clusters identified, suggesting natural groupings in the data",
                'overlap': "Data clustering shows some overlap, indicating gradual transitions between groups",
                'concentrated': "Data points are highly concentrated, suggesting homogeneous population"
            },
            'business_impact': {
                'growth': "Analysis reveals growth opportunities in {area} with potential {impact}% improvement",
                'risk': "Risk factors identified in {area} requiring mitigation strategies",
                'optimization': "Optimization opportunities detected that could improve {metric} by {improvement}%",
                'trend': "Trending patterns in {area} suggest {direction} movement over time"
            }
        }
        
        self.insight_categories = {
            'data_quality': 'Data Quality Assessment',
            'statistical': 'Statistical Analysis',
            'patterns': 'Pattern Recognition',
            'relationships': 'Variable Relationships',
            'anomalies': 'Anomaly Detection',
            'business': 'Business Implications',
            'recommendations': 'Strategic Recommendations'
        }
    
    async def generate_insights(
        self, 
        analysis_results: Dict[str, Any], 
        config: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Generate comprehensive insights from analysis results"""
        
        try:
            insights = []
            story_mode = config.get('story_mode', 'executive')
            
            # Generate different types of insights
            insights.extend(self._generate_data_quality_insights(analysis_results))
            insights.extend(self._generate_statistical_insights(analysis_results))
            insights.extend(self._generate_pattern_insights(analysis_results))
            insights.extend(self._generate_relationship_insights(analysis_results))
            insights.extend(self._generate_anomaly_insights(analysis_results))
            insights.extend(self._generate_business_insights(analysis_results, story_mode))
            insights.extend(self._generate_recommendations(analysis_results, story_mode))
            
            # Rank and filter insights based on importance
            ranked_insights = self._rank_insights(insights, story_mode)
            
            # Limit insights based on configuration
            max_insights = config.get('max_insights', 15)
            final_insights = ranked_insights[:max_insights]
            
            logger.info(f"Generated {len(final_insights)} insights from {len(insights)} candidates")
            
            return final_insights
        
        except Exception as e:
            logger.error(f"Insight generation failed: {str(e)}")
            return []
    
    def _generate_data_quality_insights(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate data quality insights"""
        
        insights = []
        
        try:
            dataset_summary = analysis_results.get('dataset_summary', {})
            column_analysis = analysis_results.get('column_analysis', {})
            
            # Overall data quality
            null_percentage = dataset_summary.get('null_percentage', 0)
            
            if null_percentage < 5:
                quality_level = 'high'
            elif null_percentage < 20:
                quality_level = 'medium'
            else:
                quality_level = 'low'
            
            insights.append({
                'category': 'data_quality',
                'type': 'overall_quality',
                'title': 'Data Quality Assessment',
                'insight': self.insight_templates['data_quality'][quality_level].format(
                    completeness=100 - null_percentage
                ),
                'confidence': 0.9,
                'impact': 'high' if quality_level == 'high' else 'medium',
                'metrics': {
                    'completeness': 100 - null_percentage,
                    'null_percentage': null_percentage
                }
            })
            
            # Column-specific quality insights
            high_null_columns = []
            for column, col_data in column_analysis.items():
                col_null_pct = col_data.get('null_percentage', 0)
                if col_null_pct > 30:
                    high_null_columns.append((column, col_null_pct))
            
            if high_null_columns:
                insights.append({
                    'category': 'data_quality',
                    'type': 'column_quality',
                    'title': 'Data Completeness Issues',
                    'insight': f"Significant missing values detected in {len(high_null_columns)} columns, "
                              f"particularly '{high_null_columns[0][0]}' ({high_null_columns[0][1]:.1f}% missing)",
                    'confidence': 0.8,
                    'impact': 'medium',
                    'affected_columns': [col for col, _ in high_null_columns],
                    'metrics': {
                        'columns_affected': len(high_null_columns),
                        'highest_null_pct': max(pct for _, pct in high_null_columns)
                    }
                })
        
        except Exception as e:
            logger.error(f"Data quality insight generation failed: {str(e)}")
        
        return insights
    
    def _generate_statistical_insights(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate statistical insights"""
        
        insights = []
        
        try:
            column_analysis = analysis_results.get('column_analysis', {})
            
            for column, col_data in column_analysis.items():
                col_type = col_data.get('type')
                
                if col_type == 'numeric':
                    # Distribution insights
                    skewness = col_data.get('skewness', 0)
                    
                    if abs(skewness) < 0.5:
                        distribution_type = 'normal'
                    elif skewness > 0.5:
                        distribution_type = 'skewed_right'
                    else:
                        distribution_type = 'skewed_left'
                    
                    insights.append({
                        'category': 'statistical',
                        'type': 'distribution',
                        'title': f'{column} Distribution Analysis',
                        'insight': self.insight_templates['distribution'][distribution_type].format(
                            column=column
                        ),
                        'confidence': 0.8,
                        'impact': 'medium',
                        'affected_columns': [column],
                        'metrics': {
                            'skewness': skewness,
                            'distribution_type': distribution_type,
                            'mean': col_data.get('mean'),
                            'median': col_data.get('median'),
                            'std': col_data.get('std')
                        }
                    })
                    
                    # Variability insights
                    mean = col_data.get('mean', 0)
                    std = col_data.get('std', 0)
                    
                    if mean != 0:
                        cv = abs(std / mean)  # Coefficient of variation
                        
                        if cv > 1:
                            insights.append({
                                'category': 'statistical',
                                'type': 'variability',
                                'title': f'{column} Variability Analysis',
                                'insight': f"High variability in '{column}' (CV={cv:.2f}) indicates significant spread in values",
                                'confidence': 0.7,
                                'impact': 'medium',
                                'affected_columns': [column],
                                'metrics': {
                                    'coefficient_of_variation': cv,
                                    'variability_level': 'high' if cv > 1.5 else 'moderate'
                                }
                            })
                
                elif col_type in ['categorical', 'categorical_numeric']:
                    # Categorical distribution insights
                    concentration = col_data.get('concentration', 0)
                    unique_count = col_data.get('unique_count', 0)
                    
                    if concentration > 0.7:
                        insights.append({
                            'category': 'statistical',
                            'type': 'categorical_concentration',
                            'title': f'{column} Category Distribution',
                            'insight': f"High concentration in '{column}' with {concentration:.1%} of values in top category, "
                                      f"indicating low diversity across {unique_count} categories",
                            'confidence': 0.8,
                            'impact': 'medium',
                            'affected_columns': [column],
                            'metrics': {
                                'concentration': concentration,
                                'unique_categories': unique_count,
                                'diversity_level': 'low' if concentration > 0.8 else 'moderate'
                            }
                        })
        
        except Exception as e:
            logger.error(f"Statistical insight generation failed: {str(e)}")
        
        return insights
    
    def _generate_pattern_insights(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate pattern recognition insights"""
        
        insights = []
        
        try:
            column_analysis = analysis_results.get('column_analysis', {})
            
            # Identify potential time series patterns
            datetime_columns = [col for col, data in column_analysis.items() 
                              if data.get('type') == 'datetime']
            
            if datetime_columns:
                for col in datetime_columns[:2]:  # Limit to 2 datetime columns
                    col_data = column_analysis[col]
                    date_range_days = col_data.get('date_range_days', 0)
                    
                    if date_range_days > 30:  # More than a month of data
                        insights.append({
                            'category': 'patterns',
                            'type': 'temporal',
                            'title': f'{col} Temporal Patterns',
                            'insight': f"Temporal data in '{col}' spans {date_range_days} days, enabling time series analysis "
                                      f"and trend identification",
                            'confidence': 0.7,
                            'impact': 'medium',
                            'affected_columns': [col],
                            'metrics': {
                                'date_range_days': date_range_days,
                                'min_date': col_data.get('min_date'),
                                'max_date': col_data.get('max_date')
                            }
                        })
            
            # Identify potential ID patterns
            high_uniqueness_columns = []
            for col, data in column_analysis.items():
                unique_count = data.get('unique_count', 0)
                total_count = data.get('count', 0)
                
                if total_count > 0:
                    uniqueness_ratio = unique_count / total_count
                    if uniqueness_ratio > 0.95 and unique_count > 100:
                        high_uniqueness_columns.append((col, uniqueness_ratio))
            
            if high_uniqueness_columns:
                top_unique_col = max(high_uniqueness_columns, key=lambda x: x[1])
                insights.append({
                    'category': 'patterns',
                    'type': 'identification',
                    'title': 'Identifier Pattern Detection',
                    'insight': f"Column '{top_unique_col[0]}' shows high uniqueness ({top_unique_col[1]:.1%}), "
                              f"likely serving as identifier or primary key",
                    'confidence': 0.8,
                    'impact': 'low',
                    'affected_columns': [col for col, _ in high_uniqueness_columns],
                    'metrics': {
                        'uniqueness_ratio': top_unique_col[1],
                        'potential_identifiers': len(high_uniqueness_columns)
                    }
                })
        
        except Exception as e:
            logger.error(f"Pattern insight generation failed: {str(e)}")
        
        return insights
    
    def _generate_relationship_insights(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate relationship insights"""
        
        insights = []
        
        try:
            correlations = analysis_results.get('correlations', {})
            strong_correlations = correlations.get('strong_correlations', [])
            
            for corr in strong_correlations[:5]:  # Top 5 correlations
                correlation_val = corr.get('pearson_correlation', 0)
                col1 = corr.get('column1')
                col2 = corr.get('column2')
                
                if abs(correlation_val) >= 0.7:
                    corr_type = 'strong_positive' if correlation_val > 0 else 'strong_negative'
                else:
                    corr_type = 'moderate'
                
                insights.append({
                    'category': 'relationships',
                    'type': 'correlation',
                    'title': f'{col1} - {col2} Relationship',
                    'insight': self.insight_templates['correlation'][corr_type].format(
                        correlation=correlation_val,
                        col1=col1,
                        col2=col2
                    ),
                    'confidence': 0.9,
                    'impact': 'high' if abs(correlation_val) >= 0.7 else 'medium',
                    'affected_columns': [col1, col2],
                    'metrics': {
                        'pearson_correlation': correlation_val,
                        'spearman_correlation': corr.get('spearman_correlation'),
                        'relationship_strength': corr.get('strength')
                    }
                })
            
            # Clustering insights
            clustering = analysis_results.get('clustering', {})
            if clustering and not clustering.get('error'):
                n_clusters = clustering.get('n_clusters', 0)
                cluster_stats = clustering.get('cluster_stats', [])
                
                if n_clusters > 1 and cluster_stats:
                    # Analyze cluster separation
                    cluster_sizes = [stat['size'] for stat in cluster_stats]
                    size_std = np.std(cluster_sizes)
                    size_mean = np.mean(cluster_sizes)
                    
                    if size_std / size_mean < 0.5:  # Relatively balanced clusters
                        cluster_type = 'distinct'
                    else:
                        cluster_type = 'overlap'
                    
                    insights.append({
                        'category': 'relationships',
                        'type': 'clustering',
                        'title': 'Data Clustering Analysis',
                        'insight': self.insight_templates['clustering'][cluster_type].format(
                            clusters=n_clusters
                        ),
                        'confidence': 0.7,
                        'impact': 'medium',
                        'metrics': {
                            'n_clusters': n_clusters,
                            'cluster_balance': size_std / size_mean if size_mean > 0 else 0,
                            'largest_cluster_size': max(cluster_sizes),
                            'smallest_cluster_size': min(cluster_sizes)
                        }
                    })
        
        except Exception as e:
            logger.error(f"Relationship insight generation failed: {str(e)}")
        
        return insights
    
    def _generate_anomaly_insights(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate anomaly detection insights"""
        
        insights = []
        
        try:
            anomalies = analysis_results.get('anomalies', {})
            
            for column, anomaly_data in anomalies.items():
                if anomaly_data.get('error'):
                    continue
                
                anomaly_pct = anomaly_data.get('anomaly_percentage', 0)
                iqr_anomalies = anomaly_data.get('iqr_anomalies', 0)
                
                if anomaly_pct > 10:
                    anomaly_level = 'high'
                elif anomaly_pct > 5:
                    anomaly_level = 'medium'
                elif anomaly_pct > 0:
                    anomaly_level = 'low'
                else:
                    continue
                
                insights.append({
                    'category': 'anomalies',
                    'type': 'outlier_detection',
                    'title': f'{column} Anomaly Detection',
                    'insight': self.insight_templates['anomaly'][anomaly_level].format(
                        column=column,
                        count=iqr_anomalies
                    ),
                    'confidence': 0.8,
                    'impact': anomaly_level,
                    'affected_columns': [column],
                    'metrics': {
                        'anomaly_percentage': anomaly_pct,
                        'iqr_anomalies': iqr_anomalies,
                        'z_score_anomalies': anomaly_data.get('z_score_anomalies', 0)
                    }
                })
        
        except Exception as e:
            logger.error(f"Anomaly insight generation failed: {str(e)}")
        
        return insights
    
    def _generate_business_insights(
        self, 
        analysis_results: Dict[str, Any], 
        story_mode: str
    ) -> List[Dict[str, Any]]:
        """Generate business-focused insights"""
        
        insights = []
        
        try:
            column_analysis = analysis_results.get('column_analysis', {})
            correlations = analysis_results.get('correlations', {})
            
            # Business impact insights based on story mode
            if story_mode == 'executive':
                insights.extend(self._generate_executive_insights(analysis_results))
            elif story_mode == 'investor':
                insights.extend(self._generate_investor_insights(analysis_results))
            elif story_mode == 'analyst':
                insights.extend(self._generate_analyst_insights(analysis_results))
            else:
                insights.extend(self._generate_general_business_insights(analysis_results))
            
            # Revenue/performance related insights
            performance_columns = self._identify_performance_columns(column_analysis)
            
            for col in performance_columns:
                col_data = column_analysis[col]
                
                if col_data.get('type') == 'numeric':
                    mean_val = col_data.get('mean', 0)
                    std_val = col_data.get('std', 0)
                    
                    if std_val > 0 and mean_val > 0:
                        cv = std_val / mean_val
                        
                        if cv > 0.5:  # High variability
                            insights.append({
                                'category': 'business',
                                'type': 'performance_variability',
                                'title': f'{col} Performance Analysis',
                                'insight': f"High variability in '{col}' suggests opportunities for standardization "
                                          f"and performance optimization",
                                'confidence': 0.7,
                                'impact': 'high',
                                'affected_columns': [col],
                                'metrics': {
                                    'coefficient_variation': cv,
                                    'mean_value': mean_val,
                                    'optimization_potential': 'high'
                                }
                            })
        
        except Exception as e:
            logger.error(f"Business insight generation failed: {str(e)}")
        
        return insights
    
    def _generate_executive_insights(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate executive-focused insights"""
        
        insights = []
        
        # High-level strategic insights
        dataset_summary = analysis_results.get('dataset_summary', {})
        total_rows = dataset_summary.get('rows', 0)
        
        if total_rows > 10000:
            insights.append({
                'category': 'business',
                'type': 'strategic_overview',
                'title': 'Data-Driven Decision Making',
                'insight': f"Substantial dataset ({total_rows:,} records) provides robust foundation for "
                          f"strategic decision making and performance optimization",
                'confidence': 0.9,
                'impact': 'high',
                'metrics': {
                    'data_volume': total_rows,
                    'strategic_value': 'high'
                }
            })
        
        return insights
    
    def _generate_investor_insights(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate investor-focused insights"""
        
        insights = []
        
        # Growth and risk insights
        correlations = analysis_results.get('correlations', {})
        strong_correlations = correlations.get('strong_correlations', [])
        
        if strong_correlations:
            insights.append({
                'category': 'business',
                'type': 'growth_indicators',
                'title': 'Growth Factor Analysis',
                'insight': f"Identified {len(strong_correlations)} strong relationships between key variables, "
                          f"indicating predictable growth patterns and risk factors",
                'confidence': 0.8,
                'impact': 'high',
                'metrics': {
                    'strong_relationships': len(strong_correlations),
                    'predictability_score': 'high'
                }
            })
        
        return insights
    
    def _generate_analyst_insights(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate analyst-focused insights"""
        
        insights = []
        
        # Technical analysis insights
        column_analysis = analysis_results.get('column_analysis', {})
        numeric_columns = [col for col, data in column_analysis.items() 
                          if data.get('type') == 'numeric']
        
        if len(numeric_columns) >= 5:
            insights.append({
                'category': 'business',
                'type': 'analytical_depth',
                'title': 'Analytical Modeling Potential',
                'insight': f"Rich dataset with {len(numeric_columns)} numeric variables enables "
                          f"advanced predictive modeling and statistical analysis",
                'confidence': 0.9,
                'impact': 'high',
                'metrics': {
                    'numeric_variables': len(numeric_columns),
                    'modeling_potential': 'high'
                }
            })
        
        return insights
    
    def _generate_general_business_insights(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate general business insights"""
        
        insights = []
        
        # Data completeness business impact
        dataset_summary = analysis_results.get('dataset_summary', {})
        null_percentage = dataset_summary.get('null_percentage', 0)
        
        if null_percentage < 5:
            insights.append({
                'category': 'business',
                'type': 'operational_excellence',
                'title': 'Data Management Excellence',
                'insight': f"Exceptional data quality ({100-null_percentage:.1f}% complete) reflects "
                          f"strong operational processes and data governance",
                'confidence': 0.8,
                'impact': 'medium',
                'metrics': {
                    'data_quality_score': 100 - null_percentage,
                    'operational_maturity': 'high'
                }
            })
        
        return insights
    
    def _generate_recommendations(
        self, 
        analysis_results: Dict[str, Any], 
        story_mode: str
    ) -> List[Dict[str, Any]]:
        """Generate strategic recommendations"""
        
        recommendations = []
        
        try:
            # Data quality recommendations
            dataset_summary = analysis_results.get('dataset_summary', {})
            null_percentage = dataset_summary.get('null_percentage', 0)
            
            if null_percentage > 10:
                recommendations.append({
                    'category': 'recommendations',
                    'type': 'data_quality',
                    'title': 'Data Quality Improvement',
                    'insight': f"Implement data validation processes to reduce missing values from "
                              f"{null_percentage:.1f}% to <5% for improved analysis reliability",
                    'confidence': 0.9,
                    'impact': 'high',
                    'priority': 'high',
                    'actionable': True,
                    'metrics': {
                        'current_completeness': 100 - null_percentage,
                        'target_completeness': 95,
                        'improvement_potential': null_percentage - 5
                    }
                })
            
            # Correlation-based recommendations
            correlations = analysis_results.get('correlations', {})
            strong_correlations = correlations.get('strong_correlations', [])
            
            if strong_correlations:
                top_correlation = max(strong_correlations, 
                                    key=lambda x: abs(x.get('pearson_correlation', 0)))
                
                recommendations.append({
                    'category': 'recommendations',
                    'type': 'leverage_relationships',
                    'title': 'Leverage Variable Relationships',
                    'insight': f"Exploit strong relationship between '{top_correlation.get('column1')}' and "
                              f"'{top_correlation.get('column2')}' for predictive modeling and optimization",
                    'confidence': 0.8,
                    'impact': 'high',
                    'priority': 'medium',
                    'actionable': True,
                    'affected_columns': [top_correlation.get('column1'), top_correlation.get('column2')],
                    'metrics': {
                        'correlation_strength': abs(top_correlation.get('pearson_correlation', 0)),
                        'predictive_potential': 'high'
                    }
                })
            
            # Anomaly-based recommendations
            anomalies = analysis_results.get('anomalies', {})
            high_anomaly_columns = [
                col for col, data in anomalies.items() 
                if data.get('anomaly_percentage', 0) > 5 and not data.get('error')
            ]
            
            if high_anomaly_columns:
                recommendations.append({
                    'category': 'recommendations',
                    'type': 'anomaly_investigation',
                    'title': 'Investigate Data Anomalies',
                    'insight': f"Investigate outliers in {len(high_anomaly_columns)} variables "
                              f"to identify data entry errors or exceptional cases requiring attention",
                    'confidence': 0.7,
                    'impact': 'medium',
                    'priority': 'medium',
                    'actionable': True,
                    'affected_columns': high_anomaly_columns,
                    'metrics': {
                        'columns_with_anomalies': len(high_anomaly_columns),
                        'investigation_priority': 'medium'
                    }
                })
            
            # Story mode specific recommendations
            if story_mode == 'executive':
                recommendations.extend(self._generate_executive_recommendations(analysis_results))
            elif story_mode == 'investor':
                recommendations.extend(self._generate_investor_recommendations(analysis_results))
        
        except Exception as e:
            logger.error(f"Recommendation generation failed: {str(e)}")
        
        return recommendations
    
    def _generate_executive_recommendations(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate executive-level recommendations"""
        
        recommendations = []
        
        # Strategic data utilization
        recommendations.append({
            'category': 'recommendations',
            'type': 'strategic_data_utilization',
            'title': 'Strategic Data Initiative',
            'insight': "Establish data-driven KPI monitoring system based on identified patterns "
                      "to enable proactive decision making and performance optimization",
            'confidence': 0.8,
            'impact': 'high',
            'priority': 'high',
            'actionable': True,
            'metrics': {
                'implementation_complexity': 'medium',
                'expected_roi': 'high'
            }
        })
        
        return recommendations
    
    def _generate_investor_recommendations(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate investor-focused recommendations"""
        
        recommendations = []
        
        # Risk assessment recommendations
        recommendations.append({
            'category': 'recommendations',
            'type': 'risk_monitoring',
            'title': 'Risk Monitoring Framework',
            'insight': "Implement automated monitoring system for identified risk indicators "
                      "to provide early warning signals and protect investment value",
            'confidence': 0.8,
            'impact': 'high',
            'priority': 'high',
            'actionable': True,
            'metrics': {
                'risk_reduction_potential': 'high',
                'monitoring_automation': 'recommended'
            }
        })
        
        return recommendations
    
    def _identify_performance_columns(self, column_analysis: Dict[str, Any]) -> List[str]:
        """Identify columns likely related to performance metrics"""
        
        performance_keywords = [
            'revenue', 'sales', 'profit', 'income', 'cost', 'price', 'value',
            'performance', 'score', 'rating', 'efficiency', 'productivity',
            'growth', 'return', 'margin', 'conversion', 'volume', 'amount'
        ]
        
        performance_columns = []
        
        for column in column_analysis.keys():
            column_lower = column.lower()
            
            for keyword in performance_keywords:
                if keyword in column_lower:
                    performance_columns.append(column)
                    break
        
        return performance_columns
    
    def _rank_insights(
        self, 
        insights: List[Dict[str, Any]], 
        story_mode: str
    ) -> List[Dict[str, Any]]:
        """Rank insights by importance and relevance"""
        
        # Define weights based on story mode
        weights = {
            'executive': {
                'business': 0.4,
                'recommendations': 0.3,
                'data_quality': 0.2,
                'relationships': 0.1
            },
            'investor': {
                'business': 0.4,
                'relationships': 0.3,
                'recommendations': 0.2,
                'anomalies': 0.1
            },
            'analyst': {
                'statistical': 0.3,
                'relationships': 0.3,
                'patterns': 0.2,
                'anomalies': 0.2
            }
        }.get(story_mode, {
            'data_quality': 0.25,
            'relationships': 0.25,
            'business': 0.25,
            'recommendations': 0.25
        })
        
        # Calculate weighted scores
        for insight in insights:
            category = insight.get('category', 'other')
            confidence = insight.get('confidence', 0.5)
            impact_score = {'high': 1.0, 'medium': 0.7, 'low': 0.4}.get(
                insight.get('impact', 'medium'), 0.7
            )
            
            category_weight = weights.get(category, 0.1)
            
            # Calculate final score
            insight['score'] = confidence * impact_score * category_weight
            
            # Boost actionable recommendations
            if insight.get('actionable', False):
                insight['score'] *= 1.2
        
        # Sort by score (descending)
        return sorted(insights, key=lambda x: x.get('score', 0), reverse=True)
    
    def generate_insight_summary(self, insights: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary of insights"""
        
        summary = {
            'total_insights': len(insights),
            'categories': {},
            'impact_distribution': {'high': 0, 'medium': 0, 'low': 0},
            'actionable_count': 0,
            'top_insights': insights[:3] if len(insights) >= 3 else insights,
            'confidence_score': 0
        }
        
        # Count by category
        for insight in insights:
            category = insight.get('category', 'other')
            summary['categories'][category] = summary['categories'].get(category, 0) + 1
            
            # Count by impact
            impact = insight.get('impact', 'medium')
            summary['impact_distribution'][impact] += 1
            
            # Count actionable
            if insight.get('actionable', False):
                summary['actionable_count'] += 1
        
        # Calculate average confidence
        if insights:
            total_confidence = sum(insight.get('confidence', 0) for insight in insights)
            summary['confidence_score'] = total_confidence / len(insights)
        
        return summary
