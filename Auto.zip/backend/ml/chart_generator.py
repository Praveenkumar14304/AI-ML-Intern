"""
Intelligent Chart Generation with ML-based recommendations
"""
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Tuple
import warnings
warnings.filterwarnings('ignore')

# Set style
plt.style.use('default')
sns.set_palette("husl")

class ChartGenerator:
    """Generates charts with intelligent type selection based on data characteristics"""
    
    def __init__(self):
        self.chart_configs = {
            'corporate': {
                'primary_color': '#FF6600',
                'secondary_color': '#000000',
                'background_color': '#FFFFFF',
                'grid_color': '#F5F5F5',
                'text_color': '#1A1A1A'
            }
        }
        self.current_theme = 'corporate'
    
    def select_optimal_chart(self, series: pd.Series, col_type: str) -> str:
        """Select optimal chart type based on data characteristics"""
        
        if col_type == 'numeric':
            # For numeric data, choose based on distribution
            if series.nunique() > 20:
                return 'histogram'
            else:
                return 'bar'
        
        elif col_type in ['categorical', 'categorical_numeric']:
            unique_count = series.nunique()
            if unique_count <= 5:
                return 'pie'
            elif unique_count <= 15:
                return 'bar'
            else:
                return 'horizontal_bar'
        
        elif col_type == 'datetime':
            return 'line'
        
        elif col_type in ['text_long', 'text_medium']:
            return 'wordcloud'
        
        else:
            return 'bar'  # Default fallback
    
    def generate_chart(
        self, 
        data: pd.Series, 
        column_name: str, 
        chart_type: str, 
        save_path: str,
        **kwargs
    ) -> str:
        """Generate and save chart"""
        
        try:
            # Set up the plot
            plt.figure(figsize=(12, 8))
            
            # Apply theme
            self._apply_theme()
            
            # Generate specific chart type
            if chart_type == 'histogram':
                self._create_histogram(data, column_name, **kwargs)
            elif chart_type == 'bar':
                self._create_bar_chart(data, column_name, **kwargs)
            elif chart_type == 'horizontal_bar':
                self._create_horizontal_bar_chart(data, column_name, **kwargs)
            elif chart_type == 'pie':
                self._create_pie_chart(data, column_name, **kwargs)
            elif chart_type == 'line':
                self._create_line_chart(data, column_name, **kwargs)
            elif chart_type == 'scatter':
                self._create_scatter_plot(data, column_name, **kwargs)
            elif chart_type == 'box':
                self._create_box_plot(data, column_name, **kwargs)
            elif chart_type == 'wordcloud':
                self._create_wordcloud(data, column_name, **kwargs)
            else:
                self._create_bar_chart(data, column_name, **kwargs)  # Default
            
            # Apply final styling
            self._apply_final_styling(column_name, chart_type)
            
            # Save the chart
            plt.tight_layout()
            plt.savefig(save_path, dpi=300, bbox_inches='tight', 
                       facecolor='white', edgecolor='none')
            plt.close()
            
            return save_path
        
        except Exception as e:
            print(f"Error generating chart: {e}")
            plt.close()
            return None
    
    def generate_correlation_matrix(
        self, 
        df: pd.DataFrame, 
        save_path: str,
        **kwargs
    ) -> str:
        """Generate correlation matrix heatmap"""
        
        try:
            plt.figure(figsize=(12, 10))
            
            # Calculate correlation
            corr_matrix = df.corr()
            
            # Create heatmap
            mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
            
            sns.heatmap(
                corr_matrix,
                mask=mask,
                annot=True,
                cmap='RdYlBu_r',
                center=0,
                square=True,
                fmt='.2f',
                cbar_kws={'shrink': 0.8},
                linewidths=0.5
            )
            
            plt.title('Correlation Matrix', fontsize=16, fontweight='bold', pad=20)
            plt.tight_layout()
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            return save_path
        
        except Exception as e:
            print(f"Error generating correlation matrix: {e}")
            plt.close()
            return None
    
    def generate_distribution_comparison(
        self, 
        df: pd.DataFrame, 
        columns: List[str], 
        save_path: str
    ) -> str:
        """Generate distribution comparison chart"""
        
        try:
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))
            axes = axes.ravel()
            
            for i, col in enumerate(columns[:4]):
                if i < len(columns):
                    if pd.api.types.is_numeric_dtype(df[col]):
                        axes[i].hist(df[col].dropna(), bins=30, alpha=0.7, 
                                   color=self.chart_configs[self.current_theme]['primary_color'])
                        axes[i].set_title(f'Distribution of {col}')
                        axes[i].set_xlabel(col)
                        axes[i].set_ylabel('Frequency')
                    else:
                        value_counts = df[col].value_counts().head(10)
                        axes[i].bar(range(len(value_counts)), value_counts.values,
                                  color=self.chart_configs[self.current_theme]['primary_color'])
                        axes[i].set_title(f'Top Categories in {col}')
                        axes[i].set_xticks(range(len(value_counts)))
                        axes[i].set_xticklabels(value_counts.index, rotation=45)
                else:
                    axes[i].axis('off')
            
            plt.suptitle('Data Distribution Comparison', fontsize=16, fontweight='bold')
            plt.tight_layout()
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            return save_path
        
        except Exception as e:
            print(f"Error generating distribution comparison: {e}")
            plt.close()
            return None
    
    def _create_histogram(self, data: pd.Series, column_name: str, **kwargs):
        """Create histogram"""
        clean_data = data.dropna()
        
        bins = kwargs.get('bins', min(30, max(10, len(clean_data) // 20)))
        
        plt.hist(
            clean_data, 
            bins=bins,
            alpha=0.7,
            color=self.chart_configs[self.current_theme]['primary_color'],
            edgecolor='white',
            linewidth=0.5
        )
        
        # Add statistics
        mean_val = clean_data.mean()
        median_val = clean_data.median()
        
        plt.axvline(mean_val, color='red', linestyle='--', alpha=0.8, label=f'Mean: {mean_val:.2f}')
        plt.axvline(median_val, color='green', linestyle='--', alpha=0.8, label=f'Median: {median_val:.2f}')
        
        plt.legend()
        plt.xlabel(column_name)
        plt.ylabel('Frequency')
    
    def _create_bar_chart(self, data: pd.Series, column_name: str, **kwargs):
        """Create bar chart"""
        value_counts = data.value_counts().head(kwargs.get('top_n', 15))
        
        bars = plt.bar(
            range(len(value_counts)),
            value_counts.values,
            color=self.chart_configs[self.current_theme]['primary_color'],
            alpha=0.8,
            edgecolor='white',
            linewidth=0.5
        )
        
        # Add value labels on bars
        for bar in bars:
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                    f'{int(height)}', ha='center', va='bottom', fontweight='bold')
        
        plt.xticks(range(len(value_counts)), value_counts.index, rotation=45, ha='right')
        plt.xlabel(f'{column_name} Categories')
        plt.ylabel('Count')
    
    def _create_horizontal_bar_chart(self, data: pd.Series, column_name: str, **kwargs):
        """Create horizontal bar chart"""
        value_counts = data.value_counts().head(kwargs.get('top_n', 15))
        
        bars = plt.barh(
            range(len(value_counts)),
            value_counts.values,
            color=self.chart_configs[self.current_theme]['primary_color'],
            alpha=0.8,
            edgecolor='white',
            linewidth=0.5
        )
        
        # Add value labels
        for i, bar in enumerate(bars):
            width = bar.get_width()
            plt.text(width + width*0.01, bar.get_y() + bar.get_height()/2.,
                    f'{int(width)}', ha='left', va='center', fontweight='bold')
        
        plt.yticks(range(len(value_counts)), value_counts.index)
        plt.xlabel('Count')
        plt.ylabel(f'{column_name} Categories')
    
    def _create_pie_chart(self, data: pd.Series, column_name: str, **kwargs):
        """Create pie chart"""
        value_counts = data.value_counts().head(kwargs.get('top_n', 8))
        
        # Create color palette
        colors = plt.cm.Set3(np.linspace(0, 1, len(value_counts)))
        
        wedges, texts, autotexts = plt.pie(
            value_counts.values,
            labels=value_counts.index,
            autopct='%1.1f%%',
            colors=colors,
            startangle=90,
            explode=[0.05] * len(value_counts)
        )
        
        # Style the text
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
        
        plt.axis('equal')
    
    def _create_line_chart(self, data: pd.Series, column_name: str, **kwargs):
        """Create line chart (for time series or ordered data)"""
        
        if pd.api.types.is_datetime64_any_dtype(data):
            # Time series
            data_sorted = data.sort_values()
            plt.plot(data_sorted.index, data_sorted.values, 
                    color=self.chart_configs[self.current_theme]['primary_color'],
                    linewidth=2, marker='o', markersize=4, alpha=0.8)
            plt.xlabel('Time')
        else:
            # Regular line chart
            plt.plot(data.values, 
                    color=self.chart_configs[self.current_theme]['primary_color'],
                    linewidth=2, marker='o', markersize=4, alpha=0.8)
            plt.xlabel('Index')
        
        plt.ylabel(column_name)
    
    def _create_scatter_plot(self, data: pd.Series, column_name: str, **kwargs):
        """Create scatter plot"""
        y_data = kwargs.get('y_data', range(len(data)))
        
        plt.scatter(
            data, y_data,
            color=self.chart_configs[self.current_theme]['primary_color'],
            alpha=0.6, s=50, edgecolors='white', linewidth=0.5
        )
        
        plt.xlabel(column_name)
        plt.ylabel(kwargs.get('y_label', 'Index'))
    
    def _create_box_plot(self, data: pd.Series, column_name: str, **kwargs):
        """Create box plot"""
        
        box_plot = plt.boxplot(
            data.dropna(),
            patch_artist=True,
            boxprops=dict(facecolor=self.chart_configs[self.current_theme]['primary_color'], alpha=0.7),
            medianprops=dict(color='red', linewidth=2)
        )
        
        plt.ylabel(column_name)
        plt.xticks([1], [column_name])
    
    def _create_wordcloud(self, data: pd.Series, column_name: str, **kwargs):
        """Create word cloud"""
        try:
            from wordcloud import WordCloud
            
            # Combine all text
            text = ' '.join(data.astype(str).tolist())
            
            # Generate word cloud
            wordcloud = WordCloud(
                width=800, height=600,
                background_color='white',
                colormap='Set2',
                max_words=100,
                relative_scaling=0.5
            ).generate(text)
            
            plt.imshow(wordcloud, interpolation='bilinear')
            plt.axis('off')
            
        except ImportError:
            # Fallback to bar chart if wordcloud not available
            self._create_bar_chart(data, column_name, **kwargs)
    
    def _apply_theme(self):
        """Apply current theme to matplotlib"""
        theme = self.chart_configs[self.current_theme]
        
        plt.rcParams['axes.facecolor'] = theme['background_color']
        plt.rcParams['figure.facecolor'] = theme['background_color']
        plt.rcParams['text.color'] = theme['text_color']
        plt.rcParams['axes.labelcolor'] = theme['text_color']
        plt.rcParams['xtick.color'] = theme['text_color']
        plt.rcParams['ytick.color'] = theme['text_color']
        plt.rcParams['axes.edgecolor'] = theme['grid_color']
        plt.rcParams['grid.color'] = theme['grid_color']
    
    def _apply_final_styling(self, column_name: str, chart_type: str):
        """Apply final styling to the chart"""
        
        # Set title
        title_map = {
            'histogram': f'Distribution of {column_name}',
            'bar': f'Categories in {column_name}',
            'horizontal_bar': f'Categories in {column_name}',
            'pie': f'Composition of {column_name}',
            'line': f'Trend of {column_name}',
            'scatter': f'Scatter Plot of {column_name}',
            'box': f'Box Plot of {column_name}',
            'wordcloud': f'Word Cloud for {column_name}'
        }
        
        plt.title(
            title_map.get(chart_type, f'Analysis of {column_name}'),
            fontsize=14,
            fontweight='bold',
            pad=20,
            color=self.chart_configs[self.current_theme]['text_color']
        )
        
        # Add grid for appropriate chart types
        if chart_type in ['histogram', 'bar', 'horizontal_bar', 'line', 'scatter', 'box']:
            plt.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
        
        # Style axes
        ax = plt.gca()
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['left'].set_color(self.chart_configs[self.current_theme]['grid_color'])
        ax.spines['bottom'].set_color(self.chart_configs[self.current_theme]['grid_color'])
    
    def get_available_charts(self, col_type: str) -> List[str]:
        """Get available chart types for a column type"""
        
        chart_map = {
            'numeric': ['Histogram', 'Box Plot', 'Line Chart', 'Scatter Plot'],
            'categorical': ['Bar Chart', 'Pie Chart', 'Horizontal Bar Chart'],
            'categorical_numeric': ['Bar Chart', 'Pie Chart', 'Histogram'],
            'datetime': ['Line Chart', 'Area Chart', 'Histogram'],
            'text_long': ['Word Cloud', 'Bar Chart'],
            'text_medium': ['Word Cloud', 'Bar Chart'],
            'boolean': ['Pie Chart', 'Bar Chart']
        }
        
        return chart_map.get(col_type, ['Bar Chart', 'Histogram'])
    
    def set_theme(self, theme_name: str):
        """Set the current theme"""
        if theme_name in self.chart_configs:
            self.current_theme = theme_name
    
    def health_check(self) -> bool:
        """Health check for chart generator"""
        try:
            # Test basic plotting capability
            test_data = pd.Series([1, 2, 3, 4, 5])
            plt.figure()
            plt.plot(test_data)
            plt.close()
            return True
        except:
            return False
