"""
Enhanced PII Detection with Override Capabilities
"""
import pandas as pd
import re
from typing import List, Dict, Tuple

class EnhancedPIIDetector:
    def __init__(self):
        self.pii_patterns = {
            'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'phone': r'\+?1?[-.]?\(?\d{3}\)?[-.]?\d{3}[-.]?\d{4}',
            'ssn': r'\b\d{3}-?\d{2}-?\d{4}\b',
            'credit_card': r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b'
        }
        
        self.pii_keywords = {
            'email': ['email', 'e_mail', 'mail_address', 'contact'],
            'phone': ['phone', 'telephone', 'mobile', 'cell'],
            'name': ['name', 'first_name', 'last_name', 'full_name'],
            'id': ['id', 'customer_id', 'user_id', 'account_id', 'ssn'],
            'address': ['address', 'street', 'location', 'zip', 'postal'],
            'financial': ['salary', 'income', 'credit', 'bank', 'account_number']
        }
    
    def detect_with_overrides(self, df: pd.DataFrame) -> Dict:
        """
        Comprehensive PII detection with override tracking
        """
        removed_columns = []
        
        for col in df.columns:
            pii_info = self._analyze_column(col, df[col])
            
            if pii_info['is_pii']:
                removed_columns.append({
                    'name': col,
                    'reason': pii_info['reason'],
                    'method': pii_info['method'],
                    'confidence': pii_info['confidence'],
                    'can_override': True,
                    'pii_type': pii_info['pii_type']
                })
        
        return {
            'removed_columns': removed_columns,
            'removed_count': len(removed_columns),
            'detection_methods': list(set([col['method'] for col in removed_columns]))
        }
    
    def _analyze_column(self, col_name: str, series: pd.Series) -> Dict:
        """Analyze individual column for PII"""
        
        col_lower = col_name.lower()
        
        # Method 1: Column name analysis
        for pii_type, keywords in self.pii_keywords.items():
            for keyword in keywords:
                if keyword in col_lower:
                    return {
                        'is_pii': True,
                        'reason': f'Column name contains {pii_type} keyword: "{keyword}"',
                        'method': 'name_analysis',
                        'confidence': 0.9,
                        'pii_type': pii_type
                    }
        
        # Method 2: Content pattern analysis
        sample_values = series.dropna().head(20).astype(str)
        
        for pii_type, pattern in self.pii_patterns.items():
            matches = sum(1 for val in sample_values if re.search(pattern, str(val)))
            match_ratio = matches / len(sample_values) if sample_values.size > 0 else 0
            
            if match_ratio > 0.6:  # 60% of samples match PII pattern
                return {
                    'is_pii': True,
                    'reason': f'{pii_type.title()} pattern detected in {matches}/{len(sample_values)} values',
                    'method': 'content_pattern',
                    'confidence': min(0.95, 0.7 + match_ratio * 0.25),
                    'pii_type': pii_type
                }
        
        # Method 3: Statistical uniqueness analysis
        uniqueness = series.nunique() / len(series)
        if uniqueness > 0.95 and len(series) > 100:
            return {
                'is_pii': True,
                'reason': f'High uniqueness ratio ({uniqueness:.1%}) suggests ID field',
                'method': 'statistical_uniqueness',
                'confidence': 0.7,
                'pii_type': 'identifier'
            }
        
        # Method 4: Named Entity Recognition (simplified)
        if self._contains_person_names(sample_values):
            return {
                'is_pii': True,
                'reason': 'Person names detected via NER analysis',
                'method': 'ner_detection',
                'confidence': 0.8,
                'pii_type': 'name'
            }
        
        return {
            'is_pii': False,
            'reason': '',
            'method': '',
            'confidence': 0.0,
            'pii_type': ''
        }
    
    def _contains_person_names(self, sample_values: pd.Series) -> bool:
        """Simple person name detection"""
        
        # Common first names (simplified list)
        common_names = {
            'john', 'jane', 'michael', 'sarah', 'david', 'lisa', 'robert', 'mary',
            'james', 'jennifer', 'william', 'elizabeth', 'richard', 'patricia'
        }
        
        name_count = 0
        for value in sample_values:
            words = str(value).lower().split()
            if any(word in common_names for word in words):
                name_count += 1
        
        return name_count > len(sample_values) * 0.3  # 30% contain common names
    
    def override_pii_decision(self, column_name: str, action: str) -> bool:
        """
        Handle PII override decisions
        
        Args:
            column_name: Name of the column
            action: 'restore' or 'remove'
            
        Returns:
            bool: Success status
        """
        
        # In a real implementation, this would update the PII detection results
        # For now, we'll just return success
        
        valid_actions = ['restore', 'remove']
        if action not in valid_actions:
            return False
        
        # Log the override decision
        print(f"PII Override: {action} column '{column_name}'")
        
        return True
    
    def get_detection_summary(self, df: pd.DataFrame) -> Dict:
        """Get summary of PII detection results"""
        
        results = self.detect_with_overrides(df)
        
        summary = {
            'total_columns': len(df.columns),
            'pii_columns_detected': results['removed_count'],
            'safe_columns': len(df.columns) - results['removed_count'],
            'detection_methods_used': results['detection_methods'],
            'pii_types_`detected': list(set([col['pii_type'] for col in results['removed_columns']])),
        }