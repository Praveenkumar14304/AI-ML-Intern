"""
Data Analysis API Endpoints
Provides comprehensive ML analysis capabilities
"""
from fastapi import HTTPException, Query
from typing import Dict, List, Any, Optional
import pandas as pd
from datetime import datetime

from ..ml.data_analyzer import MLDataAnalyzer
from ..ml.chart_generator import ChartGenerator
from ..utils.storage import StorageManager
from ..utils.logger import setup_logger

logger = setup_logger(__name__)

class AnalysisHandler:
    """Handles data analysis requests"""
    
    def __init__(self):
        self.storage_manager = StorageManager()
        self.data_analyzer = MLDataAnalyzer()
        self.chart_generator = ChartGenerator()
    
    async def analyze_dataset(
        self,
        dataset_id: str,
        columns: Optional[List[str]] = None,
        analysis_type: str = "comprehensive"
    ) -> Dict[str, Any]:
        """Perform comprehensive dataset analysis"""
        
        try:
            logger.info(f"Starting analysis for dataset: {dataset_id}")
            
            # Load dataset
            df, metadata = self._load_dataset(dataset_id)
            if df is None:
                raise HTTPException(status_code=404, detail="Dataset not found")
            
            # Determine columns to analyze
            if columns:
                # Validate columns exist
                missing_cols = [col for col in columns if col not in df.columns]
                if missing_cols:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Columns not found: {missing_cols}"
                    )
                analyze_df = df[columns]
            else:
                # Use all non-PII columns
                pii_columns = self._get_pii_columns(metadata)
                analyze_df = df.drop(columns=pii_columns, errors='ignore')
            
            if analyze_df.empty or len(analyze_df.columns) == 0:
                raise HTTPException(
                    status_code=400,
                    detail="No columns available for analysis"
                )
            
            # Perform analysis based on type
            if analysis_type == "comprehensive":
                result = await self._comprehensive_analysis(analyze_df, dataset_id)
            elif analysis_type == "statistical":
                result = await self._statistical_analysis(analyze_df)
            elif analysis_type == "correlation":
                result = await self._correlation_analysis(analyze_df)
            elif analysis_type == "clustering":
                result = await self._clustering_analysis(analyze_df)
            elif analysis_type == "anomaly":
                result = await self._anomaly_analysis(analyze_df)
            else:
                raise HTTPException(
                    status_code=400,
                    detail=f"Unknown analysis type: {analysis_type}"
                )
            
            # Add metadata
            result.update({
                'dataset_id': dataset_id,
                'analysis_timestamp': datetime.now().isoformat(),
                'analyzed_columns': analyze_df.columns.tolist(),
                'analysis_type': analysis_type,
                'total_rows': len(analyze_df),
                'total_columns': len(analyze_df.columns)
            })
            
            # Save analysis results
            self.storage_manager.save_analysis_results(dataset_id, result)
            
            logger.info(f"Analysis completed for dataset: {dataset_id}")
            return result
        
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Analysis failed for dataset {dataset_id}: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Analysis failed: {str(e)}"
            )
    
    async def get_column_analysis(
        self,
        dataset_id: str,
        column_name: str
    ) -> Dict[str, Any]:
        """Get detailed analysis for specific column"""
        
        try:
            df, metadata = self._load_dataset(dataset_id)
            if df is None:
                raise HTTPException(status_code=404, detail="Dataset not found")
            
            if column_name not in df.columns:
                raise HTTPException(status_code=404, detail=f"Column '{column_name}' not found")
            
            # Analyze column
            col_type = self.data_analyzer.detect_column_type(df[column_name])
            analysis = await self.data_analyzer.analyze_column(df[column_name], col_type)
            
            # Generate insights
            insights = self._generate_column_insights(df[column_name], analysis, col_type)
            
            # Generate recommended charts
            recommended_charts = self.chart_generator.get_available_charts(col_type)
            
            return {
                'dataset_id': dataset_id,
                'column_name': column_name,
                'analysis': analysis,
                'insights': insights,
                'recommended_charts': recommended_charts,
                'analysis_timestamp': datetime.now().isoformat()
            }
        
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Column analysis failed: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Column analysis failed: {str(e)}")
    
    async def generate_column_chart(
        self,
        dataset_id: str,
        column_name: str,
        chart_type: str = "auto"
    ) -> Dict[str, Any]:
        """Generate chart for specific column"""
        
        try:
            df, metadata = self._load_dataset(dataset_id)
            if df is None:
                raise HTTPException(status_code=404, detail="Dataset not found")
            
            if column_name not in df.columns:
                raise HTTPException(status_code=404, detail=f"Column '{column_name}' not found")
            
            # Determine chart type
            col_type = self.data_analyzer.detect_column_type(df[column_name])
            if chart_type == "auto":
                chart_type = self.chart_generator.select_optimal_chart(df[column_name], col_type)
            
            # Generate chart
            chart_path = f"data/charts/{dataset_id}_{column_name}_{chart_type}.png"
            generated_path = self.chart_generator.generate_chart(
                df[column_name],
                column_name,
                chart_type,
                chart_path
            )
            
            if generated_path:
                return {
                    'success': True,
                    'chart_path': generated_path,
                    'chart_type': chart_type,
                    'column_name': column_name,
                    'dataset_id': dataset_id
                }
            else:
                raise HTTPException(status_code=500, detail="Chart generation failed")
        
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Chart generation failed: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Chart generation failed: {str(e)}")
    
    async def get_data_preview(
        self,
        dataset_id: str,
        columns: Optional[List[str]] = None,
        limit: int = Query(default=10, le=100)
    ) -> Dict[str, Any]:
        """Get data preview with optional column filtering"""
        
        try:
            df, metadata = self._load_dataset(dataset_id)
            if df is None:
                raise HTTPException(status_code=404, detail="Dataset not found")
            
            # Filter columns if specified
            if columns:
                missing_cols = [col for col in columns if col not in df.columns]
                if missing_cols:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Columns not found: {missing_cols}"
                    )
                preview_df = df[columns]
            else:
                preview_df = df
            
            # Get preview data
            preview_data = preview_df.head(limit).fillna('').to_dict('records')
            
            return {
                'dataset_id': dataset_id,
                'preview_data': preview_data,
                'displayed_rows': len(preview_data),
                'displayed_columns': len(preview_df.columns),
                'total_rows': len(df),
                'total_columns': len(df.columns),
                'column_names': preview_df.columns.tolist()
            }
        
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Data preview failed: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Data preview failed: {str(e)}")
    
    def _load_dataset(self, dataset_id: str) -> tuple:
        """Load dataset from storage"""
        
        try:
            metadata = self.storage_manager.load_metadata(dataset_id)
            if not metadata:
                return None, None
            
            file_path = metadata.get('file_path')
            if not file_path or not Path(file_path).exists():
                return None, None
            
            # Load dataframe
            filename = metadata.get('filename', '')
            if filename.endswith('.csv'):
                df = pd.read_csv(file_path)
            else:
                df = pd.read_excel(file_path)
            
            return df, metadata
        
        except Exception as e:
            logger.error(f"Failed to load dataset {dataset_id}: {str(e)}")
            return None, None
    
    def _get_pii_columns(self, metadata: Dict[str, Any]) -> List[str]:
        """Get list of PII columns from metadata"""
        
        analysis_result = metadata.get('analysis_result', {})
        pii_results = analysis_result.get('pii_results', {})
        removed_columns = pii_results.get('removed_columns', [])
        
        return [col['name'] for col in removed_columns]
    
    async def _comprehensive_analysis(self, df: pd.DataFrame, dataset_id: str) -> Dict[str, Any]:
        """Perform comprehensive analysis"""
        
        result = await self.data_analyzer.analyze_dataset(df)
        
        # Add additional analysis
        numeric_cols = df.select_dtypes(include=['number']).columns
        if len(numeric_cols) > 1:
            result['correlations'] = self.data_analyzer.calculate_correlations(df[numeric_cols])
            result['clustering'] = self.data_analyzer.perform_clustering(df[numeric_cols])
            result['anomalies'] = self.data_analyzer.detect_anomalies(df[numeric_cols])
        
        # Generate insights
        result['insights'] = self.data_analyzer.generate_insights(result)
        
        return result
    
    async def _statistical_analysis(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Perform statistical analysis"""
        
        result = {'analysis_type': 'statistical'}
        
        # Basic statistics for numeric columns
        numeric_cols = df.select_dtypes(include=['number']).columns
        if len(numeric_cols) > 0:
            result['descriptive_stats'] = df[numeric_cols].describe().to_dict()
        
        # Categorical statistics
        categorical_cols = df.select_dtypes(include=['object']).columns
        if len(categorical_cols) > 0:
            result['categorical_stats'] = {}
            for col in categorical_cols:
                result['categorical_stats'][col] = {
                    'value_counts': df[col].value_counts().to_dict(),
                    'unique_count': df[col].nunique(),
                    'most_frequent': df[col].mode().tolist()[0] if not df[col].mode().empty else None
                }
        
        return result
    
    async def _correlation_analysis(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Perform correlation analysis"""
        
        numeric_df = df.select_dtypes(include=['number'])
        if len(numeric_df.columns) < 2:
            raise HTTPException(
                status_code=400,
                detail="Need at least 2 numeric columns for correlation analysis"
            )
        
        return {
            'analysis_type': 'correlation',
            'correlations': self.data_analyzer.calculate_correlations(numeric_df)
        }
    
    async def _clustering_analysis(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Perform clustering analysis"""
        
        numeric_df = df.select_dtypes(include=['number'])
        if len(numeric_df.columns) < 2:
            raise HTTPException(
                status_code=400,
                detail="Need at least 2 numeric columns for clustering analysis"
            )
        
        return {
            'analysis_type': 'clustering',
            'clustering': self.data_analyzer.perform_clustering(numeric_df)
        }
    
    async def _anomaly_analysis(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Perform anomaly detection"""
        
        numeric_df = df.select_dtypes(include=['number'])
        if len(numeric_df.columns) == 0:
            raise HTTPException(
                status_code=400,
                detail="Need at least 1 numeric column for anomaly detection"
            )
        
        return {
            'analysis_type': 'anomaly',
            'anomalies': self.data_analyzer.detect_anomalies(numeric_df)
        }
    
    def _generate_column_insights(
        self, 
        series: pd.Series, 
        analysis: Dict[str, Any], 
        col_type: str
    ) -> List[str]:
        """Generate insights for a specific column"""
        
        insights = []
        
        # Data quality insights
        null_pct = analysis.get('null_percentage', 0)
        if null_pct == 0:
            insights.append("Excellent data quality - no missing values detected")
        elif null_pct < 5:
            insights.append("Good data quality with minimal missing values")
        elif null_pct < 20:
            insights.append("Moderate data quality - consider addressing missing values")
        else:
            insights.append("Data quality concerns - significant missing values detected")
        
        # Type-specific insights
        if col_type == 'numeric':
            skewness = analysis.get('skewness', 0)
            if abs(skewness) < 0.5:
                insights.append("Data distribution is approximately symmetric")
            elif skewness > 0.5:
                insights.append("Data is right-skewed - consider log transformation")
            else:
                insights.append("Data is left-skewed - may need transformation")
            
            outliers = analysis.get('outliers_count', 0)
            if outliers > 0:
                insights.append(f"Detected {outliers} outliers that may need investigation")
        
        elif col_type in ['categorical', 'categorical_numeric']:
            unique_count = analysis.get('unique_count', 0)
            total_count = analysis.get('count', 0)
            
            if unique_count / total_count > 0.8:
                insights.append("High cardinality - many unique values detected")
            elif unique_count / total_count < 0.1:
                insights.append("Low cardinality - few unique categories")
            
            concentration = analysis.get('concentration', 0)
            if concentration > 0.5:
                insights.append("Data is concentrated in few categories")
        
        return insights

# API endpoint functions
async def analyze_dataset_endpoint(
    dataset_id: str,
    columns: Optional[str] = Query(None),
    analysis_type: str = Query("comprehensive")
) -> Dict[str, Any]:
    """Analyze dataset endpoint"""
    
    handler = AnalysisHandler()
    column_list = columns.split(',') if columns else None
    
    return await handler.analyze_dataset(dataset_id, column_list, analysis_type)

async def get_column_analysis_endpoint(
    dataset_id: str,
    column_name: str
) -> Dict[str, Any]:
    """Get column analysis endpoint"""
    
    handler = AnalysisHandler()
    return await handler.get_column_analysis(dataset_id, column_name)

async def generate_chart_endpoint(
    dataset_id: str,
    column_name: str,
    chart_type: str = Query("auto")
) -> Dict[str, Any]:
    """Generate chart endpoint"""
    
    handler = AnalysisHandler()
    return await handler.generate_column_chart(dataset_id, column_name, chart_type)

async def get_data_preview_endpoint(
    dataset_id: str,
    columns: Optional[str] = Query(None),
    limit: int = Query(default=10, le=100)
) -> Dict[str, Any]:
    """Get data preview endpoint"""
    
    handler = AnalysisHandler()
    column_list = columns.split(',') if columns else None
    
    return await handler.get_data_preview(dataset_id, column_list, limit)
