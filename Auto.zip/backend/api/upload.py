"""
File Upload API Handler
Enhanced with comprehensive validation and PII detection
"""
from fastapi import UploadFile, HTTPException, BackgroundTasks
import pandas as pd
import numpy as np
import uuid
import os
from pathlib import Path
from typing import Dict, List, Any
import magic
import hashlib
from datetime import datetime

from ..ml.pii_detector import EnhancedPIIDetector
from ..ml.data_analyzer import MLDataAnalyzer
from ..utils.storage import StorageManager
from ..utils.logger import setup_logger

logger = setup_logger(__name__)

class UploadHandler:
    """Handles file upload with enhanced validation and analysis"""
    
    def __init__(self):
        self.storage_manager = StorageManager()
        self.pii_detector = EnhancedPIIDetector()
        self.data_analyzer = MLDataAnalyzer()
        self.max_file_size = 50 * 1024 * 1024  # 50MB
        self.allowed_types = [
            'text/csv',
            'application/csv',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        ]
        self.allowed_extensions = ['.csv', '.xlsx', '.xls']
    
    async def handle_upload(
        self, 
        file: UploadFile, 
        background_tasks: BackgroundTasks
    ) -> Dict[str, Any]:
        """Handle file upload with comprehensive validation"""
        
        try:
            # Generate unique identifiers
            upload_id = str(uuid.uuid4())
            dataset_id = str(uuid.uuid4())
            
            logger.info(f"Starting upload processing: {upload_id}")
            
            # Step 1: Validate file
            validation_result = await self._validate_file(file)
            if not validation_result['valid']:
                raise HTTPException(
                    status_code=400, 
                    detail=validation_result['error']
                )
            
            # Step 2: Read file content
            content = await file.read()
            file_hash = hashlib.md5(content).hexdigest()
            
            # Step 3: Check for duplicates
            if self.storage_manager.file_exists(file_hash):
                logger.warning(f"Duplicate file upload detected: {file_hash}")
                existing_data = self.storage_manager.get_file_by_hash(file_hash)
                return existing_data
            
            # Step 4: Save file temporarily
            file_path = self.storage_manager.save_uploaded_file(
                dataset_id, 
                file.filename, 
                content
            )
            
            # Step 5: Load and validate dataset
            df, load_result = await self._load_dataset(file_path, file.filename)
            
            if not load_result['success']:
                self.storage_manager.cleanup_file(file_path)
                raise HTTPException(
                    status_code=400,
                    detail=load_result['error']
                )
            
            # Step 6: Perform comprehensive analysis
            analysis_result = await self._analyze_dataset(df, dataset_id)
            
            # Step 7: Generate metadata
            metadata = {
                'upload_id': upload_id,
                'dataset_id': dataset_id,
                'filename': file.filename,
                'file_hash': file_hash,
                'upload_timestamp': datetime.now().isoformat(),
                'file_size_bytes': len(content),
                'file_size_mb': len(content) / (1024 * 1024),
                'rows': len(df),
                'columns': len(df.columns),
                'column_names': df.columns.tolist(),
                'data_types': df.dtypes.astype(str).to_dict(),
                'memory_usage_mb': df.memory_usage(deep=True).sum() / (1024 * 1024),
                'analysis_result': analysis_result,
                'file_path': file_path
            }
            
            # Step 8: Save metadata
            self.storage_manager.save_metadata(dataset_id, metadata)
            
            # Step 9: Schedule background processing
            background_tasks.add_task(
                self._background_processing,
                dataset_id,
                df,
                analysis_result
            )
            
            logger.info(f"Upload processing completed: {upload_id}")
            
            # Step 10: Return response
            return {
                'success': True,
                'upload_id': upload_id,
                'dataset_id': dataset_id,
                'filename': file.filename,
                'file_size_mb': round(len(content) / (1024 * 1024), 2),
                'rows': len(df),
                'columns': len(df.columns),
                'column_info': analysis_result['column_analysis'],
                'pii_results': analysis_result['pii_results'],
                'data_quality': analysis_result['data_quality'],
                'preview_data': df.head(10).fillna('').to_dict('records'),
                'processing_time_ms': (datetime.now() - datetime.fromisoformat(metadata['upload_timestamp'])).total_seconds() * 1000
            }
        
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Upload processing failed: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Upload processing failed: {str(e)}"
            )
    
    async def _validate_file(self, file: UploadFile) -> Dict[str, Any]:
        """Comprehensive file validation"""
        
        # Check filename
        if not file.filename:
            return {'valid': False, 'error': 'No filename provided'}
        
        # Check file extension
        file_ext = Path(file.filename).suffix.lower()
        if file_ext not in self.allowed_extensions:
            return {
                'valid': False,
                'error': f'Invalid file extension. Allowed: {", ".join(self.allowed_extensions)}'
            }
        
        # Read content for further validation
        content = await file.read()
        await file.seek(0)  # Reset file pointer
        
        # Check file size
        if len(content) > self.max_file_size:
            return {
                'valid': False,
                'error': f'File too large. Maximum size: {self.max_file_size / (1024*1024):.0f}MB'
            }
        
        # Check if file is empty
        if len(content) == 0:
            return {'valid': False, 'error': 'File is empty'}
        
        # Check file content type using python-magic
        try:
            file_type = magic.from_buffer(content, mime=True)
            if file_type not in self.allowed_types:
                logger.warning(f"Unexpected MIME type: {file_type} for {file.filename}")
                # Don't fail here, as some systems report different MIME types
        except Exception as e:
            logger.warning(f"Could not determine MIME type: {e}")
        
        # Basic content validation for CSV files
        if file_ext == '.csv':
            try:
                # Try to read first few lines as text
                text_content = content.decode('utf-8')[:1000]
                if not any(sep in text_content for sep in [',', ';', '\t']):
                    return {'valid': False, 'error': 'CSV file does not contain valid separators'}
            except UnicodeDecodeError:
                # Try other encodings
                for encoding in ['latin-1', 'iso-8859-1', 'cp1252']:
                    try:
                        content.decode(encoding)
                        break
                    except UnicodeDecodeError:
                        continue
                else:
                    return {'valid': False, 'error': 'Unable to decode file content'}
        
        return {'valid': True, 'error': None}
    
    async def _load_dataset(self, file_path: str, filename: str) -> tuple:
        """Load dataset with multiple encoding attempts"""
        
        try:
            file_ext = Path(filename).suffix.lower()
            
            if file_ext == '.csv':
                # Try multiple encodings and separators for CSV
                encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252']
                separators = [',', ';', '\t']
                
                for encoding in encodings:
                    for sep in separators:
                        try:
                            df = pd.read_csv(file_path, encoding=encoding, sep=sep)
                            
                            # Validate loaded data
                            if len(df.columns) > 0 and len(df) > 0:
                                # Check if it's actually structured data
                                if len(df.columns) >= 2 or len(df) >= 5:
                                    logger.info(f"Successfully loaded CSV with encoding: {encoding}, separator: {sep}")
                                    return df, {'success': True, 'encoding': encoding, 'separator': sep}
                        except Exception as e:
                            continue
                
                return None, {'success': False, 'error': 'Unable to parse CSV file with any encoding/separator combination'}
            
            else:  # Excel files
                try:
                    df = pd.read_excel(file_path, engine='openpyxl')
                    return df, {'success': True, 'engine': 'openpyxl'}
                except Exception as e:
                    try:
                        df = pd.read_excel(file_path, engine='xlrd')
                        return df, {'success': True, 'engine': 'xlrd'}
                    except Exception as e2:
                        return None, {'success': False, 'error': f'Unable to parse Excel file: {str(e2)}'}
        
        except Exception as e:
            return None, {'success': False, 'error': f'Dataset loading failed: {str(e)}'}
    
    async def _analyze_dataset(self, df: pd.DataFrame, dataset_id: str) -> Dict[str, Any]:
        """Perform comprehensive dataset analysis"""
        
        try:
            analysis_result = {
                'dataset_id': dataset_id,
                'analysis_timestamp': datetime.now().isoformat(),
                'column_analysis': {},
                'pii_results': {},
                'data_quality': {},
                'basic_stats': {},
                'recommendations': []
            }
            
            # Basic statistics
            analysis_result['basic_stats'] = {
                'total_rows': len(df),
                'total_columns': len(df.columns),
                'memory_usage_mb': df.memory_usage(deep=True).sum() / (1024 * 1024),
                'total_cells': len(df) * len(df.columns),
                'null_cells': df.isnull().sum().sum(),
                'null_percentage': (df.isnull().sum().sum() / (len(df) * len(df.columns))) * 100
            }
            
            # Column-level analysis
            for col in df.columns:
                column_analysis = await self.data_analyzer.analyze_column(
                    df[col], 
                    self.data_analyzer.detect_column_type(df[col])
                )
                analysis_result['column_analysis'][col] = column_analysis
            
            # PII detection
            pii_results = await self.pii_detector.detect_with_overrides(df)
            analysis_result['pii_results'] = pii_results
            
            # Data quality assessment
            quality_score = self._calculate_data_quality_score(df, analysis_result)
            analysis_result['data_quality'] = quality_score
            
            # Generate recommendations
            recommendations = self._generate_recommendations(df, analysis_result)
            analysis_result['recommendations'] = recommendations
            
            return analysis_result
        
        except Exception as e:
            logger.error(f"Dataset analysis failed: {str(e)}")
            return {
                'error': str(e),
                'analysis_timestamp': datetime.now().isoformat()
            }
    
    def _calculate_data_quality_score(self, df: pd.DataFrame, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate comprehensive data quality score"""
        
        scores = {}
        
        # Completeness score (based on null values)
        null_pct = analysis['basic_stats']['null_percentage']
        completeness_score = max(0, 100 - null_pct)
        scores['completeness'] = completeness_score
        
        # Consistency score (based on data types and patterns)
        consistency_issues = 0
        total_columns = len(df.columns)
        
        for col, col_analysis in analysis['column_analysis'].items():
            # Check for mixed data types in object columns
            if df[col].dtype == 'object':
                unique_types = set(type(val).__name__ for val in df[col].dropna().iloc[:100])
                if len(unique_types) > 2:  # Mixed types
                    consistency_issues += 1
        
        consistency_score = max(0, 100 - (consistency_issues / total_columns) * 100)
        scores['consistency'] = consistency_score
        
        # Validity score (based on reasonable value ranges)
        validity_issues = 0
        numeric_columns = df.select_dtypes(include=[np.number]).columns
        
        for col in numeric_columns:
            # Check for extreme outliers
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 3 * IQR
            upper_bound = Q3 + 3 * IQR
            
            extreme_outliers = len(df[(df[col] < lower_bound) | (df[col] > upper_bound)])
            if extreme_outliers > len(df) * 0.1:  # More than 10% extreme outliers
                validity_issues += 1
        
        validity_score = max(0, 100 - (validity_issues / max(1, len(numeric_columns))) * 100)
        scores['validity'] = validity_score
        
        # Uniqueness score (based on duplicate rows)
        duplicate_rows = len(df) - len(df.drop_duplicates())
        uniqueness_score = max(0, 100 - (duplicate_rows / len(df)) * 100)
        scores['uniqueness'] = uniqueness_score
        
        # Overall score (weighted average)
        overall_score = (
            completeness_score * 0.3 +
            consistency_score * 0.25 +
            validity_score * 0.25 +
            uniqueness_score * 0.2
        )
        
        return {
            'scores': scores,
            'overall_score': overall_score,
            'grade': self._get_quality_grade(overall_score),
            'issues_found': {
                'null_values': null_pct > 10,
                'consistency_issues': consistency_issues > 0,
                'validity_issues': validity_issues > 0,
                'duplicate_rows': duplicate_rows > 0
            }
        }
    
    def _get_quality_grade(self, score: float) -> str:
        """Convert quality score to letter grade"""
        if score >= 90:
            return 'A'
        elif score >= 80:
            return 'B'
        elif score >= 70:
            return 'C'
        elif score >= 60:
            return 'D'
        else:
            return 'F'
    
    def _generate_recommendations(self, df: pd.DataFrame, analysis: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on analysis"""
        
        recommendations = []
        
        # Data quality recommendations
        quality = analysis['data_quality']
        if quality['overall_score'] < 80:
            recommendations.append("Consider data cleaning to improve overall quality score")
        
        if quality['scores']['completeness'] < 90:
            recommendations.append("Address missing values in dataset for better analysis results")
        
        if quality['scores']['consistency'] < 80:
            recommendations.append("Review data types and standardize inconsistent values")
        
        # PII recommendations
        pii_count = analysis['pii_results'].get('removed_count', 0)
        if pii_count > 0:
            recommendations.append(f"Review {pii_count} automatically detected PII columns for false positives")
        
        # Column recommendations
        numeric_cols = len([col for col, info in analysis['column_analysis'].items() 
                          if info.get('type') == 'numeric'])
        
        if numeric_cols < 2:
            recommendations.append("Consider additional numeric variables for statistical analysis")
        
        # Size recommendations
        if analysis['basic_stats']['total_rows'] < 100:
            recommendations.append("Small dataset size may limit statistical significance of results")
        elif analysis['basic_stats']['total_rows'] > 100000:
            recommendations.append("Large dataset detected - consider sampling for initial analysis")
        
        return recommendations
    
    async def _background_processing(
        self, 
        dataset_id: str, 
        df: pd.DataFrame, 
        analysis_result: Dict[str, Any]
    ) -> None:
        """Background processing tasks"""
        
        try:
            logger.info(f"Starting background processing for dataset: {dataset_id}")
            
            # Generate additional statistics
            if len(df.select_dtypes(include=[np.number]).columns) > 1:
                correlations = self.data_analyzer.calculate_correlations(
                    df.select_dtypes(include=[np.number])
                )
                analysis_result['correlations'] = correlations
            
            # Perform clustering analysis if applicable
            numeric_data = df.select_dtypes(include=[np.number])
            if len(numeric_data.columns) >= 2 and len(numeric_data) >= 10:
                clustering_result = self.data_analyzer.perform_clustering(numeric_data)
                analysis_result['clustering'] = clustering_result
            
            # Detect anomalies
            if len(numeric_data.columns) > 0:
                anomalies = self.data_analyzer.detect_anomalies(numeric_data)
                analysis_result['anomalies'] = anomalies
            
            # Update metadata with enhanced analysis
            self.storage_manager.update_analysis_results(dataset_id, analysis_result)
            
            logger.info(f"Background processing completed for dataset: {dataset_id}")
        
        except Exception as e:
            logger.error(f"Background processing failed for dataset {dataset_id}: {str(e)}")

async def handle_file_upload(
    file: UploadFile, 
    background_tasks: BackgroundTasks
) -> Dict[str, Any]:
    """Main upload handler function"""
    
    handler = UploadHandler()
    return await handler.handle_upload(file, background_tasks)
