"""
History Management API Endpoints
Tracks and manages generated presentations
"""
from fastapi import HTTPException, Query
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import json
from pathlib import Path

from ..utils.storage import StorageManager
from ..utils.logger import setup_logger

logger = setup_logger(__name__)

class HistoryHandler:
    """Handles presentation history management"""
    
    def __init__(self):
        self.storage_manager = StorageManager()
    
    async def get_presentation_history(
        self,
        limit: int = Query(default=20, le=100),
        offset: int = Query(default=0, ge=0),
        sort_by: str = Query(default="created_at"),
        sort_order: str = Query(default="desc"),
        filter_by: Optional[str] = Query(default=None),
        date_from: Optional[str] = Query(default=None),
        date_to: Optional[str] = Query(default=None)
    ) -> Dict[str, Any]:
        """Get presentation history with filtering and pagination"""
        
        try:
            # Get all presentations
            all_presentations = self.storage_manager.get_all_presentations()
            
            # Apply filters
            filtered_presentations = self._apply_filters(
                all_presentations,
                filter_by,
                date_from,
                date_to
            )
            
            # Apply sorting
            sorted_presentations = self._apply_sorting(
                filtered_presentations,
                sort_by,
                sort_order
            )
            
            # Apply pagination
            total_count = len(sorted_presentations)
            paginated_presentations = sorted_presentations[offset:offset + limit]
            
            # Enhance with additional metadata
            enhanced_presentations = []
            for presentation in paginated_presentations:
                enhanced = await self._enhance_presentation_metadata(presentation)
                enhanced_presentations.append(enhanced)
            
            # Generate summary statistics
            summary_stats = self._generate_summary_stats(all_presentations)
            
            return {
                'presentations': enhanced_presentations,
                'pagination': {
                    'total_count': total_count,
                    'limit': limit,
                    'offset': offset,
                    'has_next': offset + limit < total_count,
                    'has_previous': offset > 0
                },
                'summary_stats': summary_stats,
                'filters_applied': {
                    'filter_by': filter_by,
                    'date_from': date_from,
                    'date_to': date_to,
                    'sort_by': sort_by,
                    'sort_order': sort_order
                }
            }
        
        except Exception as e:
            logger.error(f"Failed to get presentation history: {str(e)}")
            raise HTTPException(status_code=500, detail=f"History retrieval failed: {str(e)}")
    
    async def get_presentation_details(self, generation_id: str) -> Dict[str, Any]:
        """Get detailed information about a specific presentation"""
        
        try:
            # Get generation metadata
            generation_metadata = self.storage_manager.load_generation_metadata(generation_id)
            if not generation_metadata:
                raise HTTPException(status_code=404, detail="Presentation not found")
            
            # Get dataset metadata
            dataset_id = generation_metadata.get('dataset_id')
            dataset_metadata = None
            if dataset_id:
                dataset_metadata = self.storage_manager.load_metadata(dataset_id)
            
            # Check if files still exist
            presentation_path = generation_metadata.get('presentation_path')
            file_exists = presentation_path and Path(presentation_path).exists()
            file_size_mb = 0
            if file_exists:
                file_size_mb = Path(presentation_path).stat().st_size / (1024 * 1024)
            
            # Get chart information
            chart_paths = generation_metadata.get('chart_paths', {})
            charts_info = []
            for column, chart_path in chart_paths.items():
                chart_exists = Path(chart_path).exists() if chart_path else False
                charts_info.append({
                    'column': column,
                    'chart_path': chart_path,
                    'exists': chart_exists,
                    'chart_type': self._extract_chart_type_from_path(chart_path)
                })
            
            # Compile detailed response
            return {
                'generation_id': generation_id,
                'dataset_id': dataset_id,
                'generation_metadata': generation_metadata,
                'dataset_metadata': dataset_metadata,
                'file_info': {
                    'exists': file_exists,
                    'path': presentation_path,
                    'size_mb': round(file_size_mb, 2)
                },
                'charts_info': charts_info,
                'analysis_summary': self._extract_analysis_summary(generation_metadata),
                'generation_stats': self._calculate_generation_stats(generation_metadata)
            }
        
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Failed to get presentation details: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Details retrieval failed: {str(e)}")
    
    async def delete_presentation(self, generation_id: str) -> Dict[str, Any]:
        """Delete a presentation and associated files"""
        
        try:
            # Get presentation metadata
            generation_metadata = self.storage_manager.load_generation_metadata(generation_id)
            if not generation_metadata:
                raise HTTPException(status_code=404, detail="Presentation not found")
            
            deleted_files = []
            
            # Delete presentation file
            presentation_path = generation_metadata.get('presentation_path')
            if presentation_path and Path(presentation_path).exists():
                Path(presentation_path).unlink()
                deleted_files.append(presentation_path)
            
            # Delete chart files
            chart_paths = generation_metadata.get('chart_paths', {})
            for chart_path in chart_paths.values():
                if chart_path and Path(chart_path).exists():
                    Path(chart_path).unlink()
                    deleted_files.append(chart_path)
            
            # Delete metadata
            self.storage_manager.delete_generation_metadata(generation_id)
            
            logger.info(f"Deleted presentation {generation_id} and {len(deleted_files)} associated files")
            
            return {
                'success': True,
                'generation_id': generation_id,
                'deleted_files_count': len(deleted_files),
                'deleted_files': deleted_files,
                'deleted_at': datetime.now().isoformat()
            }
        
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Failed to delete presentation {generation_id}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Deletion failed: {str(e)}")
    
    async def duplicate_presentation(self, generation_id: str, new_title: Optional[str] = None) -> Dict[str, Any]:
        """Create a duplicate of an existing presentation"""
        
        try:
            # Get original presentation metadata
            original_metadata = self.storage_manager.load_generation_metadata(generation_id)
            if not original_metadata:
                raise HTTPException(status_code=404, detail="Original presentation not found")
            
            # Generate new IDs
            new_generation_id = str(uuid.uuid4())
            
            # Update configuration for duplicate
            config = original_metadata.get('config', {}).copy()
            if new_title:
                config['title'] = new_title
            else:
                config['title'] = config.get('title', 'Data Analysis') + ' (Copy)'
            
            # Create duplicate metadata
            duplicate_metadata = original_metadata.copy()
            duplicate_metadata.update({
                'generation_id': new_generation_id,
                'config': config,
                'created_at': datetime.now().isoformat(),
                'is_duplicate': True,
                'original_generation_id': generation_id
            })
            
            # Save duplicate metadata
            self.storage_manager.save_generation_metadata(new_generation_id, duplicate_metadata)
            
            return {
                'success': True,
                'new_generation_id': new_generation_id,
                'original_generation_id': generation_id,
                'new_title': config['title'],
                'created_at': duplicate_metadata['created_at']
            }
        
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Failed to duplicate presentation {generation_id}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Duplication failed: {str(e)}")
    
    async def get_usage_statistics(self, days: int = Query(default=30, le=365)) -> Dict[str, Any]:
        """Get usage statistics for the specified time period"""
        
        try:
            # Calculate date range
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            # Get all presentations
            all_presentations = self.storage_manager.get_all_presentations()
            
            # Filter by date range
            period_presentations = [
                p for p in all_presentations
                if self._is_in_date_range(p, start_date, end_date)
            ]
            
            # Calculate statistics
            stats = {
                'period': {
                    'days': days,
                    'start_date': start_date.isoformat(),
                    'end_date': end_date.isoformat()
                },
                'totals': {
                    'presentations_created': len(period_presentations),
                    'total_slides': sum(p.get('slide_count', 0) for p in period_presentations),
                    'total_charts': sum(len(p.get('chart_paths', {})) for p in period_presentations),
                    'total_datasets': len(set(p.get('dataset_id') for p in period_presentations))
                },
                'averages': self._calculate_averages(period_presentations),
                'breakdowns': {
                    'by_story_mode': self._breakdown_by_field(period_presentations, 'config.story_mode'),
                    'by_template': self._breakdown_by_field(period_presentations, 'config.template'),
                    'by_date': self._breakdown_by_date(period_presentations),
                    'by_dataset_size': self._breakdown_by_dataset_size(period_presentations)
                },
                'trends': self._calculate_trends(period_presentations, days)
            }
            
            return stats
        
        except Exception as e:
            logger.error(f"Failed to get usage statistics: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Statistics retrieval failed: {str(e)}")
    
    async def export_history(self, format: str = Query(default="json")) -> Dict[str, Any]:
        """Export presentation history in specified format"""
        
        try:
            all_presentations = self.storage_manager.get_all_presentations()
            
            # Clean and prepare data for export
            export_data = []
            for presentation in all_presentations:
                cleaned_presentation = self._clean_presentation_for_export(presentation)
                export_data.append(cleaned_presentation)
            
            if format.lower() == "csv":
                # Convert to CSV format
                csv_data = self._convert_to_csv(export_data)
                return {
                    'format': 'csv',
                    'data': csv_data,
                    'filename': f'presentation_history_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
                }
            else:
                # Return as JSON (default)
                return {
                    'format': 'json',
                    'data': export_data,
                    'filename': f'presentation_history_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json',
                    'total_presentations': len(export_data),
                    'exported_at': datetime.now().isoformat()
                }
        
        except Exception as e:
            logger.error(f"Failed to export history: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")
    
    def _apply_filters(
        self,
        presentations: List[Dict[str, Any]],
        filter_by: Optional[str],
        date_from: Optional[str],
        date_to: Optional[str]
    ) -> List[Dict[str, Any]]:
        """Apply filters to presentations list"""
        
        filtered = presentations.copy()
        
        # Text filter
        if filter_by:
            filter_text = filter_by.lower()
            filtered = [
                p for p in filtered
                if (filter_text in p.get('config', {}).get('title', '').lower() or
                    filter_text in p.get('dataset_id', '').lower() or
                    filter_text in p.get('config', {}).get('story_mode', '').lower())
            ]
        
        # Date range filter
        if date_from:
            start_date = datetime.fromisoformat(date_from)
            filtered = [
                p for p in filtered
                if datetime.fromisoformat(p.get('created_at', p.get('started_at', ''))) >= start_date
            ]
        
        if date_to:
            end_date = datetime.fromisoformat(date_to)
            filtered = [
                p for p in filtered
                if datetime.fromisoformat(p.get('created_at', p.get('started_at', ''))) <= end_date
            ]
        
        return filtered
    
    def _apply_sorting(
        self,
        presentations: List[Dict[str, Any]],
        sort_by: str,
        sort_order: str
    ) -> List[Dict[str, Any]]:
        """Apply sorting to presentations list"""
        
        reverse = sort_order.lower() == 'desc'
        
        if sort_by == 'created_at':
            return sorted(
                presentations,
                key=lambda p: p.get('created_at', p.get('started_at', '')),
                reverse=reverse
            )
        elif sort_by == 'title':
            return sorted(
                presentations,
                key=lambda p: p.get('config', {}).get('title', '').lower(),
                reverse=reverse
            )
        elif sort_by == 'slide_count':
            return sorted(
                presentations,
                key=lambda p: p.get('slide_count', 0),
                reverse=reverse
            )
        elif sort_by == 'generation_time':
            return sorted(
                presentations,
                key=lambda p: p.get('generation_time', 0),
                reverse=reverse
            )
        else:
            return presentations
    
    async def _enhance_presentation_metadata(self, presentation: Dict[str, Any]) -> Dict[str, Any]:
        """Enhance presentation with additional metadata"""
        
        enhanced = presentation.copy()
        
        # Add file status
        presentation_path = presentation.get('presentation_path')
        enhanced['file_exists'] = presentation_path and Path(presentation_path).exists()
        
        if enhanced['file_exists']:
            enhanced['file_size_mb'] = round(
                Path(presentation_path).stat().st_size / (1024 * 1024), 2
            )
        
        # Add chart count
        enhanced['chart_count'] = len(presentation.get('chart_paths', {}))
        
        # Add dataset name if available
        dataset_id = presentation.get('dataset_id')
        if dataset_id:
            dataset_metadata = self.storage_manager.load_metadata(dataset_id)
            if dataset_metadata:
                enhanced['dataset_filename'] = dataset_metadata.get('filename', 'Unknown')
        
        # Calculate age
        created_at = presentation.get('created_at', presentation.get('started_at'))
        if created_at:
            created_datetime = datetime.fromisoformat(created_at)
            age_days = (datetime.now() - created_datetime).days
            enhanced['age_days'] = age_days
        
        return enhanced
    
    def _generate_summary_stats(self, presentations: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary statistics for all presentations"""
        
        if not presentations:
            return {
                'total_presentations': 0,
                'total_slides': 0,
                'total_charts': 0,
                'average_slides_per_presentation': 0,
                'average_charts_per_presentation': 0,
                'most_used_template': 'N/A',
                'most_used_story_mode': 'N/A'
            }
        
        total_slides = sum(p.get('slide_count', 0) for p in presentations)
        total_charts = sum(len(p.get('chart_paths', {})) for p in presentations)
        
        # Find most common values
        templates = [p.get('config', {}).get('template') for p in presentations]
        story_modes = [p.get('config', {}).get('story_mode') for p in presentations]
        
        most_used_template = max(set(templates), key=templates.count) if templates else 'N/A'
        most_used_story_mode = max(set(story_modes), key=story_modes.count) if story_modes else 'N/A'
        
        return {
            'total_presentations': len(presentations),
            'total_slides': total_slides,
            'total_charts': total_charts,
            'average_slides_per_presentation': round(total_slides / len(presentations), 1),
            'average_charts_per_presentation': round(total_charts / len(presentations), 1),
            'most_used_template': most_used_template,
            'most_used_story_mode': most_used_story_mode
        }
    
    def _extract_chart_type_from_path(self, chart_path: str) -> str:
        """Extract chart type from file path"""
        if not chart_path:
            return 'unknown'
        
        filename = Path(chart_path).stem
        parts = filename.split('_')
        return parts[-1] if len(parts) > 0 else 'unknown'
    
    def _extract_analysis_summary(self, generation_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Extract analysis summary from generation metadata"""
        
        analysis_results = generation_metadata.get('analysis_results', {})
        
        return {
            'columns_analyzed': len(generation_metadata.get('config', {}).get('selected_columns', [])),
            'insights_generated': len(analysis_results.get('ai_insights', [])),
            'correlations_found': len(analysis_results.get('correlations', {}).get('strong_correlations', [])),
            'charts_created': len(generation_metadata.get('chart_paths', {})),
            'data_quality_score': analysis_results.get('data_quality', {}).get('overall_score', 0)
        }
    
    def _calculate_generation_stats(self, generation_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate generation statistics"""
        
        generation_time = generation_metadata.get('generation_time', 0)
        
        return {
            'generation_time_seconds': generation_time,
            'generation_time_minutes': round(generation_time / 60, 1),
            'slides_generated': generation_metadata.get('slide_count', 0),
            'charts_generated': len(generation_metadata.get('chart_paths', {})),
            'template_used': generation_metadata.get('config', {}).get('template'),
            'story_mode_used': generation_metadata.get('config', {}).get('story_mode')
        }
    
    def _is_in_date_range(self, presentation: Dict[str, Any], start_date: datetime, end_date: datetime) -> bool:
        """Check if presentation is within date range"""
        
        created_at = presentation.get('created_at', presentation.get('started_at'))
        if not created_at:
            return False
        
        created_datetime = datetime.fromisoformat(created_at)
        return start_date <= created_datetime <= end_date
    
    def _calculate_averages(self, presentations: List[Dict[str, Any]]) -> Dict[str, float]:
        """Calculate average values"""
        
        if not presentations:
            return {
                'avg_slides': 0.0,
                'avg_charts': 0.0,
                'avg_generation_time': 0.0,
                'avg_columns_analyzed': 0.0
            }
        
        total_slides = sum(p.get('slide_count', 0) for p in presentations)
        total_charts = sum(len(p.get('chart_paths', {})) for p in presentations)
        total_gen_time = sum(p.get('generation_time', 0) for p in presentations)
        total_columns = sum(len(p.get('config', {}).get('selected_columns', [])) for p in presentations)
        
        count = len(presentations)
        
        return {
            'avg_slides': round(total_slides / count, 1),
            'avg_charts': round(total_charts / count, 1),
            'avg_generation_time': round(total_gen_time / count, 1),
            'avg_columns_analyzed': round(total_columns / count, 1)
        }
    
    def _breakdown_by_field(self, presentations: List[Dict[str, Any]], field_path: str) -> Dict[str, int]:
        """Create breakdown by specified field"""
        
        values = []
        for presentation in presentations:
            if '.' in field_path:
                parts = field_path.split('.')
                value = presentation
                for part in parts:
                    value = value.get(part, {}) if isinstance(value, dict) else None
                    if value is None:
                        break
            else:
                value = presentation.get(field_path)
            
            if value:
                values.append(str(value))
        
        # Count occurrences
        breakdown = {}
        for value in values:
            breakdown[value] = breakdown.get(value, 0) + 1
        
        return breakdown
    
    def _breakdown_by_date(self, presentations: List[Dict[str, Any]]) -> Dict[str, int]:
        """Create breakdown by date"""
        
        date_counts = {}
        
        for presentation in presentations:
            created_at = presentation.get('created_at', presentation.get('started_at'))
            if created_at:
                date = datetime.fromisoformat(created_at).date().isoformat()
                date_counts[date] = date_counts.get(date, 0) + 1
        
        return date_counts
    
    def _breakdown_by_dataset_size(self, presentations: List[Dict[str, Any]]) -> Dict[str, int]:
        """Create breakdown by dataset size categories"""
        
        size_categories = {
            'Small (< 1K rows)': 0,
            'Medium (1K - 10K rows)': 0,
            'Large (10K - 100K rows)': 0,
            'Very Large (> 100K rows)': 0
        }
        
        for presentation in presentations:
            # This would need to be enhanced to get actual dataset sizes
            # For now, we'll use a placeholder implementation
            size_categories['Medium (1K - 10K rows)'] += 1
        
        return size_categories
    
    def _calculate_trends(self, presentations: List[Dict[str, Any]], days: int) -> Dict[str, Any]:
        """Calculate trend information"""
        
        if not presentations or days < 2:
            return {'trend': 'insufficient_data'}
        
        # Sort by date
        sorted_presentations = sorted(
            presentations,
            key=lambda p: p.get('created_at', p.get('started_at', ''))
        )
        
        # Split into two halves
        mid_point = len(sorted_presentations) // 2
        first_half = sorted_presentations[:mid_point]
        second_half = sorted_presentations[mid_point:]
        
        if not first_half or not second_half:
            return {'trend': 'insufficient_data'}
        
        first_half_rate = len(first_half) / (days / 2)
        second_half_rate = len(second_half) / (days / 2)
        
        if second_half_rate > first_half_rate * 1.1:
            trend = 'increasing'
        elif second_half_rate < first_half_rate * 0.9:
            trend = 'decreasing'
        else:
            trend = 'stable'
        
        return {
            'trend': trend,
            'first_half_rate': round(first_half_rate, 2),
            'second_half_rate': round(second_half_rate, 2),
            'change_percentage': round(((second_half_rate - first_half_rate) / first_half_rate) * 100, 1) if first_half_rate > 0 else 0
        }
    
    def _clean_presentation_for_export(self, presentation: Dict[str, Any]) -> Dict[str, Any]:
        """Clean presentation data for export"""
        
        config = presentation.get('config', {})
        
        return {
            'generation_id': presentation.get('generation_id'),
            'dataset_id': presentation.get('dataset_id'),
            'title': config.get('title'),
            'template': config.get('template'),
            'story_mode': config.get('story_mode'),
            'created_at': presentation.get('created_at', presentation.get('started_at')),
            'slide_count': presentation.get('slide_count'),
            'chart_count': len(presentation.get('chart_paths', {})),
            'generation_time_seconds': presentation.get('generation_time'),
            'columns_analyzed': len(config.get('selected_columns', [])),
            'file_exists': presentation.get('presentation_path') and Path(presentation.get('presentation_path')).exists()
        }
    
    def _convert_to_csv(self, export_data: List[Dict[str, Any]]) -> str:
        """Convert export data to CSV format"""
        
        if not export_data:
            return ""
        
        import csv
        import io
        
        output = io.StringIO()
        fieldnames = export_data[0].keys()
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        
        writer.writeheader()
        for row in export_data:
            writer.writerow(row)
        
        return output.getvalue()

# API endpoint functions
async def get_history_endpoint(
    limit: int = Query(default=20, le=100),
    offset: int = Query(default=0, ge=0),
    sort_by: str = Query(default="created_at"),
    sort_order: str = Query(default="desc"),
    filter_by: Optional[str] = Query(default=None),
    date_from: Optional[str] = Query(default=None),
    date_to: Optional[str] = Query(default=None)
) -> Dict[str, Any]:
    """Get presentation history endpoint"""
    
    handler = HistoryHandler()
    return await handler.get_presentation_history(limit, offset, sort_by, sort_order, filter_by, date_from, date_to)

async def get_presentation_details_endpoint(generation_id: str) -> Dict[str, Any]:
    """Get presentation details endpoint"""
    
    handler = HistoryHandler()
    return await handler.get_presentation_details(generation_id)

async def delete_presentation_endpoint(generation_id: str) -> Dict[str, Any]:
    """Delete presentation endpoint"""
    
    handler = HistoryHandler()
    return await handler.delete_presentation(generation_id)

async def duplicate_presentation_endpoint(
    generation_id: str,
    new_title: Optional[str] = None
) -> Dict[str, Any]:
    """Duplicate presentation endpoint"""
    
    handler = HistoryHandler()
    return await handler.duplicate_presentation(generation_id, new_title)

async def get_usage_stats_endpoint(days: int = Query(default=30, le=365)) -> Dict[str, Any]:
    """Get usage statistics endpoint"""
    
    handler = HistoryHandler()
    return await handler.get_usage_statistics(days)

async def export_history_endpoint(format: str = Query(default="json")) -> Dict[str, Any]:
    """Export history endpoint"""
    
    handler = HistoryHandler()
    return await handler.export_history(format)
