"""
PowerPoint Generation API Endpoints
Handles presentation creation with AI/ML analysis
"""
from fastapi import HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from typing import Dict, List, Any, Optional
import asyncio
from pathlib import Path
import uuid
from datetime import datetime
import json

from ..ppt.generator import PPTGenerator
from ..ppt.templates import PPTTemplateManager
from ..ml.chart_generator import ChartGenerator
from ..ml.insights_generator import InsightsGenerator
from ..utils.storage import StorageManager
from ..utils.logger import setup_logger

logger = setup_logger(__name__)

class GenerationHandler:
    """Handles PowerPoint generation requests"""
    
    def __init__(self):
        self.storage_manager = StorageManager()
        self.ppt_generator = PPTGenerator()
        self.template_manager = PPTTemplateManager()
        self.chart_generator = ChartGenerator()
        self.insights_generator = InsightsGenerator()
        self.generation_status = {}  # Track generation progress
    
    async def generate_presentation(
        self,
        dataset_id: str,
        config: Dict[str, Any],
        background_tasks: BackgroundTasks
    ) -> Dict[str, Any]:
        """Generate PowerPoint presentation"""
        
        try:
            generation_id = str(uuid.uuid4())
            logger.info(f"Starting presentation generation: {generation_id}")
            
            # Validate dataset
            df, metadata = await self._load_dataset(dataset_id)
            if df is None:
                raise HTTPException(status_code=404, detail="Dataset not found")
            
            # Validate configuration
            validated_config = self._validate_config(config, metadata)
            
            # Initialize generation status
            self.generation_status[generation_id] = {
                'status': 'initializing',
                'progress': 0,
                'current_step': 'Preparing analysis',
                'total_steps': 8,
                'started_at': datetime.now().isoformat(),
                'dataset_id': dataset_id,
                'config': validated_config
            }
            
            # Start background generation
            background_tasks.add_task(
                self._generate_presentation_background,
                generation_id,
                dataset_id,
                df,
                validated_config
            )
            
            return {
                'success': True,
                'generation_id': generation_id,
                'status': 'started',
                'estimated_time_minutes': self._estimate_generation_time(df, validated_config),
                'dataset_id': dataset_id,
                'config': validated_config
            }
        
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Presentation generation failed: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Generation failed: {str(e)}"
            )
    
    async def get_generation_status(self, generation_id: str) -> Dict[str, Any]:
        """Get generation progress status"""
        
        if generation_id not in self.generation_status:
            raise HTTPException(status_code=404, detail="Generation not found")
        
        status = self.generation_status[generation_id]
        
        # Check if generation is complete
        if status['status'] == 'completed':
            # Add download information
            presentation_path = status.get('presentation_path')
            if presentation_path and Path(presentation_path).exists():
                status['download_ready'] = True
                status['file_size_mb'] = Path(presentation_path).stat().st_size / (1024 * 1024)
        
        return status
    
    async def download_presentation(self, generation_id: str) -> FileResponse:
        """Download generated presentation"""
        
        if generation_id not in self.generation_status:
            raise HTTPException(status_code=404, detail="Generation not found")
        
        status = self.generation_status[generation_id]
        
        if status['status'] != 'completed':
            raise HTTPException(status_code=400, detail="Generation not completed")
        
        presentation_path = status.get('presentation_path')
        if not presentation_path or not Path(presentation_path).exists():
            raise HTTPException(status_code=404, detail="Presentation file not found")
        
        filename = f"analysis_presentation_{generation_id[:8]}.pptx"
        
        return FileResponse(
            path=presentation_path,
            filename=filename,
            media_type='application/vnd.openxmlformats-officedocument.presentationml.presentation'
        )
    
    async def get_available_templates(self) -> Dict[str, Any]:
        """Get available presentation templates"""
        
        templates = self.template_manager.get_available_templates()
        
        # Add preview information
        for template in templates:
            template['color_palette'] = self.template_manager.get_color_palette_preview(template['key'])
            template['chart_colors'] = self.template_manager.get_chart_colors(template['key'])
        
        return {
            'templates': templates,
            'default_template': 'corporate_blue',
            'total_available': len(templates)
        }
    
    async def preview_template(self, template_name: str, dataset_id: str) -> Dict[str, Any]:
        """Generate template preview"""
        
        try:
            # Validate template
            if not self.template_manager.validate_template(template_name):
                raise HTTPException(status_code=404, detail="Template not found")
            
            # Load dataset for preview
            df, metadata = await self._load_dataset(dataset_id)
            if df is None:
                raise HTTPException(status_code=404, detail="Dataset not found")
            
            # Generate preview configuration
            preview_config = {
                'template': template_name,
                'selected_columns': df.columns.tolist()[:5],  # First 5 columns
                'story_mode': 'executive',
                'content_style': 'insights_charts',
                'title': 'Template Preview'
            }
            
            # Get template details
            template = self.template_manager.get_template(template_name)
            
            return {
                'template_name': template_name,
                'template_info': template,
                'preview_config': preview_config,
                'sample_slides': [
                    'Title Slide',
                    'Dataset Overview',
                    f'{df.columns[0]} Analysis' if len(df.columns) > 0 else 'Data Analysis',
                    'Key Insights',
                    'Conclusions'
                ],
                'estimated_slides': len(df.columns) + 4 if len(df.columns) < 10 else 14
            }
        
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Template preview failed: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Preview failed: {str(e)}")
    
    async def _load_dataset(self, dataset_id: str) -> tuple:
        """Load dataset from storage"""
        
        try:
            metadata = self.storage_manager.load_metadata(dataset_id)
            if not metadata:
                return None, None
            
            file_path = metadata.get('file_path')
            if not file_path or not Path(file_path).exists():
                return None, None
            
            # Load dataframe
            filename = metadata.get('filename', '')
            if filename.endswith('.csv'):
                df = pd.read_csv(file_path)
            else:
                df = pd.read_excel(file_path)
            
            return df, metadata
        
        except Exception as e:
            logger.error(f"Failed to load dataset {dataset_id}: {str(e)}")
            return None, None
    
    def _validate_config(self, config: Dict[str, Any], metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and normalize generation configuration"""
        
        validated = {
            'template': config.get('template', 'corporate_blue'),
            'story_mode': config.get('story_mode', 'executive'),
            'content_style': config.get('content_style', 'insights_charts'),
            'title': config.get('title', 'Data Analysis Results'),
            'selected_columns': config.get('selected_columns', []),
            'auto_remove_pii': config.get('auto_remove_pii', True),
            'include_charts': config.get('include_charts', True),
            'include_insights': config.get('include_insights', True),
            'slide_count_target': config.get('slide_count_target', 'auto'),
            'brand_assets': config.get('brand_assets', {}),
            'export_format': config.get('export_format', 'pptx'),
            'quality_settings': config.get('quality_settings', {
                'chart_quality': 'high',
                'slide_size': 'widescreen'
            })
        }
        
        # Validate template exists
        if not self.template_manager.validate_template(validated['template']):
            validated['template'] = 'corporate_blue'  # Fallback to default
        
        # Validate story mode
        valid_story_modes = ['executive', 'analyst', 'investor', 'manager', 'consultant']
        if validated['story_mode'] not in valid_story_modes:
            validated['story_mode'] = 'executive'
        
        # Validate selected columns
        if metadata:
            all_columns = metadata.get('column_names', [])
            pii_columns = self._get_pii_columns(metadata) if validated['auto_remove_pii'] else []
            available_columns = [col for col in all_columns if col not in pii_columns]
            
            # Filter valid columns
            validated['selected_columns'] = [
                col for col in validated['selected_columns'] 
                if col in available_columns
            ]
            
            # Use all available columns if none specified
            if not validated['selected_columns']:
                validated['selected_columns'] = available_columns[:10]  # Limit to 10 for performance
        
        return validated
    
    def _get_pii_columns(self, metadata: Dict[str, Any]) -> List[str]:
        """Get PII columns from metadata"""
        
        analysis_result = metadata.get('analysis_result', {})
        pii_results = analysis_result.get('pii_results', {})
        removed_columns = pii_results.get('removed_columns', [])
        
        return [col['name'] for col in removed_columns]
    
    def _estimate_generation_time(self, df: pd.DataFrame, config: Dict[str, Any]) -> float:
        """Estimate generation time in minutes"""
        
        base_time = 2.0  # Base 2 minutes
        
        # Add time based on data size
        rows = len(df)
        if rows > 10000:
            base_time += 1.0
        elif rows > 50000:
            base_time += 2.0
        
        # Add time based on columns
        columns = len(config.get('selected_columns', []))
        base_time += columns * 0.3
        
        # Add time for charts
        if config.get('include_charts', True):
            base_time += columns * 0.5
        
        # Add time for insights
        if config.get('include_insights', True):
            base_time += 1.0
        
        return round(base_time, 1)
    
    async def _generate_presentation_background(
        self,
        generation_id: str,
        dataset_id: str,
        df: pd.DataFrame,
        config: Dict[str, Any]
    ) -> None:
        """Background presentation generation"""
        
        try:
            status = self.generation_status[generation_id]
            
            # Step 1: Data preparation
            await self._update_status(generation_id, 'analyzing', 1, 'Preparing data for analysis')
            
            # Filter to selected columns
            selected_columns = config['selected_columns']
            analysis_df = df[selected_columns] if selected_columns else df
            
            # Step 2: ML Analysis
            await self._update_status(generation_id, 'analyzing', 2, 'Performing ML analysis')
            
            from ..ml.data_analyzer import MLDataAnalyzer
            data_analyzer = MLDataAnalyzer()
            analysis_results = await data_analyzer.analyze_dataset(analysis_df)
            
            # Step 3: Generate insights
            await self._update_status(generation_id, 'analyzing', 3, 'Generating AI insights')
            
            insights = await self.insights_generator.generate_insights(analysis_results, config)
            analysis_results['ai_insights'] = insights
            
            # Step 4: Generate charts
            chart_paths = {}
            if config.get('include_charts', True):
                await self._update_status(generation_id, 'generating', 4, 'Creating visualizations')
                
                # Set chart theme
                self.chart_generator.set_theme(config['template'])
                
                for column in selected_columns[:8]:  # Limit to 8 charts for performance
                    try:
                        col_type = data_analyzer.detect_column_type(analysis_df[column])
                        chart_type = self.chart_generator.select_optimal_chart(analysis_df[column], col_type)
                        
                        chart_path = f"data/charts/{generation_id}_{column}_{chart_type}.png"
                        generated_path = self.chart_generator.generate_chart(
                            analysis_df[column],
                            column,
                            chart_type,
                            chart_path
                        )
                        
                        if generated_path:
                            chart_paths[column] = generated_path
                    except Exception as e:
                        logger.warning(f"Chart generation failed for {column}: {e}")
            
            # Step 5: Generate correlation matrix if applicable
            numeric_cols = analysis_df.select_dtypes(include=['number']).columns
            if len(numeric_cols) > 1:
                await self._update_status(generation_id, 'generating', 5, 'Creating correlation analysis')
                
                corr_path = f"data/charts/{generation_id}_correlation_matrix.png"
                corr_generated = self.chart_generator.generate_correlation_matrix(
                    analysis_df[numeric_cols],
                    corr_path
                )
                if corr_generated:
                    chart_paths['correlation_matrix'] = corr_generated
            
            # Step 6: Create presentation
            await self._update_status(generation_id, 'creating', 6, 'Building PowerPoint slides')
            
            presentation = self.ppt_generator.create_presentation(
                analysis_results,
                config,
                chart_paths
            )
            
            if not presentation:
                raise Exception("Presentation creation failed")
            
            # Step 7: Save presentation
            await self._update_status(generation_id, 'saving', 7, 'Saving presentation file')
            
            output_path = f"data/generated/presentation_{generation_id}.pptx"
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            
            saved_path = self.ppt_generator.save_presentation(output_path)
            if not saved_path:
                raise Exception("Failed to save presentation")
            
            # Step 8: Finalize
            await self._update_status(generation_id, 'completed', 8, 'Generation complete')
            
            # Update final status
            status.update({
                'status': 'completed',
                'progress': 100,
                'completed_at': datetime.now().isoformat(),
                'presentation_path': saved_path,
                'slide_count': self.ppt_generator.get_slide_count(),
                'charts_generated': len(chart_paths),
                'insights_generated': len(insights),
                'success': True
            })
            
            # Save generation metadata
            generation_metadata = {
                'generation_id': generation_id,
                'dataset_id': dataset_id,
                'config': config,
                'analysis_results': analysis_results,
                'chart_paths': chart_paths,
                'presentation_path': saved_path,
                'generation_time': (
                    datetime.fromisoformat(status['completed_at']) - 
                    datetime.fromisoformat(status['started_at'])
                ).total_seconds()
            }
            
            self.storage_manager.save_generation_metadata(generation_id, generation_metadata)
            
            logger.info(f"Presentation generation completed: {generation_id}")
        
        except Exception as e:
            logger.error(f"Background generation failed for {generation_id}: {str(e)}")
            
            # Update error status
            self.generation_status[generation_id].update({
                'status': 'failed',
                'error': str(e),
                'failed_at': datetime.now().isoformat()
            })
    
    async def _update_status(
        self, 
        generation_id: str, 
        status: str, 
        step: int, 
        current_step: str
    ) -> None:
        """Update generation status"""
        
        if generation_id in self.generation_status:
            self.generation_status[generation_id].update({
                'status': status,
                'progress': int((step / 8) * 100),
                'current_step': current_step,
                'last_updated': datetime.now().isoformat()
            })
        
        # Add small delay to make progress visible
        await asyncio.sleep(0.5)

# API endpoint functions
async def generate_presentation_endpoint(
    dataset_id: str,
    config: Dict[str, Any],
    background_tasks: BackgroundTasks
) -> Dict[str, Any]:
    """Generate presentation endpoint"""
    
    handler = GenerationHandler()
    return await handler.generate_presentation(dataset_id, config, background_tasks)

async def get_generation_status_endpoint(generation_id: str) -> Dict[str, Any]:
    """Get generation status endpoint"""
    
    handler = GenerationHandler()
    return await handler.get_generation_status(generation_id)

async def download_presentation_endpoint(generation_id: str) -> FileResponse:
    """Download presentation endpoint"""
    
    handler = GenerationHandler()
    return await handler.download_presentation(generation_id)

async def get_templates_endpoint() -> Dict[str, Any]:
    """Get available templates endpoint"""
    
    handler = GenerationHandler()
    return await handler.get_available_templates()

async def preview_template_endpoint(template_name: str, dataset_id: str) -> Dict[str, Any]:
    """Preview template endpoint"""
    
    handler = GenerationHandler()
    return await handler.preview_template(template_name, dataset_id)
