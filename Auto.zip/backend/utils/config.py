"""
Configuration Management System
Handles application settings, environment variables, and configurations
"""
import os
import yaml
import json
from pathlib import Path
from typing import Dict, Any, Optional, Union
from dataclasses import dataclass, asdict
from enum import Enum

class Environment(Enum):
    """Environment types"""
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"
    TESTING = "testing"

@dataclass
class DatabaseConfig:
    """Database configuration"""
    host: str = "localhost"
    port: int = 5432
    database: str = "aiml_ppt"
    username: str = "postgres"
    password: str = ""
    ssl_mode: str = "prefer"
    pool_size: int = 10
    max_overflow: int = 20

@dataclass
class StorageConfig:
    """Storage configuration"""
    data_path: str = "./data"
    max_file_size_mb: int = 50
    allowed_extensions: list = None
    cleanup_after_days: int = 30
    backup_enabled: bool = True
    backup_path: str = "./backups"
    
    def __post_init__(self):
        if self.allowed_extensions is None:
            self.allowed_extensions = ['.csv', '.xlsx', '.xls']

@dataclass
class MLConfig:
    """Machine Learning configuration"""
    enable_advanced_analysis: bool = True
    max_correlation_features: int = 50
    clustering_max_clusters: int = 10
    anomaly_detection_threshold: float = 0.05
    pii_detection_confidence: float = 0.8
    insights_max_count: int = 20
    parallel_processing: bool = True
    cache_results: bool = True
    cache_ttl_hours: int = 24

@dataclass
class PPTConfig:
    """PowerPoint generation configuration"""
    default_theme: str = "corporate_blue"
    max_slides: int = 50
    max_charts_per_presentation: int = 20
    chart_quality: str = "high"
    slide_size: str = "widescreen"
    include_speaker_notes: bool = True
    watermark_enabled: bool = False
    export_formats: list = None
    
    def __post_init__(self):
        if self.export_formats is None:
            self.export_formats = ['pptx', 'pdf']

@dataclass
class SecurityConfig:
    """Security configuration"""
    enable_pii_detection: bool = True
    auto_remove_pii: bool = True
    allow_pii_override: bool = True
    data_retention_days: int = 90
    audit_logging: bool = True
    secure_file_deletion: bool = True
    encryption_at_rest: bool = False
    api_rate_limiting: bool = True
    max_requests_per_minute: int = 60

@dataclass
class LoggingConfig:
    """Logging configuration"""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file_path: str = "./logs/app.log"
    max_file_size_mb: int = 100
    backup_count: int = 5
    enable_console: bool = True
    enable_file: bool = True
    structured_logging: bool = False

@dataclass
class APIConfig:
    """API configuration"""
    host: str = "127.0.0.1"
    port: int = 8000
    workers: int = 1
    reload: bool = False
    cors_enabled: bool = True
    cors_origins: list = None
    request_timeout: int = 300
    max_request_size: int = 52428800  # 50MB
    
    def __post_init__(self):
        if self.cors_origins is None:
            self.cors_origins = ["*"]

@dataclass
class FrontendConfig:
    """Frontend configuration"""
    host: str = "127.0.0.1"
    port: int = 8501
    theme: str = "corporate"
    page_title: str = "AI/ML Data to PowerPoint Generator"
    page_icon: str = "🤖"
    layout: str = "wide"
    sidebar_state: str = "expanded"
    max_upload_size: int = 200  # MB

@dataclass
class AppConfig:
    """Main application configuration"""
    environment: Environment = Environment.DEVELOPMENT
    debug: bool = False
    app_name: str = "AI/ML Data to PowerPoint Generator"
    app_version: str = "2.0.0"
    database: DatabaseConfig = None
    storage: StorageConfig = None
    ml: MLConfig = None
    ppt: PPTConfig = None
    security: SecurityConfig = None
    logging: LoggingConfig = None
    api: APIConfig = None
    frontend: FrontendConfig = None
    
    def __post_init__(self):
        if self.database is None:
            self.database = DatabaseConfig()
        if self.storage is None:
            self.storage = StorageConfig()
        if self.ml is None:
            self.ml = MLConfig()
        if self.ppt is None:
            self.ppt = PPTConfig()
        if self.security is None:
            self.security = SecurityConfig()
        if self.logging is None:
            self.logging = LoggingConfig()
        if self.api is None:
            self.api = APIConfig()
        if self.frontend is None:
            self.frontend = FrontendConfig()

class ConfigManager:
    """Configuration management system"""
    
    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or "config/config.yaml"
        self.env_prefix = "AIML_PPT_"
        self._config = None
        self._load_config()
    
    def _load_config(self) -> None:
        """Load configuration from multiple sources"""
        
        # Start with default configuration
        self._config = AppConfig()
        
        # Load from YAML file if exists
        if Path(self.config_path).exists():
            self._load_from_yaml()
        
        # Override with environment variables
        self._load_from_environment()
        
        # Validate configuration
        self._validate_config()
        
        # Create necessary directories
        self._ensure_directories()
    
    def _load_from_yaml(self) -> None:
        """Load configuration from YAML file"""
        
        try:
            with open(self.config_path, 'r') as file:
                yaml_config = yaml.safe_load(file)
            
            if yaml_config:
                self._merge_config_dict(yaml_config)
                
        except Exception as e:
            print(f"Warning: Could not load config from {self.config_path}: {e}")
    
    def _load_from_environment(self) -> None:
        """Load configuration from environment variables"""
        
        # Environment mapping
        env_mappings = {
            f"{self.env_prefix}ENVIRONMENT": ("environment",),
            f"{self.env_prefix}DEBUG": ("debug",),
            f"{self.env_prefix}APP_NAME": ("app_name",),
            f"{self.env_prefix}DATA_PATH": ("storage", "data_path"),
            f"{self.env_prefix}MAX_FILE_SIZE_MB": ("storage", "max_file_size_mb"),
            f"{self.env_prefix}API_HOST": ("api", "host"),
            f"{self.env_prefix}API_PORT": ("api", "port"),
            f"{self.env_prefix}FRONTEND_HOST": ("frontend", "host"),
            f"{self.env_prefix}FRONTEND_PORT": ("frontend", "port"),
            f"{self.env_prefix}LOG_LEVEL": ("logging", "level"),
            f"{self.env_prefix}LOG_FILE": ("logging", "file_path"),
            f"{self.env_prefix}ENABLE_PII_DETECTION": ("security", "enable_pii_detection"),
            f"{self.env_prefix}AUTO_REMOVE_PII": ("security", "auto_remove_pii"),
            f"{self.env_prefix}DEFAULT_THEME": ("ppt", "default_theme"),
            f"{self.env_prefix}MAX_SLIDES": ("ppt", "max_slides"),
            f"{self.env_prefix}DB_HOST": ("database", "host"),
            f"{self.env_prefix}DB_PORT": ("database", "port"),
            f"{self.env_prefix}DB_DATABASE": ("database", "database"),
            f"{self.env_prefix}DB_USERNAME": ("database", "username"),
            f"{self.env_prefix}DB_PASSWORD": ("database", "password"),
        }
        
        for env_var, config_path in env_mappings.items():
            env_value = os.getenv(env_var)
            if env_value is not None:
                self._set_nested_config(config_path, self._parse_env_value(env_value))
    
    def _merge_config_dict(self, config_dict: Dict[str, Any]) -> None:
        """Merge configuration dictionary with current config"""
        
        for section, values in config_dict.items():
            if hasattr(self._config, section) and isinstance(values, dict):
                section_config = getattr(self._config, section)
                
                for key, value in values.items():
                    if hasattr(section_config, key):
                        setattr(section_config, key, value)
            elif hasattr(self._config, section):
                setattr(self._config, section, values)
    
    def _set_nested_config(self, path: tuple, value: Any) -> None:
        """Set nested configuration value"""
        
        current = self._config
        for key in path[:-1]:
            if hasattr(current, key):
                current = getattr(current, key)
            else:
                return  # Path doesn't exist
        
        final_key = path[-1]
        if hasattr(current, final_key):
            # Convert type if necessary
            current_value = getattr(current, final_key)
            if isinstance(current_value, bool):
                value = self._str_to_bool(value)
            elif isinstance(current_value, int):
                value = int(value)
            elif isinstance(current_value, float):
                value = float(value)
            
            setattr(current, final_key, value)
    
    def _parse_env_value(self, value: str) -> Union[str, int, float, bool, list]:
        """Parse environment variable value to appropriate type"""
        
        # Boolean
        if value.lower() in ('true', 'false'):
            return value.lower() == 'true'
        
        # Integer
        if value.isdigit():
            return int(value)
        
        # Float
        try:
            return float(value)
        except ValueError:
            pass
        
        # List (comma-separated)
        if ',' in value:
            return [item.strip() for item in value.split(',')]
        
        # String
        return value
    
    def _str_to_bool(self, value: str) -> bool:
        """Convert string to boolean"""
        return str(value).lower() in ('true', '1', 'yes', 'on')
    
    def _validate_config(self) -> None:
        """Validate configuration values"""
        
        # Validate paths
        if not Path(self._config.storage.data_path).is_absolute():
            self._config.storage.data_path = str(Path(self._config.storage.data_path).resolve())
        
        # Validate ports
        if not (1024 <= self._config.api.port <= 65535):
            self._config.api.port = 8000
        
        if not (1024 <= self._config.frontend.port <= 65535):
            self._config.frontend.port = 8501
        
        # Validate file sizes
        if self._config.storage.max_file_size_mb <= 0:
            self._config.storage.max_file_size_mb = 50
        
        # Validate ML parameters
        if self._config.ml.max_correlation_features <= 0:
            self._config.ml.max_correlation_features = 50
        
        # Validate logging level
        valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if self._config.logging.level.upper() not in valid_levels:
            self._config.logging.level = 'INFO'
    
    def _ensure_directories(self) -> None:
        """Create necessary directories"""
        
        directories_to_create = [
            self._config.storage.data_path,
            f"{self._config.storage.data_path}/uploads",
            f"{self._config.storage.data_path}/generated",
            f"{self._config.storage.data_path}/charts",
            f"{self._config.storage.data_path}/history",
            f"{self._config.storage.data_path}/thumbnails",
            Path(self._config.logging.file_path).parent,
        ]
        
        if self._config.storage.backup_enabled:
            directories_to_create.append(self._config.storage.backup_path)
        
        for directory in directories_to_create:
            Path(directory).mkdir(parents=True, exist_ok=True)
    
    @property
    def config(self) -> AppConfig:
        """Get current configuration"""
        return self._config
    
    def get_database_url(self) -> str:
        """Get database connection URL"""
        db = self._config.database
        return f"postgresql://{db.username}:{db.password}@{db.host}:{db.port}/{db.database}"
    
    def get_redis_url(self) -> Optional[str]:
        """Get Redis connection URL (if configured)"""
        # This would be implemented if Redis caching is needed
        return None
    
    def is_development(self) -> bool:
        """Check if running in development mode"""
        return self._config.environment == Environment.DEVELOPMENT
    
    def is_production(self) -> bool:
        """Check if running in production mode"""
        return self._config.environment == Environment.PRODUCTION
    
    def get_cors_settings(self) -> Dict[str, Any]:
        """Get CORS configuration for FastAPI"""
        return {
            "allow_origins": self._config.api.cors_origins,
            "allow_credentials": True,
            "allow_methods": ["*"],
            "allow_headers": ["*"],
        }
    
    def get_logging_config(self) -> Dict[str, Any]:
        """Get logging configuration dictionary"""
        return {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "standard": {
                    "format": self._config.logging.format
                },
                "detailed": {
                    "format": "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s"
                }
            },
            "handlers": {
                "console": {
                    "level": self._config.logging.level,
                    "class": "logging.StreamHandler",
                    "formatter": "standard"
                },
                "file": {
                    "level": self._config.logging.level,
                    "class": "logging.handlers.RotatingFileHandler",
                    "filename": self._config.logging.file_path,
                    "formatter": "detailed",
                    "maxBytes": self._config.logging.max_file_size_mb * 1024 * 1024,
                    "backupCount": self._config.logging.backup_count
                }
            },
            "root": {
                "level": self._config.logging.level,
                "handlers": ["console", "file"] if self._config.logging.enable_file else ["console"]
            }
        }
    
    def export_config(self, format: str = "yaml") -> str:
        """Export current configuration"""
        
        config_dict = asdict(self._config)
        
        # Convert enums to strings
        config_dict["environment"] = config_dict["environment"].value
        
        if format.lower() == "json":
            return json.dumps(config_dict, indent=2)
        elif format.lower() == "yaml":
            return yaml.dump(config_dict, default_flow_style=False, indent=2)
        else:
            raise ValueError(f"Unsupported format: {format}")
    
    def save_config(self, path: Optional[str] = None) -> None:
        """Save current configuration to file"""
        
        save_path = path or self.config_path
        config_yaml = self.export_config("yaml")
        
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        
        with open(save_path, 'w') as file:
            file.write(config_yaml)
    
    def reload_config(self) -> None:
        """Reload configuration from sources"""
        self._load_config()
    
    def update_config(self, updates: Dict[str, Any]) -> None:
        """Update configuration with new values"""
        self._merge_config_dict(updates)
        self._validate_config()
    
    def get_feature_flags(self) -> Dict[str, bool]:
        """Get feature flags configuration"""
        return {
            "enable_advanced_analysis": self._config.ml.enable_advanced_analysis,
            "enable_pii_detection": self._config.security.enable_pii_detection,
            "auto_remove_pii": self._config.security.auto_remove_pii,
            "allow_pii_override": self._config.security.allow_pii_override,
            "parallel_processing": self._config.ml.parallel_processing,
            "cache_results": self._config.ml.cache_results,
            "audit_logging": self._config.security.audit_logging,
            "backup_enabled": self._config.storage.backup_enabled,
            "cors_enabled": self._config.api.cors_enabled,
            "rate_limiting": self._config.security.api_rate_limiting
        }

# Global configuration instance
config_manager = ConfigManager()

def get_config() -> AppConfig:
    """Get global configuration instance"""
    return config_manager.config

def get_database_url() -> str:
    """Get database connection URL"""
    return config_manager.get_database_url()

def is_development() -> bool:
    """Check if running in development mode"""
    return config_manager.is_development()

def is_production() -> bool:
    """Check if running in production mode"""
    return config_manager.is_production()
