"""
Enhanced Storage Management System
Handles file operations, metadata management, and data persistence
"""
import os
import json
import pickle
import shutil
import hashlib
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Union
import pandas as pd
from contextlib import contextmanager

from .logger import setup_logger
from .config import get_config

logger = setup_logger(__name__)

class StorageManager:
    """Enhanced storage management with SQLite backend"""
    
    def __init__(self):
        self.config = get_config()
        self.base_path = Path(self.config.storage.data_path)
        self.db_path = self.base_path / "metadata.db"
        
        # Initialize storage structure
        self._initialize_storage()
        self._initialize_database()
    
    def _initialize_storage(self) -> None:
        """Initialize storage directory structure"""
        
        directories = [
            self.base_path,
            self.base_path / "uploads",
            self.base_path / "generated",
            self.base_path / "charts",
            self.base_path / "thumbnails",
            self.base_path / "history",
            self.base_path / "temp",
            self.base_path / "backups"
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Storage initialized at {self.base_path}")
    
    def _initialize_database(self) -> None:
        """Initialize SQLite database for metadata"""
        
        with self._get_db_connection() as conn:
            cursor = conn.cursor()
            
            # Datasets table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS datasets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    dataset_id TEXT UNIQUE NOT NULL,
                    filename TEXT NOT NULL,
                    file_hash TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    upload_timestamp TEXT NOT NULL,
                    file_size_bytes INTEGER NOT NULL,
                    rows INTEGER,
                    columns INTEGER,
                    metadata_json TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Presentations table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS presentations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    generation_id TEXT UNIQUE NOT NULL,
                    dataset_id TEXT NOT NULL,
                    title TEXT,
                    template_name TEXT,
                    story_mode TEXT,
                    presentation_path TEXT,
                    slide_count INTEGER,
                    chart_count INTEGER,
                    generation_time REAL,
                    config_json TEXT,
                    analysis_results_json TEXT,
                    status TEXT DEFAULT 'completed',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (dataset_id) REFERENCES datasets (dataset_id)
                )
            """)
            
            # Analysis results table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS analysis_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    dataset_id TEXT NOT NULL,
                    analysis_type TEXT NOT NULL,
                    results_json TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (dataset_id) REFERENCES datasets (dataset_id)
                )
            """)
            
            # File operations log table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS file_operations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    operation_type TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    file_hash TEXT,
                    status TEXT NOT NULL,
                    details TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_datasets_hash ON datasets (file_hash)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_presentations_dataset ON presentations (dataset_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_analysis_dataset ON analysis_results (dataset_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_file_ops_timestamp ON file_operations (timestamp)")
            
            conn.commit()
        
        logger.info("Database initialized successfully")
    
    @contextmanager
    def _get_db_connection(self):
        """Get database connection context manager"""
        
        conn = sqlite3.connect(
            self.db_path,
            timeout=30.0,
            isolation_level=None  # Auto-commit mode
        )
        conn.row_factory = sqlite3.Row  # Enable column access by name
        
        try:
            yield conn
        finally:
            conn.close()
    
    def save_uploaded_file(self, dataset_id: str, filename: str, content: bytes) -> str:
        """Save uploaded file and return path"""
        
        try:
            # Generate unique filename to avoid conflicts
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_filename = self._sanitize_filename(filename)
            unique_filename = f"{dataset_id}_{timestamp}_{safe_filename}"
            
            file_path = self.base_path / "uploads" / unique_filename
            
            # Save file
            with open(file_path, 'wb') as f:
                f.write(content)
            
            # Log operation
            file_hash = hashlib.md5(content).hexdigest()
            self._log_file_operation("upload", str(file_path), file_hash, "success")
            
            logger.info(f"File saved: {file_path}")
            return str(file_path)
        
        except Exception as e:
            logger.error(f"Failed to save uploaded file: {str(e)}")
            self._log_file_operation("upload", filename, None, "failed", str(e))
            raise
    
    def save_metadata(self, dataset_id: str, metadata: Dict[str, Any]) -> None:
        """Save dataset metadata to database"""
        
        try:
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    INSERT OR REPLACE INTO datasets 
                    (dataset_id, filename, file_hash, file_path, upload_timestamp, 
                     file_size_bytes, rows, columns, metadata_json, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                """, (
                    dataset_id,
                    metadata.get('filename'),
                    metadata.get('file_hash'),
                    metadata.get('file_path'),
                    metadata.get('upload_timestamp'),
                    metadata.get('file_size_bytes'),
                    metadata.get('rows'),
                    metadata.get('columns'),
                    json.dumps(metadata)
                ))
            
            logger.info(f"Metadata saved for dataset: {dataset_id}")
        
        except Exception as e:
            logger.error(f"Failed to save metadata for {dataset_id}: {str(e)}")
            raise
    
    def load_metadata(self, dataset_id: str) -> Optional[Dict[str, Any]]:
        """Load dataset metadata from database"""
        
        try:
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute(
                    "SELECT metadata_json FROM datasets WHERE dataset_id = ?",
                    (dataset_id,)
                )
                
                row = cursor.fetchone()
                if row:
                    return json.loads(row['metadata_json'])
                
                return None
        
        except Exception as e:
            logger.error(f"Failed to load metadata for {dataset_id}: {str(e)}")
            return None
    
    def save_generation_metadata(self, generation_id: str, metadata: Dict[str, Any]) -> None:
        """Save presentation generation metadata"""
        
        try:
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                config = metadata.get('config', {})
                
                cursor.execute("""
                    INSERT OR REPLACE INTO presentations 
                    (generation_id, dataset_id, title, template_name, story_mode, 
                     presentation_path, slide_count, chart_count, generation_time,
                     config_json, analysis_results_json, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    generation_id,
                    metadata.get('dataset_id'),
                    config.get('title'),
                    config.get('template'),
                    config.get('story_mode'),
                    metadata.get('presentation_path'),
                    metadata.get('slide_count', 0),
                    len(metadata.get('chart_paths', {})),
                    metadata.get('generation_time', 0),
                    json.dumps(config),
                    json.dumps(metadata.get('analysis_results', {})),
                    'completed'
                ))
            
            logger.info(f"Generation metadata saved: {generation_id}")
        
        except Exception as e:
            logger.error(f"Failed to save generation metadata for {generation_id}: {str(e)}")
            raise
    
    def load_generation_metadata(self, generation_id: str) -> Optional[Dict[str, Any]]:
        """Load presentation generation metadata"""
        
        try:
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT p.*, d.filename, d.file_path as dataset_file_path
                    FROM presentations p
                    LEFT JOIN datasets d ON p.dataset_id = d.dataset_id
                    WHERE p.generation_id = ?
                """, (generation_id,))
                
                row = cursor.fetchone()
                if row:
                    # Reconstruct metadata dictionary
                    metadata = {
                        'generation_id': row['generation_id'],
                        'dataset_id': row['dataset_id'],
                        'presentation_path': row['presentation_path'],
                        'slide_count': row['slide_count'],
                        'generation_time': row['generation_time'],
                        'status': row['status'],
                        'created_at': row['created_at'],
                        'config': json.loads(row['config_json']) if row['config_json'] else {},
                        'analysis_results': json.loads(row['analysis_results_json']) if row['analysis_results_json'] else {},
                        'dataset_filename': row['filename'],
                        'dataset_file_path': row['dataset_file_path']
                    }
                    return metadata
                
                return None
        
        except Exception as e:
            logger.error(f"Failed to load generation metadata for {generation_id}: {str(e)}")
            return None
    
    def save_analysis_results(self, dataset_id: str, analysis_results: Dict[str, Any]) -> None:
        """Save analysis results to database"""
        
        try:
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                analysis_type = analysis_results.get('analysis_type', 'comprehensive')
                
                cursor.execute("""
                    INSERT INTO analysis_results 
                    (dataset_id, analysis_type, results_json)
                    VALUES (?, ?, ?)
                """, (
                    dataset_id,
                    analysis_type,
                    json.dumps(analysis_results)
                ))
            
            logger.info(f"Analysis results saved for dataset: {dataset_id}")
        
        except Exception as e:
            logger.error(f"Failed to save analysis results for {dataset_id}: {str(e)}")
            raise
    
    def update_analysis_results(self, dataset_id: str, analysis_results: Dict[str, Any]) -> None:
        """Update existing dataset with enhanced analysis results"""
        
        try:
            # Get existing metadata
            existing_metadata = self.load_metadata(dataset_id)
            if existing_metadata:
                # Merge analysis results
                existing_metadata['analysis_result'].update(analysis_results)
                
                # Save updated metadata
                self.save_metadata(dataset_id, existing_metadata)
            
            # Also save as separate analysis record
            self.save_analysis_results(dataset_id, analysis_results)
        
        except Exception as e:
            logger.error(f"Failed to update analysis results for {dataset_id}: {str(e)}")
            raise
    
    def get_all_presentations(self) -> List[Dict[str, Any]]:
        """Get all presentations with metadata"""
        
        try:
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT p.*, d.filename, d.rows, d.columns
                    FROM presentations p
                    LEFT JOIN datasets d ON p.dataset_id = d.dataset_id
                    ORDER BY p.created_at DESC
                """)
                
                presentations = []
                for row in cursor.fetchall():
                    presentation = {
                        'generation_id': row['generation_id'],
                        'dataset_id': row['dataset_id'],
                        'title': row['title'],
                        'template_name': row['template_name'],
                        'story_mode': row['story_mode'],
                        'presentation_path': row['presentation_path'],
                        'slide_count': row['slide_count'],
                        'chart_count': row['chart_count'],
                        'generation_time': row['generation_time'],
                        'status': row['status'],
                        'created_at': row['created_at'],
                        'dataset_filename': row['filename'],
                        'dataset_rows': row['rows'],
                        'dataset_columns': row['columns'],
                        'config': json.loads(row['config_json']) if row['config_json'] else {}
                    }
                    
                    # Add chart paths if available
                    if row['analysis_results_json']:
                        analysis_results = json.loads(row['analysis_results_json'])
                        presentation['chart_paths'] = analysis_results.get('chart_paths', {})
                    
                    presentations.append(presentation)
                
                return presentations
        
        except Exception as e:
            logger.error(f"Failed to get all presentations: {str(e)}")
            return []
    
    def delete_generation_metadata(self, generation_id: str) -> None:
        """Delete presentation generation metadata"""
        
        try:
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("DELETE FROM presentations WHERE generation_id = ?", (generation_id,))
            
            logger.info(f"Generation metadata deleted: {generation_id}")
        
        except Exception as e:
            logger.error(f"Failed to delete generation metadata for {generation_id}: {str(e)}")
            raise
    
    def file_exists(self, file_hash: str) -> bool:
        """Check if file with given hash already exists"""
        
        try:
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("SELECT COUNT(*) as count FROM datasets WHERE file_hash = ?", (file_hash,))
                row = cursor.fetchone()
                
                return row['count'] > 0
        
        except Exception as e:
            logger.error(f"Failed to check file existence: {str(e)}")
            return False
    
    def get_file_by_hash(self, file_hash: str) -> Optional[Dict[str, Any]]:
        """Get file metadata by hash"""
        
        try:
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute(
                    "SELECT metadata_json FROM datasets WHERE file_hash = ?",
                    (file_hash,)
                )
                
                row = cursor.fetchone()
                if row:
                    return json.loads(row['metadata_json'])
                
                return None
        
        except Exception as e:
            logger.error(f"Failed to get file by hash: {str(e)}")
            return None
    
    def cleanup_old_files(self, days: int = None) -> Dict[str, int]:
        """Clean up old files based on retention policy"""
        
        if days is None:
            days = self.config.storage.cleanup_after_days
        
        cutoff_date = datetime.now() - timedelta(days=days)
        
        cleanup_stats = {
            'datasets_deleted': 0,
            'presentations_deleted': 0,
            'files_deleted': 0,
            'space_freed_mb': 0
        }
        
        try:
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                # Find old datasets
                cursor.execute("""
                    SELECT dataset_id, file_path FROM datasets 
                    WHERE created_at < ?
                """, (cutoff_date.isoformat(),))
                
                old_datasets = cursor.fetchall()
                
                for dataset in old_datasets:
                    dataset_id = dataset['dataset_id']
                    file_path = dataset['file_path']
                    
                    # Delete associated presentations first
                    cursor.execute("SELECT presentation_path FROM presentations WHERE dataset_id = ?", (dataset_id,))
                    presentations = cursor.fetchall()
                    
                    for pres in presentations:
                        if pres['presentation_path'] and Path(pres['presentation_path']).exists():
                            file_size = Path(pres['presentation_path']).stat().st_size
                            Path(pres['presentation_path']).unlink()
                            cleanup_stats['space_freed_mb'] += file_size / (1024 * 1024)
                            cleanup_stats['files_deleted'] += 1
                    
                    cursor.execute("DELETE FROM presentations WHERE dataset_id = ?", (dataset_id,))
                    cleanup_stats['presentations_deleted'] += len(presentations)
                    
                    # Delete dataset file
                    if file_path and Path(file_path).exists():
                        file_size = Path(file_path).stat().st_size
                        Path(file_path).unlink()
                        cleanup_stats['space_freed_mb'] += file_size / (1024 * 1024)
                        cleanup_stats['files_deleted'] += 1
                    
                    # Delete dataset metadata
                    cursor.execute("DELETE FROM analysis_results WHERE dataset_id = ?", (dataset_id,))
                    cursor.execute("DELETE FROM datasets WHERE dataset_id = ?", (dataset_id,))
                    cleanup_stats['datasets_deleted'] += 1
                
                # Clean up orphaned files
                self._cleanup_orphaned_files(cleanup_stats)
                
                logger.info(f"Cleanup completed: {cleanup_stats}")
                
        except Exception as e:
            logger.error(f"Cleanup failed: {str(e)}")
        
        return cleanup_stats
    
    def _cleanup_orphaned_files(self, stats: Dict[str, int]) -> None:
        """Clean up orphaned files that don't have database records"""
        
        try:
            # Check uploads directory
            uploads_dir = self.base_path / "uploads"
            if uploads_dir.exists():
                for file_path in uploads_dir.glob("*"):
                    if file_path.is_file():
                        # Check if file is referenced in database
                        with self._get_db_connection() as conn:
                            cursor = conn.cursor()
                            cursor.execute("SELECT COUNT(*) as count FROM datasets WHERE file_path = ?", (str(file_path),))
                            row = cursor.fetchone()
                            
                            if row['count'] == 0:
                                # Orphaned file
                                file_size = file_path.stat().st_size
                                file_path.unlink()
                                stats['space_freed_mb'] += file_size / (1024 * 1024)
                                stats['files_deleted'] += 1
            
            # Check generated presentations directory
            generated_dir = self.base_path / "generated"
            if generated_dir.exists():
                for file_path in generated_dir.glob("*.pptx"):
                    if file_path.is_file():
                        with self._get_db_connection() as conn:
                            cursor = conn.cursor()
                            cursor.execute("SELECT COUNT(*) as count FROM presentations WHERE presentation_path = ?", (str(file_path),))
                            row = cursor.fetchone()
                            
                            if row['count'] == 0:
                                # Orphaned presentation file
                                file_size = file_path.stat().st_size
                                file_path.unlink()
                                stats['space_freed_mb'] += file_size / (1024 * 1024)
                                stats['files_deleted'] += 1
        
        except Exception as e:
            logger.error(f"Orphaned file cleanup failed: {str(e)}")
    
    def cleanup_file(self, file_path: str) -> bool:
        """Clean up single file"""
        
        try:
            if Path(file_path).exists():
                Path(file_path).unlink()
                self._log_file_operation("delete", file_path, None, "success")
                return True
            return False
        
        except Exception as e:
            logger.error(f"Failed to cleanup file {file_path}: {str(e)}")
            self._log_file_operation("delete", file_path, None, "failed", str(e))
            return False
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get storage usage statistics"""
        
        try:
            stats = {
                'total_datasets': 0,
                'total_presentations': 0,
                'total_files': 0,
                'total_size_mb': 0,
                'by_type': {},
                'by_date': {},
                'disk_usage': {}
            }
            
            # Database statistics
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                # Count datasets
                cursor.execute("SELECT COUNT(*) as count FROM datasets")
                stats['total_datasets'] = cursor.fetchone()['count']
                
                # Count presentations
                cursor.execute("SELECT COUNT(*) as count FROM presentations")
                stats['total_presentations'] = cursor.fetchone()['count']
            
            # File system statistics
            for directory_name in ['uploads', 'generated', 'charts', 'thumbnails']:
                directory = self.base_path / directory_name
                if directory.exists():
                    dir_stats = self._get_directory_stats(directory)
                    stats['by_type'][directory_name] = dir_stats
                    stats['total_files'] += dir_stats['file_count']
                    stats['total_size_mb'] += dir_stats['size_mb']
            
            # Overall disk usage
            if self.base_path.exists():
                stats['disk_usage'] = self._get_directory_stats(self.base_path)
            
            return stats
        
        except Exception as e:
            logger.error(f"Failed to get storage stats: {str(e)}")
            return {}
    
    def _get_directory_stats(self, directory: Path) -> Dict[str, Any]:
        """Get statistics for a directory"""
        
        stats = {
            'file_count': 0,
            'size_bytes': 0,
            'size_mb': 0,
            'last_modified': None
        }
        
        try:
            if not directory.exists():
                return stats
            
            latest_mtime = 0
            
            for file_path in directory.rglob('*'):
                if file_path.is_file():
                    file_stat = file_path.stat()
                    stats['file_count'] += 1
                    stats['size_bytes'] += file_stat.st_size
                    
                    if file_stat.st_mtime > latest_mtime:
                        latest_mtime = file_stat.st_mtime
            
            stats['size_mb'] = round(stats['size_bytes'] / (1024 * 1024), 2)
            
            if latest_mtime > 0:
                stats['last_modified'] = datetime.fromtimestamp(latest_mtime).isoformat()
        
        except Exception as e:
            logger.error(f"Failed to get directory stats for {directory}: {str(e)}")
        
        return stats
    
    def _log_file_operation(
        self, 
        operation_type: str, 
        file_path: str, 
        file_hash: Optional[str], 
        status: str, 
        details: Optional[str] = None
    ) -> None:
        """Log file operation to database"""
        
        try:
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    INSERT INTO file_operations 
                    (operation_type, file_path, file_hash, status, details)
                    VALUES (?, ?, ?, ?, ?)
                """, (operation_type, file_path, file_hash, status, details))
        
        except Exception as e:
            logger.error(f"Failed to log file operation: {str(e)}")
    
    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for safe storage"""
        
        # Remove or replace dangerous characters
        import re
        
        # Replace dangerous characters with underscores
        sanitized = re.sub(r'[<>:"/\\|?*]', '_', filename)
        
        # Remove leading/trailing whitespace and dots
        sanitized = sanitized.strip('. ')
        
        # Ensure filename is not empty
        if not sanitized:
            sanitized = "unnamed_file"
        
        # Limit length
        if len(sanitized) > 100:
            name, ext = os.path.splitext(sanitized)
            max_name_length = 100 - len(ext)
            sanitized = name[:max_name_length] + ext
        
        return sanitized
    
    def backup_database(self) -> str:
        """Create database backup"""
        
        try:
            backup_filename = f"metadata_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
            backup_path = self.base_path / "backups" / backup_filename
            
            # Copy database file
            shutil.copy2(self.db_path, backup_path)
            
            logger.info(f"Database backup created: {backup_path}")
            return str(backup_path)
        
        except Exception as e:
            logger.error(f"Database backup failed: {str(e)}")
            raise
    
    def restore_database(self, backup_path: str) -> bool:
        """Restore database from backup"""
        
        try:
            if not Path(backup_path).exists():
                raise FileNotFoundError(f"Backup file not found: {backup_path}")
            
            # Close any existing connections
            # Copy backup over current database
            shutil.copy2(backup_path, self.db_path)
            
            logger.info(f"Database restored from: {backup_path}")
            return True
        
        except Exception as e:
            logger.error(f"Database restore failed: {str(e)}")
            return False
    
    def health_check(self) -> Dict[str, Any]:
        """Perform storage health check"""
        
        health_status = {
            'status': 'healthy',
            'checks': {},
            'warnings': [],
            'errors': []
        }
        
        try:
            # Check database connectivity
            with self._get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM datasets")
                health_status['checks']['database'] = 'ok'
            
            # Check directory structure
            required_dirs = ['uploads', 'generated', 'charts', 'history']
            for dir_name in required_dirs:
                dir_path = self.base_path / dir_name
                if dir_path.exists():
                    health_status['checks'][f'dir_{dir_name}'] = 'ok'
                else:
                    health_status['checks'][f'dir_{dir_name}'] = 'missing'
                    health_status['warnings'].append(f"Missing directory: {dir_name}")
            
            # Check disk space
            disk_usage = shutil.disk_usage(self.base_path)
            free_gb = disk_usage.free / (1024 ** 3)
            
            if free_gb < 1:  # Less than 1GB free
                health_status['warnings'].append(f"Low disk space: {free_gb:.1f}GB free")
            
            health_status['checks']['disk_space_gb'] = round(free_gb, 1)
            
            # Check for orphaned files
            stats = self.get_storage_stats()
            if stats:
                health_status['checks']['total_files'] = stats['total_files']
                health_status['checks']['total_size_mb'] = stats['total_size_mb']
            
            # Overall status
            if health_status['errors']:
                health_status['status'] = 'unhealthy'
            elif health_status['warnings']:
                health_status['status'] = 'warning'
        
        except Exception as e:
            health_status['status'] = 'unhealthy'
            health_status['errors'].append(str(e))
            logger.error(f"Storage health check failed: {str(e)}")
        
        return health_status
