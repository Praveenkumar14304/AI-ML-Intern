"""
PowerPoint Generation Engine with Advanced Features
Creates professional presentations with AI/ML insights
"""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Any, Optional
import io
import base64
from PIL import Image
import matplotlib.pyplot as plt

class PPTGenerator:
    """Advanced PowerPoint generator with AI/ML integration"""
    
    def __init__(self):
        self.presentation = None
        self.themes = {
            'corporate': {
                'primary_color': RGBColor(255, 102, 0),    # Orange
                'secondary_color': RGBColor(0, 0, 0),       # Black
                'accent_color': RGBColor(245, 245, 245),    # Light Gray
                'text_color': RGBColor(26, 26, 26),         # Dark Gray
                'background_color': RGBColor(255, 255, 255), # White
                'font_name': 'Calibri'
            },
            'modern': {
                'primary_color': RGBColor(0, 122, 204),     # Blue
                'secondary_color': RGBColor(44, 62, 80),    # Dark Blue
                'accent_color': RGBColor(236, 240, 241),    # Light Blue
                'text_color': RGBColor(44, 62, 80),         # Dark Blue
                'background_color': RGBColor(255, 255, 255), # White
                'font_name': 'Segoe UI'
            }
        }
        self.current_theme = 'corporate'
        self.slide_layouts = {}
    
    def create_presentation(
        self, 
        analysis_data: Dict[str, Any],
        config: Dict[str, Any],
        chart_paths: Dict[str, str] = None
    ) -> Presentation:
        """Create complete presentation with all slides"""
        
        try:
            # Initialize presentation
            self.presentation = Presentation()
            self._setup_slide_layouts()
            
            # Apply theme
            theme_name = config.get('theme', 'corporate')
            self.current_theme = theme_name if theme_name in self.themes else 'corporate'
            
            # Create slides
            self._create_title_slide(config)
            self._create_overview_slide(analysis_data, config)
            self._create_objectives_slide(config)
            
            # Create analysis slides for each column
            column_analysis = analysis_data.get('column_analysis', {})
            for column_name, column_data in column_analysis.items():
                chart_path = chart_paths.get(column_name) if chart_paths else None
                self._create_analysis_slide(column_name, column_data, chart_path)
            
            # Create insights slide
            if analysis_data.get('insights'):
                self._create_insights_slide(analysis_data['insights'])
            
            # Create correlation slide if correlations exist
            correlations = analysis_data.get('correlations', {})
            if correlations.get('strong_correlations'):
                self._create_correlation_slide(correlations)
            
            # Create conclusions slide
            self._create_conclusions_slide(analysis_data, config)
            
            # Create thank you slide
            self._create_thank_you_slide(config)
            
            return self.presentation
        
        except Exception as e:
            print(f"Error creating presentation: {e}")
            return None
    
    def _setup_slide_layouts(self):
        """Setup custom slide layouts"""
        # Get existing layouts
        layouts = self.presentation.slide_layouts
        
        self.slide_layouts = {
            'title': layouts[0],           # Title slide
            'title_content': layouts[1],   # Title and content
            'section_header': layouts[2],  # Section header
            'two_content': layouts[3],     # Two content
            'comparison': layouts[4],      # Comparison
            'title_only': layouts[5],      # Title only
            'blank': layouts[6]            # Blank
        }
    
    def _create_title_slide(self, config: Dict[str, Any]) -> None:
        """Create title slide"""
        
        slide = self.presentation.slides.add_slide(self.slide_layouts['title'])
        
        # Title
        title = slide.shapes.title
        title.text = config.get('title', 'Data Analysis Results')
        self._format_title_text(title.text_frame)
        
        # Subtitle
        subtitle = slide.placeholders[1]
        subtitle_text = f"""Comprehensive AI/ML Analysis Report
Generated on {pd.Timestamp.now().strftime('%B %d, %Y')}
Enhanced with PII Protection & Advanced Analytics"""
        
        subtitle.text = subtitle_text
        self._format_subtitle_text(subtitle.text_frame)
        
        # Add company branding if provided
        brand_assets = config.get('brand_assets', {})
        if brand_assets.get('company_name'):
            self._add_company_branding(slide, brand_assets)
        
        # Add logo if provided
        if brand_assets.get('logo'):
            self._add_logo(slide, brand_assets['logo'])
    
    def _create_overview_slide(self, analysis_data: Dict[str, Any], config: Dict[str, Any]) -> None:
        """Create dataset overview slide"""
        
        slide = self.presentation.slides.add_slide(self.slide_layouts['title_content'])
        
        # Title
        title = slide.shapes.title
        title.text = "📊 Dataset Overview"
        self._format_slide_title(title.text_frame)
        
        # Content area
        content_placeholder = slide.placeholders[1]
        
        # Get data summary
        dataset_summary = analysis_data.get('dataset_summary', {})
        selected_columns = config.get('selected_columns', [])
        
        overview_text = f"""Dataset Characteristics:
• Total Records: {dataset_summary.get('rows', 'N/A'):,}
• Total Variables: {dataset_summary.get('columns', 'N/A')}
• Selected for Analysis: {len(selected_columns)} columns
• Data Quality: {100 - dataset_summary.get('null_percentage', 0):.1f}% complete
• Total Size: {dataset_summary.get('memory_usage_mb', 0):.1f} MB

Analysis Configuration:
• Story Mode: {config.get('story_mode', 'Executive').title()}
• Content Style: {config.get('content_style', 'insights_charts').replace('_', ' ').title()}
• PII Protection: {'Enabled' if config.get('auto_remove_pii') else 'Manual'}

Selected Variables:"""
        
        # Add selected columns
        for i, col in enumerate(selected_columns[:8], 1):  # Show first 8
            overview_text += f"\n{i}. {col}"
        
        if len(selected_columns) > 8:
            overview_text += f"\n... and {len(selected_columns) - 8} more variables"
        
        content_placeholder.text = overview_text
        self._format_content_text(content_placeholder.text_frame)
    
    def _create_objectives_slide(self, config: Dict[str, Any]) -> None:
        """Create analysis objectives slide"""
        
        slide = self.presentation.slides.add_slide(self.slide_layouts['title_content'])
        
        # Title
        title = slide.shapes.title
        title.text = "🎯 Analysis Objectives"
        self._format_slide_title(title.text_frame)
        
        # Content
        content_placeholder = slide.placeholders[1]
        
        story_mode = config.get('story_mode', 'executive')
        
        # Customize objectives based on story mode
        if story_mode == 'executive':
            objectives = [
                "Identify key business drivers and performance indicators",
                "Discover strategic opportunities and risk factors",
                "Provide actionable insights for decision-making",
                "Ensure data privacy and regulatory compliance",
                "Present findings in executive-friendly format"
            ]
        elif story_mode == 'analyst':
            objectives = [
                "Conduct comprehensive statistical analysis",
                "Identify patterns, trends, and anomalies",
                "Perform correlation and relationship analysis",
                "Generate detailed technical insights",
                "Provide methodological transparency"
            ]
        elif story_mode == 'investor':
            objectives = [
                "Analyze growth potential and market opportunities",
                "Identify key performance metrics and KPIs",
                "Assess risk factors and mitigation strategies",
                "Provide data-driven investment insights",
                "Benchmark against industry standards"
            ]
        else:
            objectives = [
                "Analyze data quality and completeness",
                "Identify key patterns and relationships",
                "Generate actionable business insights",
                "Ensure privacy and compliance standards",
                "Provide clear, data-driven recommendations"
            ]
        
        objectives_text = "Key Analysis Goals:\n\n"
        for i, obj in enumerate(objectives, 1):
            objectives_text += f"{i}. {obj}\n\n"
        
        objectives_text += f"""
Analysis Approach:
• Advanced statistical analysis with ML algorithms
• Multi-dimensional pattern recognition
• Automated insight generation
• Privacy-first data handling
• Professional visualization standards"""
        
        content_placeholder.text = objectives_text
        self._format_content_text(content_placeholder.text_frame)
    
    def _create_analysis_slide(
        self, 
        column_name: str, 
        column_data: Dict[str, Any], 
        chart_path: Optional[str] = None
    ) -> None:
        """Create individual column analysis slide"""
        
        slide = self.presentation.slides.add_slide(self.slide_layouts['two_content'])
        
        # Title
        title = slide.shapes.title
        title.text = f"📈 {column_name} Analysis"
        self._format_slide_title(title.text_frame)
        
        # Left content (insights)
        left_content = slide.placeholders[1]
        
        # Generate insights based on column type
        col_type = column_data.get('type', 'unknown')
        insights_text = self._generate_column_insights(column_name, column_data, col_type)
        
        left_content.text = insights_text
        self._format_content_text(left_content.text_frame)
        
        # Right content (chart or statistics)
        right_content = slide.placeholders[2]
        
        if chart_path and Path(chart_path).exists():
            # Add chart image
            try:
                right_content.text = ""  # Clear placeholder text
                slide.shapes._spTree.remove(right_content._element)  # Remove placeholder
                
                # Add chart image
                left = Inches(6)
                top = Inches(2)
                width = Inches(5)
                height = Inches(4)
                
                slide.shapes.add_picture(chart_path, left, top, width, height)
            except Exception as e:
                print(f"Error adding chart: {e}")
                # Fallback to statistics
                self._add_statistics_content(right_content, column_data, col_type)
        else:
            # Add statistics table
            self._add_statistics_content(right_content, column_data, col_type)
    
    def _create_insights_slide(self, insights: List[str]) -> None:
        """Create insights summary slide"""
        
        slide = self.presentation.slides.add_slide(self.slide_layouts['title_content'])
        
        # Title
        title = slide.shapes.title
        title.text = "💡 Key Insights & Discoveries"
        self._format_slide_title(title.text_frame)
        
        # Content
        content_placeholder = slide.placeholders[1]
        
        insights_text = "Data Analysis Reveals:\n\n"
        
        for i, insight in enumerate(insights[:6], 1):  # Show top 6 insights
            insights_text += f"🔍 {insight}\n\n"
        
        insights_text += """
Strategic Implications:
• Data-driven decision making opportunities identified
• Performance optimization areas highlighted  
• Risk mitigation strategies can be developed
• Competitive advantages discovered through analysis
• ROI improvement potential quantified"""
        
        content_placeholder.text = insights_text
        self._format_content_text(content_placeholder.text_frame)
    
    def _create_correlation_slide(self, correlations: Dict[str, Any]) -> None:
        """Create correlation analysis slide"""
        
        slide = self.presentation.slides.add_slide(self.slide_layouts['title_content'])
        
        # Title
        title = slide.shapes.title
        title.text = "🔗 Variable Relationships"
        self._format_slide_title(title.text_frame)
        
        # Content
        content_placeholder = slide.placeholders[1]
        
        strong_correlations = correlations.get('strong_correlations', [])
        correlation_summary = correlations.get('correlation_summary', {})
        
        corr_text = f"""Correlation Analysis Results:

Strong Relationships Identified: {len(strong_correlations)}
Total Variable Pairs Analyzed: {correlation_summary.get('total_pairs', 0)}

Key Findings:"""
        
        for i, corr in enumerate(strong_correlations[:5], 1):  # Show top 5
            strength = "Strong" if abs(corr.get('pearson_correlation', 0)) > 0.7 else "Moderate"
            direction = "Positive" if corr.get('pearson_correlation', 0) > 0 else "Negative"
            
            corr_text += f"""
{i}. {corr.get('column1', '')} ↔ {corr.get('column2', '')}
   • Correlation: {corr.get('pearson_correlation', 0):.3f} ({strength} {direction})
   • Business Impact: Interdependent variables for optimization"""
        
        corr_text += f"""

Statistical Significance:
• Pearson correlation coefficients calculated
• Spearman rank correlations verified
• Relationship strength validated
• Business relevance assessed"""
        
        content_placeholder.text = corr_text
        self._format_content_text(content_placeholder.text_frame)
    
    def _create_conclusions_slide(self, analysis_data: Dict[str, Any], config: Dict[str, Any]) -> None:
        """Create conclusions and recommendations slide"""
        
        slide = self.presentation.slides.add_slide(self.slide_layouts['title_content'])
        
        # Title
        title = slide.shapes.title
        title.text = "📋 Conclusions & Recommendations"
        self._format_slide_title(title.text_frame)
        
        # Content
        content_placeholder = slide.placeholders[1]
        
        # Generate conclusions based on story mode
        story_mode = config.get('story_mode', 'executive')
        
        if story_mode == 'executive':
            conclusions_text = """Executive Summary:

Key Findings:
• Comprehensive analysis of business data completed
• Strategic opportunities identified for growth
• Performance optimization areas highlighted
• Risk factors assessed and mitigation strategies proposed

Strategic Recommendations:
1. Implement data-driven decision making processes
2. Focus resources on high-impact areas identified
3. Develop KPI monitoring based on analysis results
4. Create action plans for optimization opportunities
5. Establish regular data analysis cadence

Next Steps:
• Review findings with stakeholder teams
• Prioritize recommendations by business impact
• Develop implementation roadmap
• Establish success metrics and monitoring"""
        
        elif story_mode == 'analyst':
            conclusions_text = """Technical Analysis Summary:

Statistical Findings:
• Comprehensive data quality assessment completed
• Advanced statistical analysis performed
• Pattern recognition and anomaly detection executed
• Correlation analysis revealed key relationships

Analytical Insights:
1. Data completeness and quality metrics established
2. Distribution patterns and outliers identified
3. Variable relationships quantified and validated
4. Predictive indicators discovered
5. Methodological rigor maintained throughout

Recommendations:
• Continue monitoring identified patterns
• Expand analysis to additional variables
• Implement automated alerting for anomalies
• Develop predictive models based on findings"""
        
        else:  # Default/Manager/Investor
            conclusions_text = """Analysis Conclusions:

Primary Outcomes:
• Data analysis reveals significant business insights
• Key performance drivers identified and quantified
• Optimization opportunities discovered
• Strategic advantages highlighted through data

Actionable Recommendations:
1. Leverage identified patterns for competitive advantage
2. Monitor key metrics discovered in analysis
3. Implement data-driven optimization strategies
4. Establish regular review cycles for continuous improvement

Business Impact:
• Enhanced decision-making capabilities
• Improved operational efficiency potential
• Risk mitigation strategies identified
• Growth opportunities quantified"""
        
        content_placeholder.text = conclusions_text
        self._format_content_text(content_placeholder.text_frame)
    
    def _create_thank_you_slide(self, config: Dict[str, Any]) -> None:
        """Create thank you slide"""
        
        slide = self.presentation.slides.add_slide(self.slide_layouts['title'])
        
        # Title
        title = slide.shapes.title
        title.text = "Thank You"
        self._format_title_text(title.text_frame)
        
        # Subtitle
        subtitle = slide.placeholders[1]
        
        subtitle_text = """Questions & Discussion

Data Analysis powered by AI/ML
Enhanced with Privacy Protection
Generated with Advanced Analytics"""
        
        # Add company info if available
        brand_assets = config.get('brand_assets', {})
        if brand_assets.get('company_name'):
            subtitle_text += f"\n\nPrepared for: {brand_assets['company_name']['text']}"
        
        subtitle_text += f"\n\nGenerated: {pd.Timestamp.now().strftime('%B %d, %Y')}"
        
        subtitle.text = subtitle_text
        self._format_subtitle_text(subtitle.text_frame)
        
        # Add branding
        if brand_assets.get('company_name'):
            self._add_company_branding(slide, brand_assets)
        
        if brand_assets.get('logo'):
            self._add_logo(slide, brand_assets['logo'])
    
    def _generate_column_insights(self, column_name: str, column_data: Dict[str, Any], col_type: str) -> str:
        """Generate insights text for a column"""
        
        insights = f"Column Analysis: {column_name}\n\n"
        
        # Basic information
        insights += f"Data Type: {col_type.title()}\n"
        insights += f"Completeness: {100 - column_data.get('null_percentage', 0):.1f}%\n"
        insights += f"Unique Values: {column_data.get('unique_count', 0):,}\n\n"
        
        if col_type == 'numeric':
            insights += f"Statistical Summary:\n"
            insights += f"• Mean: {column_data.get('mean', 0):.2f}\n"
            insights += f"• Median: {column_data.get('median', 0):.2f}\n"
            insights += f"• Std Dev: {column_data.get('std', 0):.2f}\n"
            insights += f"• Range: {column_data.get('min', 0):.2f} to {column_data.get('max', 0):.2f}\n\n"
            
            # Distribution insights
            skewness = column_data.get('skewness', 0)
            if abs(skewness) < 0.5:
                insights += "• Distribution: Approximately symmetric\n"
            elif skewness > 0.5:
                insights += "• Distribution: Right-skewed (tail extends right)\n"
            else:
                insights += "• Distribution: Left-skewed (tail extends left)\n"
            
            outliers = column_data.get('outliers_count', 0)
            if outliers > 0:
                insights += f"• Outliers: {outliers} values detected\n"
            
        elif col_type in ['categorical', 'categorical_numeric']:
            insights += f"Category Analysis:\n"
            top_value = column_data.get('top_value', 'N/A')
            top_percentage = column_data.get('top_percentage', 0)
            insights += f"• Most Common: '{top_value}' ({top_percentage:.1f}%)\n"
            insights += f"• Total Categories: {column_data.get('categories', 0)}\n"
            
            entropy = column_data.get('entropy', 0)
            if entropy > 3:
                insights += "• Distribution: High diversity\n"
            elif entropy < 1:
                insights += "• Distribution: Low diversity (concentrated)\n"
            else:
                insights += "• Distribution: Moderate diversity\n"
        
        elif col_type == 'datetime':
            insights += f"Temporal Analysis:\n"
            insights += f"• Date Range: {column_data.get('date_range_days', 0)} days\n"
            insights += f"• From: {column_data.get('min_date', 'N/A')}\n"
            insights += f"• To: {column_data.get('max_date', 'N/A')}\n"
        
        insights += f"\nBusiness Relevance:\n"
        insights += f"• High-quality data suitable for analysis\n"
        insights += f"• Patterns identified for strategic insights\n"
        insights += f"• Suitable for predictive modeling\n"
        
        return insights
    
    def _add_statistics_content(self, content_placeholder, column_data: Dict[str, Any], col_type: str) -> None:
        """Add statistics content to placeholder"""
        
        if col_type == 'numeric':
            stats_text = f"""Statistical Measures:

Mean: {column_data.get('mean', 0):.3f}
Median: {column_data.get('median', 0):.3f}
Mode: {column_data.get('mode', 'N/A')}
Std Dev: {column_data.get('std', 0):.3f}
Variance: {column_data.get('variance', 0):.3f}

Range: {column_data.get('range', 0):.3f}
Min: {column_data.get('min', 0):.3f}
Max: {column_data.get('max', 0):.3f}

Quartiles:
Q1: {column_data.get('q1', 0):.3f}
Q3: {column_data.get('q3', 0):.3f}
IQR: {column_data.get('iqr', 0):.3f}

Distribution:
Skewness: {column_data.get('skewness', 0):.3f}
Kurtosis: {column_data.get('kurtosis', 0):.3f}
Outliers: {column_data.get('outliers_count', 0)}"""
        
        elif col_type in ['categorical', 'categorical_numeric']:
            value_dist = column_data.get('value_distribution', {})
            stats_text = f"""Category Statistics:

Total Categories: {column_data.get('categories', 0)}
Entropy: {column_data.get('entropy', 0):.3f}
Concentration: {column_data.get('concentration', 0):.3f}

Top Categories:"""
            
            for i, (category, count) in enumerate(list(value_dist.items())[:5], 1):
                percentage = (count / column_data.get('count', 1)) * 100
                stats_text += f"\n{i}. {category}: {count} ({percentage:.1f}%)"
        
        else:
            stats_text = f"""Data Summary:

Total Records: {column_data.get('count', 0):,}
Unique Values: {column_data.get('unique_count', 0):,}
Null Values: {column_data.get('null_count', 0):,}
Completeness: {100 - column_data.get('null_percentage', 0):.1f}%

Data Quality: Excellent
Analysis Ready: Yes
Insights Available: Yes"""
        
        content_placeholder.text = stats_text
        self._format_content_text(content_placeholder.text_frame)
    
    def _format_title_text(self, text_frame) -> None:
        """Format title text"""
        text_frame.clear()
        p = text_frame.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        
        run = p.runs[0] if p.runs else p.add_run()
        run.font.name = self.themes[self.current_theme]['font_name']
        run.font.size = Pt(44)
        run.font.color.rgb = self.themes[self.current_theme]['primary_color']
        run.font.bold = True
    
    def _format_slide_title(self, text_frame) -> None:
        """Format slide title"""
        p = text_frame.paragraphs[0]
        p.alignment = PP_ALIGN.LEFT
        
        run = p.runs[0] if p.runs else p.add_run()
        run.font.name = self.themes[self.current_theme]['font_name']
        run.font.size = Pt(32)
        run.font.color.rgb = self.themes[self.current_theme]['primary_color']
        run.font.bold = True
    
    def _format_subtitle_text(self, text_frame) -> None:
        """Format subtitle text"""
        p = text_frame.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        
        run = p.runs[0] if p.runs else p.add_run()
        run.font.name = self.themes[self.current_theme]['font_name']
        run.font.size = Pt(18)
        run.font.color.rgb = self.themes[self.current_theme]['text_color']
    
    def _format_content_text(self, text_frame) -> None:
        """Format content text"""
        for p in text_frame.paragraphs:
            p.alignment = PP_ALIGN.LEFT
            
            run = p.runs[0] if p.runs else p.add_run()
            run.font.name = self.themes[self.current_theme]['font_name']
            run.font.size = Pt(16)
            run.font.color.rgb = self.themes[self.current_theme]['text_color']
    
    def _add_company_branding(self, slide, brand_assets: Dict[str, Any]) -> None:
        """Add company branding to slide"""
        
        company_info = brand_assets.get('company_name', {})
        if not company_info:
            return
        
        try:
            # Add text box for company name
            left = Inches(0.5)
            top = Inches(7)
            width = Inches(9)
            height = Inches(0.5)
            
            text_box = slide.shapes.add_textbox(left, top, width, height)
            text_frame = text_box.text_frame
            text_frame.text = company_info.get('text', '')
            
            # Format text
            p = text_frame.paragraphs[0]
            p.alignment = PP_ALIGN.CENTER
            
            run = p.runs[0]
            run.font.name = self.themes[self.current_theme]['font_name']
            run.font.size = Pt(company_info.get('size', 12))
            run.font.color.rgb = RGBColor.from_string(company_info.get('color', '#000000').lstrip('#'))
            
        except Exception as e:
            print(f"Error adding company branding: {e}")
    
    def _add_logo(self, slide, logo_info: Dict[str, Any]) -> None:
        """Add logo to slide"""
        
        try:
            # Logo positioning
            position = logo_info.get('position', 'Top Right')
            size_pct = logo_info.get('size', 15)
            
            # Calculate position
            if position == 'Top Right':
                left = Inches(8.5)
                top = Inches(0.5)
            elif position == 'Top Left':
                left = Inches(0.5)
                top = Inches(0.5)
            elif position == 'Bottom Right':
                left = Inches(8.5)
                top = Inches(6.5)
            elif position == 'Bottom Left':
                left = Inches(0.5)
                top = Inches(6.5)
            else:  # Center
                left = Inches(4.5)
                top = Inches(3.5)
            
            # Calculate size
            width = Inches(10 * size_pct / 100)
            height = Inches(7.5 * size_pct / 100)
            
            # Add logo (placeholder - would need actual image file)
            # slide.shapes.add_picture(logo_path, left, top, width, height)
            
        except Exception as e:
            print(f"Error adding logo: {e}")
    
    def save_presentation(self, file_path: str) -> str:
        """Save presentation to file"""
        
        try:
            if self.presentation:
                self.presentation.save(file_path)
                return file_path
            else:
                raise ValueError("No presentation to save")
        
        except Exception as e:
            print(f"Error saving presentation: {e}")
            return None
    
    def get_slide_count(self) -> int:
        """Get number of slides in presentation"""
        return len(self.presentation.slides) if self.presentation else 0
    
    def add_custom_slide(self, title: str, content: str, layout: str = 'title_content') -> None:
        """Add custom slide with specified content"""
        
        try:
            slide_layout = self.slide_layouts.get(layout, self.slide_layouts['title_content'])
            slide = self.presentation.slides.add_slide(slide_layout)
            
            # Set title
            if slide.shapes.title:
                slide.shapes.title.text = title
                self._format_slide_title(slide.shapes.title.text_frame)
            
            # Set content
            if len(slide.placeholders) > 1:
                slide.placeholders[1].text = content
                self._format_content_text(slide.placeholders[1].text_frame)
                
        except Exception as e:
            print(f"Error adding custom slide: {e}")
