"""
PowerPoint Template Management
Handles different presentation themes and layouts
"""
from typing import Dict, List, Any
from pptx.dml.color import RGBColor
from pptx.util import Pt

class PPTTemplateManager:
    """Manages PowerPoint templates and themes"""
    
    def __init__(self):
        self.templates = {
            'corporate_blue': {
                'name': 'Corporate Blue',
                'description': 'Professional business template with blue accents',
                'colors': {
                    'primary': RGBColor(0, 122, 204),
                    'secondary': RGBColor(44, 62, 80),
                    'accent': RGBColor(236, 240, 241),
                    'text': RGBColor(44, 62, 80),
                    'background': RGBColor(255, 255, 255)
                },
                'fonts': {
                    'title': ('Calibri', 44, True),
                    'subtitle': ('Calibri', 18, False),
                    'heading': ('Calibri', 32, True),
                    'body': ('Calibri', 16, False)
                }
            },
            'modern_minimal': {
                'name': 'Modern Minimal',
                'description': 'Clean contemporary design with subtle colors',
                'colors': {
                    'primary': RGBColor(74, 74, 74),
                    'secondary': RGBColor(44, 62, 80),
                    'accent': RGBColor(248, 249, 250),
                    'text': RGBColor(44, 62, 80),
                    'background': RGBColor(255, 255, 255)
                },
                'fonts': {
                    'title': ('Segoe UI', 44, True),
                    'subtitle': ('Segoe UI', 18, False),
                    'heading': ('Segoe UI', 32, True),
                    'body': ('Segoe UI', 16, False)
                }
            },
            'executive_dashboard': {
                'name': 'Executive Dashboard',
                'description': 'High-level overview style for C-suite presentations',
                'colors': {
                    'primary': RGBColor(255, 102, 0),
                    'secondary': RGBColor(0, 0, 0),
                    'accent': RGBColor(245, 245, 245),
                    'text': RGBColor(26, 26, 26),
                    'background': RGBColor(255, 255, 255)
                },
                'fonts': {
                    'title': ('Arial', 44, True),
                    'subtitle': ('Arial', 18, False),
                    'heading': ('Arial', 32, True),
                    'body': ('Arial', 16, False)
                }
            },
            'data_analyst': {
                'name': 'Data Analyst',
                'description': 'Detailed technical presentation with emphasis on data',
                'colors': {
                    'primary': RGBColor(40, 167, 69),
                    'secondary': RGBColor(33, 37, 41),
                    'accent': RGBColor(248, 249, 250),
                    'text': RGBColor(33, 37, 41),
                    'background': RGBColor(255, 255, 255)
                },
                'fonts': {
                    'title': ('Consolas', 44, True),
                    'subtitle': ('Consolas', 18, False),
                    'heading': ('Consolas', 32, True),
                    'body': ('Consolas', 16, False)
                }
            },
            'consultant_pro': {
                'name': 'Consultant Pro',
                'description': 'Professional consulting presentation style',
                'colors': {
                    'primary': RGBColor(220, 53, 69),
                    'secondary': RGBColor(52, 58, 64),
                    'accent': RGBColor(248, 249, 250),
                    'text': RGBColor(52, 58, 64),
                    'background': RGBColor(255, 255, 255)
                },
                'fonts': {
                    'title': ('Times New Roman', 44, True),
                    'subtitle': ('Times New Roman', 18, False),
                    'heading': ('Times New Roman', 32, True),
                    'body': ('Times New Roman', 16, False)
                }
            },
            'academic_research': {
                'name': 'Academic Research',
                'description': 'Scholarly presentation template',
                'colors': {
                    'primary': RGBColor(23, 162, 184),
                    'secondary': RGBColor(73, 80, 87),
                    'accent': RGBColor(233, 236, 239),
                    'text': RGBColor(73, 80, 87),
                    'background': RGBColor(255, 255, 255)
                },
                'fonts': {
                    'title': ('Georgia', 44, True),
                    'subtitle': ('Georgia', 18, False),
                    'heading': ('Georgia', 32, True),
                    'body': ('Georgia', 16, False)
                }
            }
        }
        
        self.slide_structures = {
            'title_slide': {
                'layout': 'title',
                'elements': ['title', 'subtitle', 'logo', 'company_name']
            },
            'content_slide': {
                'layout': 'title_content',
                'elements': ['title', 'content', 'footer']
            },
            'two_column_slide': {
                'layout': 'two_content',
                'elements': ['title', 'left_content', 'right_content', 'footer']
            },
            'chart_slide': {
                'layout': 'title_content',
                'elements': ['title', 'chart', 'insights', 'footer']
            },
            'comparison_slide': {
                'layout': 'comparison',
                'elements': ['title', 'left_comparison', 'right_comparison', 'footer']
            }
        }
    
    def get_template(self, template_name: str) -> Dict[str, Any]:
        """Get template configuration"""
        return self.templates.get(template_name, self.templates['corporate_blue'])
    
    def get_available_templates(self) -> List[Dict[str, str]]:
        """Get list of available templates"""
        return [
            {
                'key': key,
                'name': template['name'],
                'description': template['description']
            }
            for key, template in self.templates.items()
        ]
    
    def get_template_colors(self, template_name: str) -> Dict[str, RGBColor]:
        """Get color scheme for template"""
        template = self.get_template(template_name)
        return template.get('colors', {})
    
    def get_template_fonts(self, template_name: str) -> Dict[str, tuple]:
        """Get font configuration for template"""
        template = self.get_template(template_name)
        return template.get('fonts', {})
    
    def create_custom_template(
        self, 
        name: str,
        colors: Dict[str, str],
        fonts: Dict[str, tuple] = None
    ) -> str:
        """Create custom template"""
        
        template_key = name.lower().replace(' ', '_')
        
        # Convert color strings to RGBColor objects
        rgb_colors = {}
        for color_name, color_value in colors.items():
            if isinstance(color_value, str):
                # Remove # and convert hex to RGB
                hex_color = color_value.lstrip('#')
                rgb = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
                rgb_colors[color_name] = RGBColor(*rgb)
            else:
                rgb_colors[color_name] = color_value
        
        # Default fonts if not provided
        if fonts is None:
            fonts = {
                'title': ('Calibri', 44, True),
                'subtitle': ('Calibri', 18, False),
                'heading': ('Calibri', 32, True),
                'body': ('Calibri', 16, False)
            }
        
        self.templates[template_key] = {
            'name': name,
            'description': f'Custom template: {name}',
            'colors': rgb_colors,
            'fonts': fonts
        }
        
        return template_key
    
    def validate_template(self, template_name: str) -> bool:
        """Validate template completeness"""
        
        template = self.templates.get(template_name)
        if not template:
            return False
        
        required_colors = ['primary', 'secondary', 'text', 'background']
        required_fonts = ['title', 'heading', 'body']
        
        colors = template.get('colors', {})
        fonts = template.get('fonts', {})
        
        # Check required colors
        for color in required_colors:
            if color not in colors:
                return False
        
        # Check required fonts
        for font in required_fonts:
            if font not in fonts:
                return False
        
        return True
    
    def export_template_config(self, template_name: str) -> Dict[str, Any]:
        """Export template configuration for external use"""
        
        template = self.get_template(template_name)
        
        # Convert RGBColor objects to hex strings for serialization
        colors_hex = {}
        for color_name, rgb_color in template.get('colors', {}).items():
            if hasattr(rgb_color, 'rgb'):
                r, g, b = rgb_color.rgb
                colors_hex[color_name] = f"#{r:02x}{g:02x}{b:02x}"
            else:
                colors_hex[color_name] = "#000000"  # Fallback
        
        return {
            'name': template.get('name'),
            'description': template.get('description'),
            'colors': colors_hex,
            'fonts': template.get('fonts', {}),
            'slide_structures': self.slide_structures
        }
    
    def import_template_config(self, config: Dict[str, Any]) -> str:
        """Import template configuration from external source"""
        
        name = config.get('name', 'Imported Template')
        template_key = name.lower().replace(' ', '_')
        
        # Convert hex colors to RGBColor objects
        colors = {}
        for color_name, hex_color in config.get('colors', {}).items():
            hex_color = hex_color.lstrip('#')
            if len(hex_color) == 6:
                rgb = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
                colors[color_name] = RGBColor(*rgb)
        
        self.templates[template_key] = {
            'name': name,
            'description': config.get('description', 'Imported template'),
            'colors': colors,
            'fonts': config.get('fonts', {})
        }
        
        return template_key
    
    def get_color_palette_preview(self, template_name: str) -> List[str]:
        """Get color palette as hex strings for preview"""
        
        template = self.get_template(template_name)
        colors = template.get('colors', {})
        
        palette = []
        for color_name, rgb_color in colors.items():
            if hasattr(rgb_color, 'rgb'):
                r, g, b = rgb_color.rgb
                palette.append(f"#{r:02x}{g:02x}{b:02x}")
        
        return palette
    
    def suggest_template_for_audience(self, audience: str) -> str:
        """Suggest appropriate template based on audience"""
        
        audience_templates = {
            'executive': 'executive_dashboard',
            'analyst': 'data_analyst',
            'investor': 'consultant_pro',
            'manager': 'corporate_blue',
            'consultant': 'consultant_pro',
            'academic': 'academic_research',
            'technical': 'data_analyst'
        }
        
        return audience_templates.get(audience.lower(), 'corporate_blue')
    
    def get_chart_colors(self, template_name: str) -> List[str]:
        """Get recommended colors for charts based on template"""
        
        template = self.get_template(template_name)
        colors = template.get('colors', {})
        
        # Create color palette for charts
        chart_colors = []
        
        # Primary color
        primary = colors.get('primary')
        if primary and hasattr(primary, 'rgb'):
            r, g, b = primary.rgb
            chart_colors.append(f"#{r:02x}{g:02x}{b:02x}")
        
        # Secondary color
        secondary = colors.get('secondary')
        if secondary and hasattr(secondary, 'rgb'):
            r, g, b = secondary.rgb
            chart_colors.append(f"#{r:02x}{g:02x}{b:02x}")
        
        # Generate complementary colors
        if len(chart_colors) >= 1:
            base_color = chart_colors[0]
            chart_colors.extend(self._generate_color_variations(base_color, 4))
        
        return chart_colors[:6]  # Return max 6 colors
    
    def _generate_color_variations(self, hex_color: str, count: int) -> List[str]:
        """Generate color variations from base color"""
        
        # Convert hex to RGB
        hex_color = hex_color.lstrip('#')
        r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        variations = []
        
        for i in range(count):
            # Create variations by adjusting brightness and saturation
            factor = 0.7 + (i * 0.1)  # Vary from 70% to 100%+ brightness
            
            new_r = min(255, int(r * factor))
            new_g = min(255, int(g * factor))
            new_b = min(255, int(b * factor))
            
            variations.append(f"#{new_r:02x}{new_g:02x}{new_b:02x}")
        
        return variations
