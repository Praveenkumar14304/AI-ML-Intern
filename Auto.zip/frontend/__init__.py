"""
AI/ML Data to PowerPoint Generator - Frontend Package
Enhanced Streamlit application with PII override and dynamic preview
"""

__version__ = "2.0.0"
__author__ = "AI/ML Team"
__description__ = "Enhanced frontend with PII protection and dynamic preview"

# Import main components
from .app import main as run_app

__all__ = ["run_app"]
