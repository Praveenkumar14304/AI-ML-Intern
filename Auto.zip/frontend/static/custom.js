// AI/ML Data to PowerPoint Generator - Interactive Features
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initializeTabs();
    initializeCodeSections();
    initializeCopyButtons();
    initializeFileTree();
    initializePlatformTabs();
    initializeProjectGenerator();
    
    console.log('🎯 AI/ML Data to PowerPoint Generator - Interactive Features Loaded');
});

// Tab Navigation
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tab');
            
            // Remove active class from all tabs
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to current tab
            button.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
            
            // Trigger specific tab initialization if needed
            if (targetTab === 'structure') {
                initializeFileTreeInteractions();
            } else if (targetTab === 'download') {
                updateGenerateSection();
            }
        });
    });
}

// Enhanced File Upload Handler
function initializeFileUpload() {
    const uploadArea = document.querySelector('.file-upload-area');
    
    if (uploadArea) {
        // Drag and drop functionality
        uploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            uploadArea.classList.add('drag-over');
        });
        
        uploadArea.addEventListener('dragleave', function(e) {
            e.preventDefault();
            uploadArea.classList.remove('drag-over');
        });
        
        uploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            uploadArea.classList.remove('drag-over');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                handleFileUpload(files[0]);
            }
        });
    }
}

// File Upload Handler
function handleFileUpload(file) {
    // Validate file type
    const allowedTypes = ['text/csv', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
    
    if (!allowedTypes.includes(file.type)) {
        showNotification('Please upload a CSV or Excel file', 'error');
        return;
    }
    
    // Validate file size (50MB limit)
    const maxSize = 50 * 1024 * 1024;
    if (file.size > maxSize) {
        showNotification('File too large. Maximum size is 50MB', 'error');
        return;
    }
    
    // Show upload progress
    showUploadProgress(file);
    
    // Simulate file processing
    setTimeout(() => {
        hideUploadProgress();
        showNotification(`File "${file.name}" uploaded successfully`, 'success');
        triggerDataAnalysis(file);
    }, 2000);
}

// Show Upload Progress
function showUploadProgress(file) {
    const progressContainer = document.createElement('div');
    progressContainer.className = 'upload-progress';
    progressContainer.innerHTML = `
        <div class="progress-header">
            <span>Uploading ${file.name}</span>
            <span class="file-size">${formatFileSize(file.size)}</span>
        </div>
        <div class="progress-bar">
            <div class="progress-fill"></div>
        </div>
        <div class="progress-text">0%</div>
    `;
    
    document.body.appendChild(progressContainer);
    
    // Animate progress
    const progressFill = progressContainer.querySelector('.progress-fill');
    const progressText = progressContainer.querySelector('.progress-text');
    
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 100) progress = 100;
        
        progressFill.style.width = progress + '%';
        progressText.textContent = Math.round(progress) + '%';
        
        if (progress >= 100) {
            clearInterval(interval);
        }
    }, 100);
}

// Hide Upload Progress
function hideUploadProgress() {
    const progressContainer = document.querySelector('.upload-progress');
    if (progressContainer) {
        progressContainer.remove();
    }
}

// Format File Size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Trigger Data Analysis
function triggerDataAnalysis(file) {
    // Show analysis progress
    const analysisSteps = [
        'Loading dataset...',
        'Detecting column types...',
        'Scanning for PII...',
        'Calculating statistics...',
        'Generating preview...',
        'Analysis complete!'
    ];
    
    showAnalysisProgress(analysisSteps);
}

// Show Analysis Progress
function showAnalysisProgress(steps) {
    const modal = document.createElement('div');
    modal.className = 'analysis-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>🤖 Analyzing Dataset</h3>
                <div class="spinner"></div>
            </div>
            <div class="analysis-steps">
                ${steps.map((step, index) => `
                    <div class="step" id="step-${index}">
                        <span class="step-icon">⏳</span>
                        <span class="step-text">${step}</span>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Animate steps
    steps.forEach((step, index) => {
        setTimeout(() => {
            const stepElement = document.getElementById(`step-${index}`);
            const icon = stepElement.querySelector('.step-icon');
            
            icon.textContent = '✅';
            stepElement.classList.add('completed');
            
            if (index === steps.length - 1) {
                setTimeout(() => {
                    modal.remove();
                    showDataPreview();
                }, 1000);
            }
        }, (index + 1) * 800);
    });
}

// Show Data Preview
function showDataPreview() {
    // Simulate showing data preview with PII detection results
    const previewData = {
        rows: 15420,
        columns: 12,
        piiDetected: ['email', 'customer_id', 'phone_number'],
        selectedColumns: ['revenue', 'region', 'product_category', 'date']
    };
    
    updateDataOverview(previewData);
    showNotification('Dataset analysis complete. Review PII detection results.', 'info');
}

// Update Data Overview
function updateDataOverview(data) {
    // Update metrics cards
    updateMetric('total-rows', data.rows.toLocaleString());
    updateMetric('total-columns', data.columns);
    
    // Update PII detection results
    if (data.piiDetected.length > 0) {
        showPIIAlert(data.piiDetected);
    } else {
        showPIISuccess();
    }
    
    // Update column selection
    updateColumnSelection(data.selectedColumns);
}

// Update Metric Display
function updateMetric(metricId, value) {
    const element = document.getElementById(metricId);
    if (element) {
        element.textContent = value;
    }
}

// Show PII Alert
function showPIIAlert(piiColumns) {
    const alert = document.createElement('div');
    alert.className = 'pii-alert';
    alert.innerHTML = `
        <div class="alert-header">
            <span class="alert-icon">🛡️</span>
            <span class="alert-title">PII Detected</span>
        </div>
        <div class="alert-content">
            <p>${piiColumns.length} columns contain potentially sensitive information:</p>
            <ul>
                ${piiColumns.map(col => `<li>${col}</li>`).join('')}
            </ul>
            <p>These columns have been automatically excluded from analysis.</p>
        </div>
        <div class="alert-actions">
            <button class="btn-primary" onclick="reviewPIISettings()">Review Settings</button>
            <button class="btn-secondary" onclick="dismissAlert(this)">Dismiss</button>
        </div>
    `;
    
    const container = document.querySelector('.pii-container');
    if (container) {
        container.appendChild(alert);
    }
}

// Show PII Success
function showPIISuccess() {
    const success = document.createElement('div');
    success.className = 'pii-success';
    success.innerHTML = `
        <span class="success-icon">✅</span>
        <span class="success-text">No PII detected - dataset is privacy-safe</span>
    `;
    
    const container = document.querySelector('.pii-container');
    if (container) {
        container.appendChild(success);
    }
}

// Review PII Settings
function reviewPIISettings() {
    // Show PII override modal
    const modal = document.createElement('div');
    modal.className = 'pii-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>🛡️ PII Detection Review</h3>
                <button class="close-btn" onclick="closeModal(this)">&times;</button>
            </div>
            <div class="modal-body">
                <p>Review and override PII detection results:</p>
                <div class="pii-columns">
                    <div class="pii-column">
                        <div class="column-info">
                            <strong>email</strong>
                            <span class="detection-method">Email pattern detected</span>
                            <span class="confidence">95% confidence</span>
                        </div>
                        <button class="restore-btn" onclick="restoreColumn('email')">🔓 Restore</button>
                    </div>
                    <div class="pii-column">
                        <div class="column-info">
                            <strong>customer_id</strong>
                            <span class="detection-method">ID keyword detected</span>
                            <span class="confidence">90% confidence</span>
                        </div>
                        <button class="restore-btn" onclick="restoreColumn('customer_id')">🔓 Restore</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Restore Column
function restoreColumn(columnName) {
    showNotification(`Column "${columnName}" restored for analysis`, 'success');
    // Update column selection UI
    updateColumnSelection([columnName]);
}

// Close Modal
function closeModal(button) {
    const modal = button.closest('.pii-modal, .analysis-modal');
    if (modal) {
        modal.remove();
    }
}

// Dismiss Alert
function dismissAlert(button) {
    const alert = button.closest('.pii-alert');
    if (alert) {
        alert.remove();
    }
}

// Update Column Selection
function updateColumnSelection(columns) {
    const container = document.querySelector('.column-selection');
    if (container) {
        container.innerHTML = `
            <div class="selection-header">
                <h4>Selected Columns (${columns.length})</h4>
                <div class="selection-actions">
                    <button onclick="selectAllColumns()">Select All</button>
                    <button onclick="clearAllColumns()">Clear All</button>
                </div>
            </div>
            <div class="column-list">
                ${columns.map(col => `
                    <div class="column-item">
                        <input type="checkbox" id="col-${col}" checked>
                        <label for="col-${col}">${col}</label>
                        <span class="column-type">numeric</span>
                    </div>
                `).join('')}
            </div>
        `;
    }
}

// Show Notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">${getNotificationIcon(type)}</span>
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="closeNotification(this)">&times;</button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Get Notification Icon
function getNotificationIcon(type) {
    const icons = {
        'success': '✅',
        'error': '❌',
        'warning': '⚠️',
        'info': 'ℹ️'
    };
    return icons[type] || 'ℹ️';
}

// Close Notification
function closeNotification(button) {
    const notification = button.closest('.notification');
    if (notification) {
        notification.remove();
    }
}

// Initialize Dynamic Preview Toggle
function initializeDynamicPreview() {
    const toggleButton = document.querySelector('.preview-toggle');
    const dataTable = document.querySelector('.data-preview-table');
    
    if (toggleButton && dataTable) {
        toggleButton.addEventListener('click', function() {
            const isShowingSelected = toggleButton.classList.contains('show-selected');
            
            if (isShowingSelected) {
                // Show all columns
                toggleButton.textContent = '📊 Show Selected Only';
                toggleButton.classList.remove('show-selected');
                showAllColumns(dataTable);
            } else {
                // Show selected columns only
                toggleButton.textContent = '📋 Show All Columns';
                toggleButton.classList.add('show-selected');
                showSelectedColumns(dataTable);
            }
        });
    }
}

// Show All Columns
function showAllColumns(table) {
    const hiddenColumns = table.querySelectorAll('.column-hidden');
    hiddenColumns.forEach(col => {
        col.classList.remove('column-hidden');
    });
    
    updatePreviewInfo('Showing all columns');
}

// Show Selected Columns
function showSelectedColumns(table) {
    const selectedColumns = getSelectedColumns();
    const allColumns = table.querySelectorAll('th, td');
    
    allColumns.forEach((col, index) => {
        const columnName = col.textContent || col.getAttribute('data-column');
        if (!selectedColumns.includes(columnName)) {
            col.classList.add('column-hidden');
        }
    });
    
    updatePreviewInfo(`Showing ${selectedColumns.length} selected columns`);
}

// Get Selected Columns
function getSelectedColumns() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    return Array.from(checkboxes).map(cb => cb.value || cb.getAttribute('data-column'));
}

// Update Preview Info
function updatePreviewInfo(message) {
    const infoElement = document.querySelector('.preview-info');
    if (infoElement) {
        infoElement.textContent = message;
    }
}

// Initialize Theme Switcher
function initializeThemeSwitcher() {
    const themeButtons = document.querySelectorAll('.theme-btn');
    
    themeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const theme = this.getAttribute('data-theme');
            switchTheme(theme);
            
            // Update active theme button
            themeButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// Switch Theme
function switchTheme(theme) {
    const root = document.documentElement;
    
    const themes = {
        'corporate': {
            '--primary-color': '#FF6600',
            '--secondary-color': '#000000',
            '--background-color': '#FFFFFF'
        },
        'modern': {
            '--primary-color': '#007ACC',
            '--secondary-color': '#2C3E50',
            '--background-color': '#FFFFFF'
        },
        'minimal': {
            '--primary-color': '#4A4A4A',
            '--secondary-color': '#2C3E50',
            '--background-color': '#FFFFFF'
        }
    };
    
    const selectedTheme = themes[theme] || themes['corporate'];
    
    Object.entries(selectedTheme).forEach(([property, value]) => {
        root.style.setProperty(property, value);
    });
    
    showNotification(`Theme switched to ${theme}`, 'success');
}

// Initialize Copy Buttons
function initializeCopyButtons() {
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('copy-btn')) {
            const targetId = e.target.getAttribute('data-target');
            const content = document.getElementById(targetId);
            
            if (content) {
                copyToClipboard(content.textContent || content.innerText);
                showNotification('Code copied to clipboard!', 'success');
            }
        }
    });
}

// Copy to Clipboard
function copyToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
        return navigator.clipboard.writeText(text);
    } else {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        return new Promise((resolve, reject) => {
            try {
                document.execCommand('copy');
                textArea.remove();
                resolve();
            } catch (err) {
                textArea.remove();
                reject(err);
            }
        });
    }
}

// Initialize Smooth Scrolling
function initializeSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Add CSS for animations and interactions
const style = document.createElement('style');
style.textContent = `
    /* Upload Progress Styles */
    .upload-progress {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        border-radius: 12px;
        padding: 2rem;
        box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        z-index: 1000;
        min-width: 300px;
    }
    
    .progress-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 1rem;
        font-weight: bold;
    }
    
    .progress-bar {
        height: 8px;
        background: #f0f0f0;
        border-radius: 4px;
        overflow: hidden;
        margin-bottom: 0.5rem;
    }
    
    .progress-fill {
        height: 100%;
        background: var(--primary-orange, #FF6600);
        transition: width 0.3s ease;
    }
    
    .progress-text {
        text-align: center;
        font-size: 0.9rem;
        color: #666;
    }
    
    /* Analysis Modal Styles */
    .analysis-modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }
    
    .modal-content {
        background: white;
        border-radius: 12px;
        padding: 2rem;
        max-width: 400px;
        width: 90%;
        box-shadow: 0 8px 25px rgba(0,0,0,0.3);
    }
    
    .modal-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 1.5rem;
    }
    
    .spinner {
        width: 20px;
        height: 20px;
        border: 2px solid #f3f3f3;
        border-top: 2px solid var(--primary-orange, #FF6600);
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .analysis-steps {
        space-y: 1rem;
    }
    
    .step {
        display: flex;
        align-items: center;
        padding: 0.5rem;
        transition: all 0.3s ease;
    }
    
    .step.completed {
        background: #f0fff0;
        border-radius: 6px;
    }
    
    .step-icon {
        margin-right: 0.75rem;
        font-size: 1.1rem;
    }
    
    .step-text {
        font-weight: 500;
    }
    
    /* Notification Styles */
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1001;
        min-width: 300px;
        border-left: 4px solid var(--primary-orange, #FF6600);
    }
    
    .notification.success {
        border-left-color: #28a745;
    }
    
    .notification.error {
        border-left-color: #dc3545;
    }
    
    .notification.warning {
        border-left-color: #ffc107;
    }
    
    .notification-content {
        display: flex;
        align-items: center;
        padding: 1rem;
    }
    
    .notification-icon {
        margin-right: 0.75rem;
        font-size: 1.2rem;
    }
    
    .notification-message {
        flex: 1;
        font-weight: 500;
    }
    
    .notification-close {
        background: none;
        border: none;
        font-size: 1.2rem;
        cursor: pointer;
        color: #999;
        margin-left: 0.5rem;
    }
    
    .notification-close:hover {
        color: #666;
    }
    
    /* PII Alert Styles */
    .pii-alert {
        background: linear-gradient(90deg, #ffe6e6, #fff0f0);
        border: 1px solid var(--primary-orange, #FF6600);
        border-radius: 8px;
        padding: 1.5rem;
        margin: 1rem 0;
    }
    
    .alert-header {
        display: flex;
        align-items: center;
        margin-bottom: 1rem;
    }
    
    .alert-icon {
        font-size: 1.3rem;
        margin-right: 0.5rem;
    }
    
    .alert-title {
        font-weight: bold;
        font-size: 1.1rem;
        color: var(--primary-orange, #FF6600);
    }
    
    .alert-actions {
        display: flex;
        gap: 0.5rem;
        margin-top: 1rem;
    }
    
    .btn-primary, .btn-secondary {
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .btn-primary {
        background: var(--primary-orange, #FF6600);
        color: white;
    }
    
    .btn-primary:hover {
        background: #e55a00;
    }
    
    .btn-secondary {
        background: #f8f9fa;
        color: #495057;
        border: 1px solid #dee2e6;
    }
    
    .btn-secondary:hover {
        background: #e9ecef;
    }
    
    /* Column Hidden State */
    .column-hidden {
        display: none !important;
    }
    
    /* Theme Button Styles */
    .theme-btn {
        padding: 0.5rem 1rem;
        border: 2px solid transparent;
        border-radius: 6px;
        background: #f8f9fa;
        cursor: pointer;
        transition: all 0.3s ease;
        margin: 0.25rem;
    }
    
    .theme-btn:hover {
        border-color: var(--primary-orange, #FF6600);
    }
    
    .theme-btn.active {
        background: var(--primary-orange, #FF6600);
        color: white;
        border-color: var(--primary-orange, #FF6600);
    }
`;

document.head.appendChild(style);

// Initialize all features when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        initializeFileUpload();
        initializeDynamicPreview();
        initializeThemeSwitcher();
        initializeCopyButtons();
        initializeSmoothScrolling();
    });
} else {
    initializeFileUpload();
    initializeDynamicPreview();
    initializeThemeSwitcher();
    initializeCopyButtons();
    initializeSmoothScrolling();
}
