"""
AI/ML Data to PowerPoint Generator - Enhanced Streamlit Frontend
Features: PII Override, Dynamic Preview Toggle, Professional Theme
"""
import streamlit as st
import pandas as pd
import numpy as np
import requests
import time
from datetime import datetime
from typing import List, Dict, Any

# Set page configuration
st.set_page_config(
    page_title="AI/ML Data to PowerPoint Generator",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

def load_custom_css():
    """Load enhanced CSS with black/orange/white theme"""
    st.markdown("""
    <style>
    :root {
        --primary-orange: #FF6600;
        --secondary-black: #000000;
        --background-white: #FFFFFF;
        --text-dark: #1A1A1A;
        --accent-gray: #F5F5F5;
        --success-green: #28A745;
        --warning-yellow: #FFC107;
        --error-red: #DC3545;
        --info-blue: #17A2B8;
    }
    
    /* Main Header */
    .main-header {
        background: linear-gradient(135deg, var(--secondary-black) 0%, var(--primary-orange) 100%);
        padding: 2rem;
        border-radius: 15px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: 0 8px 25px rgba(255,102,0,0.3);
    }
    
    .main-header h1 {
        font-size: 2.5rem;
        font-weight: bold;
        margin-bottom: 0.5rem;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    .main-header p {
        font-size: 1.1rem;
        opacity: 0.9;
        margin: 0;
    }
    
    /* Enhanced Buttons */
    .stButton > button {
        background: linear-gradient(135deg, var(--primary-orange), #FF8533) !important;
        color: white !important;
        border: none !important;
        border-radius: 8px !important;
        font-weight: bold !important;
        padding: 0.6rem 1.2rem !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 4px 12px rgba(255,102,0,0.3) !important;
    }
    
    .stButton > button:hover {
        background: linear-gradient(135deg, #E55A00, #FF6600) !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 6px 20px rgba(255,102,0,0.4) !important;
    }
    
    /* Metric Cards */
    .metric-card {
        background: linear-gradient(135deg, var(--primary-orange), #FF8533);
        color: white;
        padding: 1.5rem;
        border-radius: 12px;
        text-align: center;
        margin: 0.5rem 0;
        box-shadow: 0 4px 12px rgba(255,102,0,0.3);
    }
    
    .metric-card h3 {
        margin: 0;
        font-size: 2rem;
        font-weight: bold;
    }
    
    .metric-card p {
        margin: 0;
        opacity: 0.9;
        font-size: 0.9rem;
    }
    
    /* PII Warning */
    .pii-warning {
        background: linear-gradient(90deg, #FFE6E6, #FFF0F0);
        border-left: 5px solid var(--primary-orange);
        padding: 1.5rem;
        border-radius: 8px;
        margin: 1rem 0;
        box-shadow: 0 2px 8px rgba(255,102,0,0.2);
    }
    
    .pii-warning h4 {
        color: var(--primary-orange);
        margin-bottom: 0.5rem;
        font-weight: bold;
    }
    
    /* Success Messages */
    .success-message {
        background: linear-gradient(90deg, #E6FFE6, #F0FFF0);
        border-left: 5px solid var(--success-green);
        padding: 1.5rem;
        border-radius: 8px;
        margin: 1rem 0;
        box-shadow: 0 2px 8px rgba(40,167,69,0.2);
    }
    
    .success-message h4 {
        color: var(--success-green);
        margin-bottom: 0.5rem;
        font-weight: bold;
    }
    
    /* Column Info Cards */
    .column-info {
        background: var(--accent-gray);
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
        border-left: 4px solid var(--primary-orange);
        transition: all 0.3s ease;
    }
    
    .column-info:hover {
        box-shadow: 0 4px 12px rgba(255,102,0,0.2);
        transform: translateX(5px);
    }
    
    .column-info h5 {
        color: var(--primary-orange);
        margin-bottom: 0.5rem;
        font-weight: bold;
    }
    
    /* Toggle Styling */
    .stCheckbox > label > div[data-testid="stCheckbox"] > div {
        background-color: var(--primary-orange) !important;
    }
    
    /* File Uploader */
    .stFileUploader > div > div {
        border: 2px dashed var(--primary-orange) !important;
        border-radius: 12px !important;
        background-color: #FFF8F0 !important;
        padding: 2rem !important;
    }
    
    /* Progress Bars */
    .stProgress > div > div > div {
        background-color: var(--primary-orange) !important;
    }
    
    /* Dataframe Styling */
    .stDataFrame {
        border: 2px solid var(--accent-gray);
        border-radius: 8px;
        overflow: hidden;
    }
    
    /* Expander Styling */
    .streamlit-expanderHeader {
        background-color: var(--accent-gray) !important;
        border-left: 4px solid var(--primary-orange) !important;
    }
    
    /* Tab Styling */
    .stTabs > div > div > div > div {
        background-color: var(--primary-orange) !important;
        color: white !important;
        font-weight: bold !important;
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
        .main-header h1 {
            font-size: 2rem;
        }
        
        .metric-card {
            padding: 1rem;
        }
        
        .column-info {
            padding: 0.8rem;
        }
    }
    </style>
    """, unsafe_allow_html=True)

# Initialize session state
def init_session_state():
    """Initialize all session state variables"""
    defaults = {
        'uploaded_file': None,
        'dataset_id': None,
        'all_columns': [],
        'selected_columns': [],
        'removed_columns': [],
        'show_selected_only': False,
        'auto_remove_pii': True,
        'presentation_ready': False,
        'current_slide': 0,
        'processing': False,
        'template_source': 'builtin',
        'selected_theme': 'corporate',
        'story_mode': 'executive',
        'content_style': 'insights_charts',
        'custom_filename': '',
        'brand_assets': {},
        'export_format': 'pptx'
    }
    
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value

# API configuration
API_BASE = "http://127.0.0.1:8000/api"

def main():
    """Main application entry point"""
    
    # Load custom CSS
    load_custom_css()
    
    # Initialize session state
    init_session_state()
    
    # Application header
    st.markdown("""
    <div class="main-header">
        <h1>🤖 AI/ML Data to PowerPoint Generator</h1>
        <p>Transform your data into professional presentations with advanced AI/ML analysis</p>
        <p><strong>✨ Enhanced with PII Override & Dynamic Preview Toggle</strong></p>
    </div>
    """, unsafe_allow_html=True)
    
    # Main navigation tabs
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📁 Upload & Select", 
        "🎨 Template & Story", 
        "👁️ Preview & Edit", 
        "📤 Export & Download", 
        "📚 History"
    ])
    
    with tab1:
        render_upload_tab()
    with tab2:
        render_template_tab()
    with tab3:
        render_preview_tab()
    with tab4:
        render_export_tab()
    with tab5:
        render_history_tab()

def render_upload_tab():
    """Enhanced upload tab with PII override and dynamic preview"""
    st.markdown("### 📁 Upload Dataset & Column Selection")
    st.markdown("Upload your data file and configure analysis settings with enhanced privacy protection")
    
    # File upload section
    col1, col2 = st.columns([2, 1])
    
    with col1:
        uploaded_file = st.file_uploader(
            "Choose CSV or Excel file",
            type=['csv', 'xlsx', 'xls'],
            help="Upload your dataset for AI/ML analysis (maximum 50MB)",
            key="file_uploader"
        )
    
    with col2:
        if uploaded_file:
            st.success(f"✅ File: {uploaded_file.name}")
            st.info(f"📊 Size: {uploaded_file.size/1024/1024:.1f} MB")
    
    if uploaded_file is not None:
        st.session_state.uploaded_file = uploaded_file
        
        try:
            # Load and process dataset
            with st.spinner("🔍 Analyzing dataset and detecting PII..."):
                if uploaded_file.name.endswith('.csv'):
                    df = pd.read_csv(uploaded_file)
                else:
                    df = pd.read_excel(uploaded_file)
                
                # Dataset overview metrics
                render_dataset_overview(df, uploaded_file)
                
                # Enhanced PII detection and management
                pii_results = detect_pii_advanced(df)
                render_pii_management(pii_results)
                
                # Column selection interface
                render_column_selection(df, pii_results)
                
                # Enhanced dataset preview with toggle
                render_dataset_preview_with_toggle(df)
                
        except Exception as e:
            st.error(f"❌ Error processing file: {str(e)}")
            st.info("💡 Please ensure your file is a valid CSV or Excel format")
    
    else:
        render_upload_help()

def render_dataset_overview(df: pd.DataFrame, uploaded_file) -> None:
    """Display comprehensive dataset overview"""
    st.markdown("### 📊 Dataset Overview")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <h3>{len(df):,}</h3>
            <p>Total Rows</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-card">
            <h3>{len(df.columns)}</h3>
            <p>Total Columns</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <h3>{uploaded_file.size/1024/1024:.1f}</h3>
            <p>Size (MB)</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        memory_usage = df.memory_usage(deep=True).sum() / 1024 / 1024
        st.markdown(f"""
        <div class="metric-card">
            <h3>{memory_usage:.1f}</h3>
            <p>Memory (MB)</p>
        </div>
        """, unsafe_allow_html=True)

def detect_pii_advanced(df: pd.DataFrame) -> Dict[str, Any]:
    """Advanced PII detection with multiple methods"""
    pii_columns = []
    
    # Enhanced PII detection patterns
    pii_patterns = {
        'email': ['email', 'e_mail', 'mail', 'contact'],
        'phone': ['phone', 'telephone', 'mobile', 'cell', 'contact'],
        'name': ['name', 'first_name', 'last_name', 'full_name', 'customer_name'],
        'id': ['id', 'customer_id', 'user_id', 'account', 'ssn', 'social'],
        'address': ['address', 'street', 'location', 'city', 'zip'],
        'financial': ['salary', 'income', 'credit', 'bank', 'account_number']
    }
    
    for col in df.columns:
        col_lower = col.lower()
        pii_info = None
        
        # Method 1: Column name pattern matching
        for pii_type, patterns in pii_patterns.items():
            for pattern in patterns:
                if pattern in col_lower:
                    pii_info = {
                        'name': col,
                        'reason': f'Column name contains {pii_type} keyword: "{pattern}"',
                        'method': 'name_pattern_detection',
                        'confidence': 0.9,
                        'can_override': True,
                        'pii_type': pii_type
                    }
                    break
            if pii_info:
                break
        
        # Method 2: Content pattern analysis
        if not pii_info:
            sample_values = df[col].dropna().head(20).astype(str)
            
            # Email pattern detection
            email_count = sum(1 for val in sample_values if '@' in str(val) and '.' in str(val))
            if email_count > len(sample_values) * 0.6:
                pii_info = {
                    'name': col,
                    'reason': f'Email pattern detected in {email_count}/{len(sample_values)} values',
                    'method': 'content_pattern_detection',
                    'confidence': 0.95,
                    'can_override': True,
                    'pii_type': 'email'
                }
            
            # Phone pattern detection
            elif any(len(str(val).replace('-', '').replace(' ', '').replace('(', '').replace(')', '')) >= 10 
                    and any(c.isdigit() for c in str(val)) for val in sample_values):
                phone_count = sum(1 for val in sample_values 
                                if len(str(val).replace('-', '').replace(' ', '')) >= 10)
                if phone_count > len(sample_values) * 0.5:
                    pii_info = {
                        'name': col,
                        'reason': f'Phone pattern detected in {phone_count}/{len(sample_values)} values',
                        'method': 'content_pattern_detection',
                        'confidence': 0.85,
                        'can_override': True,
                        'pii_type': 'phone'
                    }
        
        # Method 3: Statistical uniqueness (potential ID fields)
        if not pii_info:
            uniqueness = df[col].nunique() / len(df)
            if uniqueness > 0.95 and len(df) > 100:
                pii_info = {
                    'name': col,
                    'reason': f'High uniqueness ratio ({uniqueness:.1%}) suggests ID field',
                    'method': 'statistical_analysis',
                    'confidence': 0.7,
                    'can_override': True,
                    'pii_type': 'identifier'
                }
        
        if pii_info:
            pii_columns.append(pii_info)
    
    return {
        'removed_columns': pii_columns,
        'removed_count': len(pii_columns),
        'total_columns': len(df.columns),
        'detection_methods': list(set([col['method'] for col in pii_columns]))
    }

def render_pii_management(pii_results: Dict[str, Any]) -> None:
    """Enhanced PII management with override capabilities"""
    st.markdown("### 🛡️ PII Protection & Management")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        auto_remove_pii = st.toggle(
            "🛡️ Auto-remove PII columns",
            value=st.session_state.auto_remove_pii,
            help="Automatically detect and remove personally identifiable information",
            key="auto_remove_toggle"
        )
        st.session_state.auto_remove_pii = auto_remove_pii
    
    with col2:
        if pii_results['removed_columns']:
            st.markdown(f"""
            <div class="pii-warning">
                <h4>⚠️ {pii_results['removed_count']} PII columns detected</h4>
                <p>Methods used: {', '.join(pii_results['detection_methods'])}</p>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div class="success-message">
                <h4>✅ No PII detected</h4>
                <p>Your dataset appears to be privacy-safe</p>
            </div>
            """, unsafe_allow_html=True)
    
    # Detailed PII management with override options
    if pii_results['removed_columns'] and auto_remove_pii:
        st.markdown("#### 🚨 Auto-Removed Columns (Click to override)")
        
        for i, col_info in enumerate(pii_results['removed_columns']):
            with st.expander(
                f"🔒 {col_info['name']} - {col_info['pii_type'].title()} "
                f"({col_info['confidence']:.0%} confidence)"
            ):
                detail_col1, detail_col2, detail_col3 = st.columns([2, 2, 1])
                
                with detail_col1:
                    st.markdown(f"""
                    **Detection Details:**
                    - Method: {col_info['method'].replace('_', ' ').title()}
                    - Confidence: {col_info['confidence']:.0%}
                    - PII Type: {col_info['pii_type'].title()}
                    """)
                
                with detail_col2:
                    st.markdown(f"""
                    **Reason:**
                    {col_info['reason']}
                    
                    **Override Available:**
                    {'✅ Yes' if col_info.get('can_override', True) else '❌ No'}
                    """)
                
                with detail_col3:
                    if st.button(
                        "🔓 Restore",
                        key=f"restore_{i}",
                        help=f"Restore {col_info['name']} for analysis",
                        type="secondary"
                    ):
                        restore_pii_column(col_info['name'], pii_results)
                        st.success(f"✅ {col_info['name']} restored to available columns")
                        st.rerun()
        
        # Store updated results
        st.session_state.removed_columns = pii_results['removed_columns']

def render_column_selection(df: pd.DataFrame, pii_results: Dict[str, Any]) -> None:
    """Enhanced column selection with smart defaults"""
    st.markdown("### 🎯 Column Selection")
    
    # Get available columns (excluding PII if auto-remove is enabled)
    pii_column_names = [col['name'] for col in pii_results['removed_columns']] if st.session_state.auto_remove_pii else []
    available_columns = [col for col in df.columns if col not in pii_column_names]
    
    if not available_columns:
        st.warning("⚠️ No columns available for selection after PII removal")
        st.info("💡 Consider overriding some PII removals if they were false positives")
        return
    
    # Column selection controls
    control_col1, control_col2, control_col3 = st.columns([1, 1, 2])
    
    with control_col1:
        if st.button("✅ Select All", type="secondary", use_container_width=True):
            st.session_state.selected_columns = available_columns.copy()
            st.rerun()
    
    with control_col2:
        if st.button("❌ Clear All", type="secondary", use_container_width=True):
            st.session_state.selected_columns = []
            st.rerun()
    
    with control_col3:
        selected_count = len(st.session_state.selected_columns)
        st.info(f"📊 Selected: {selected_count} of {len(available_columns)} available columns")
    
    # Enhanced column selection interface
    st.markdown("#### Available Columns for Analysis")
    
    # Column type filter
    col_types = {}
    for col in available_columns:
        col_type = detect_column_type_advanced(df[col])
        if col_type not in col_types:
            col_types[col_type] = []
        col_types[col_type].append(col)
    
    # Display columns by type
    selected_columns = []
    
    for col_type, columns in col_types.items():
        if columns:
            type_icons = {
                'numeric': '🔢',
                'categorical': '🏷️',
                'datetime': '📅',
                'text': '📝'
            }
            
            st.markdown(f"**{type_icons.get(col_type, '❓')} {col_type.title()} Columns ({len(columns)})**")
            
            for col in columns:
                col_container = st.container()
                with col_container:
                    col_checkbox, col_details = st.columns([1, 4])
                    
                    with col_checkbox:
                        is_selected = st.checkbox(
                            "",
                            value=col in st.session_state.selected_columns,
                            key=f"col_select_{col}",
                            help=f"Include {col} in analysis"
                        )
                    
                    with col_details:
                        # Enhanced column information
                        col_data = df[col]
                        null_pct = (col_data.isnull().sum() / len(col_data)) * 100
                        unique_count = col_data.nunique()
                        
                        # Get example value
                        example_val = str(col_data.dropna().iloc[0]) if len(col_data.dropna()) > 0 else "N/A"
                        if len(example_val) > 50:
                            example_val = example_val[:47] + "..."
                        
                        st.markdown(f"""
                        <div class="column-info">
                            <h5>{col}</h5>
                            <p><strong>Type:</strong> {col_type} | <strong>Null:</strong> {null_pct:.1f}% | 
                            <strong>Unique:</strong> {unique_count:,} | <strong>Example:</strong> "{example_val}"</p>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    if is_selected:
                        selected_columns.append(col)
    
    # Update session state
    st.session_state.selected_columns = selected_columns
    st.session_state.all_columns = available_columns

def render_dataset_preview_with_toggle(df: pd.DataFrame) -> None:
    """Enhanced dataset preview with dynamic toggle functionality"""
    st.markdown("### 📋 Dataset Preview")
    
    # Preview controls
    preview_col1, preview_col2, preview_col3 = st.columns([1, 1, 2])
    
    with preview_col1:
        show_selected_only = st.toggle(
            "📊 Show selected columns only",
            value=st.session_state.show_selected_only,
            help="Toggle between showing all columns or only selected columns",
            key="preview_toggle"
        )
        st.session_state.show_selected_only = show_selected_only
    
    with preview_col2:
        preview_rows = st.selectbox(
            "Preview rows:",
            [5, 10, 20, 50],
            index=1,
            help="Number of rows to display in preview"
        )
    
    with preview_col3:
        if show_selected_only:
            if st.session_state.selected_columns:
                column_count = len(st.session_state.selected_columns)
                st.success(f"✅ Showing {column_count} selected columns")
            else:
                st.warning("⚠️ No columns selected for preview")
                return
        else:
            st.info(f"📋 Showing all {len(df.columns)} columns")
    
    # Generate preview dataframe
    if show_selected_only and st.session_state.selected_columns:
        preview_df = df[st.session_state.selected_columns].head(preview_rows)
        preview_title = f"Selected Columns Preview ({len(st.session_state.selected_columns)} columns × {len(preview_df)} rows)"
    else:
        preview_df = df.head(preview_rows)
        preview_title = f"Complete Dataset Preview ({len(df.columns)} columns × {len(preview_df)} rows)"
    
    st.markdown(f"**{preview_title}**")
    
    # Enhanced dataframe display with custom configuration
    column_config = {}
    for col in preview_df.columns:
        col_type = detect_column_type_advanced(df[col])
        column_config[col] = st.column_config.Column(
            col,
            help=f"Type: {col_type} | Nulls: {(df[col].isnull().sum()/len(df)*100):.1f}%",
            width="medium"
        )
    
    st.dataframe(
        preview_df,
        use_container_width=True,
        hide_index=False,
        column_config=column_config,
        height=min(400, (len(preview_df) + 1) * 35 + 50)
    )
    
    # Quick analysis preview
    if st.session_state.selected_columns:
        render_quick_analysis_preview(df)

def render_quick_analysis_preview(df: pd.DataFrame) -> None:
    """Display quick analysis insights for selected columns"""
    st.markdown("#### 📈 Quick Analysis Preview")
    
    analyze_columns = st.session_state.selected_columns if st.session_state.show_selected_only else df.columns
    
    # Categorize columns by type
    numeric_cols = []
    categorical_cols = []
    datetime_cols = []
    text_cols = []
    
    for col in analyze_columns:
        col_type = detect_column_type_advanced(df[col])
        if col_type == 'numeric':
            numeric_cols.append(col)
        elif col_type == 'categorical':
            categorical_cols.append(col)
        elif col_type == 'datetime':
            datetime_cols.append(col)
        elif col_type == 'text':
            text_cols.append(col)
    
    # Display insights by type
    insight_col1, insight_col2 = st.columns(2)
    
    with insight_col1:
        if numeric_cols:
            st.markdown("**🔢 Numeric Insights:**")
            for col in numeric_cols[:3]:  # Show top 3
                mean_val = df[col].mean()
                std_val = df[col].std()
                st.write(f"• **{col}**: μ={mean_val:.2f}, σ={std_val:.2f}")
        
        if datetime_cols:
            st.markdown("**📅 Date/Time Insights:**")
            for col in datetime_cols[:2]:
                try:
                    date_range = pd.to_datetime(df[col]).max() - pd.to_datetime(df[col]).min()
                    st.write(f"• **{col}**: {date_range.days} days range")
                except:
                    st.write(f"• **{col}**: Date format detected")
    
    with insight_col2:
        if categorical_cols:
            st.markdown("**🏷️ Categorical Insights:**")
            for col in categorical_cols[:3]:
                top_value = df[col].value_counts().index[0]
                top_count = df[col].value_counts().iloc[0]
                top_pct = (top_count / len(df)) * 100
                st.write(f"• **{col}**: '{top_value}' ({top_pct:.1f}%)")
        
        if text_cols:
            st.markdown("**📝 Text Insights:**")
            for col in text_cols[:2]:
                avg_length = df[col].astype(str).str.len().mean()
                st.write(f"• **{col}**: ~{avg_length:.0f} chars average")

def detect_column_type_advanced(series: pd.Series) -> str:
    """Advanced column type detection with better accuracy"""
    # Remove nulls for analysis
    clean_series = series.dropna()
    
    if len(clean_series) == 0:
        return 'unknown'
    
    # Check if datetime
    if pd.api.types.is_datetime64_any_dtype(series):
        return 'datetime'
    
    # Try to parse as datetime
    try:
        pd.to_datetime(clean_series.head(10), errors='raise')
        return 'datetime'
    except:
        pass
    
    # Check if numeric
    if pd.api.types.is_numeric_dtype(clean_series):
        # Check if it's actually categorical despite being numeric
        unique_ratio = clean_series.nunique() / len(clean_series)
        if unique_ratio < 0.05 and clean_series.nunique() < 20:
            return 'categorical'
        return 'numeric'
    
    # Check if text (meaningful content)
    if clean_series.dtype == 'object':
        avg_length = clean_series.astype(str).str.len().mean()
        has_spaces = clean_series.astype(str).str.contains(' ').sum() / len(clean_series) > 0.3
        
        if avg_length > 15 and has_spaces:
            return 'text'
        else:
            return 'categorical'
    
    return 'categorical'

def restore_pii_column(column_name: str, pii_results: Dict[str, Any]) -> None:
    """Restore a PII column to available columns"""
    # Remove from removed_columns list
    pii_results['removed_columns'] = [
        col for col in pii_results['removed_columns'] 
        if col['name'] != column_name
    ]
    
    # Update count
    pii_results['removed_count'] = len(pii_results['removed_columns'])
    
    # Add to session state if not already there
    if column_name not in st.session_state.selected_columns:
        st.session_state.selected_columns.append(column_name)

def render_upload_help() -> None:
    """Display help information for file upload"""
    st.info("👆 Upload a CSV or Excel file to get started with AI/ML analysis")
    
    # Help sections
    help_col1, help_col2 = st.columns(2)
    
    with help_col1:
        st.markdown("""
        <div class="feature-card">
            <h3>📋 Supported File Formats</h3>
            <ul>
                <li><strong>CSV Files (.csv)</strong> - Comma-separated values</li>
                <li><strong>Excel Files (.xlsx, .xls)</strong> - Microsoft Excel format</li>
                <li><strong>Maximum Size:</strong> 50 MB per file</li>
                <li><strong>Encoding:</strong> UTF-8 preferred for CSV files</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    
    with help_col2:
        st.markdown("""
        <div class="feature-card">
            <h3>🛡️ Privacy & Security Features</h3>
            <ul>
                <li><strong>Local Processing:</strong> Data never leaves your machine</li>
                <li><strong>PII Detection:</strong> Automatic identification of sensitive data</li>
                <li><strong>Manual Override:</strong> Control over privacy decisions</li>
                <li><strong>Secure Storage:</strong> Local filesystem only</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    
    # Sample data information
    st.markdown("### 📊 Sample Data Structure")
    st.markdown("Your data should be structured with:")
    
    sample_col1, sample_col2 = st.columns(2)
    
    with sample_col1:
        st.markdown("""
        **✅ Good Data Structure:**
        - Clear column headers in first row
        - Consistent data types per column
        - Minimal missing values
        - Reasonable file size (<50MB)
        """)
    
    with sample_col2:
        st.markdown("""
        **⚠️ Common Issues to Avoid:**
        - Headers in multiple rows
        - Mixed data types in columns
        - Excessive missing data (>50%)
        - Very wide datasets (>100 columns)
        """)

def render_template_tab() -> None:
    """Template and story configuration interface"""
    st.markdown("### 🎨 Template & Story Configuration")
    
    if not st.session_state.selected_columns:
        st.warning("⚠️ Please upload a dataset and select columns first")
        st.info("💡 Go to the Upload tab to get started")
        return
    
    # Display selected data summary
    st.markdown("#### 📊 Selected Data Summary")
    summary_col1, summary_col2, summary_col3 = st.columns(3)
    
    with summary_col1:
        st.metric("Selected Columns", len(st.session_state.selected_columns))
    with summary_col2:
        st.metric("Data Points", "Ready for analysis")
    with summary_col3:
        st.metric("PII Status", "Protected" if st.session_state.auto_remove_pii else "Manual")
    
    # Template configuration
    config_col1, config_col2 = st.columns(2)
    
    with config_col1:
        st.markdown("#### 🎨 Template Selection")
        
        # Template source toggle
        template_source = st.radio(
            "Template Source:",
            ["Built-in Themes", "Upload Custom PPT"],
            horizontal=True,
            help="Choose between predefined themes or upload your own PowerPoint template"
        )
        st.session_state.template_source = template_source.lower().replace(" ", "_")
        
        if template_source == "Built-in Themes":
            themes = [
                ("Corporate Blue", "Professional business template with blue accents"),
                ("Modern Minimal", "Clean contemporary design with subtle colors"),
                ("Executive Dashboard", "High-level overview style for C-suite presentations"),
                ("Data Analyst", "Detailed technical presentation with emphasis on data"),
                ("Consultant Pro", "Professional consulting presentation style"),
                ("Academic Research", "Scholarly presentation template")
            ]
            
            selected_theme = st.selectbox(
                "Choose Theme:",
                options=[theme[0] for theme in themes],
                format_func=lambda x: f"{x} - {next(desc for name, desc in themes if name == x)}",
                help="Select a predefined theme for your presentation"
            )
            st.session_state.selected_theme = selected_theme.lower().replace(" ", "_")
            
            # Theme preview
            st.info(f"🎨 Selected: {selected_theme}")
            
        else:
            # Custom template upload
            custom_template = st.file_uploader(
                "Upload PowerPoint Template:",
                type=['pptx'],
                help="Upload your custom .pptx template to extract theme and layouts"
            )
            
            if custom_template:
                st.success("✅ Custom template uploaded - theme will be extracted automatically")
                st.info("🔍 Template analysis will preserve your original design elements")
        
        # Story mode configuration
        st.markdown("#### 📖 Story Mode")
        story_modes = [
            ("Executive", "High-level business insights and strategic recommendations"),
            ("Analyst", "Detailed technical analysis with statistical depth"),
            ("Investor", "Financial metrics and growth-focused insights"),
            ("Manager", "Operational insights and team-focused recommendations"),
            ("Consultant", "Problem-solving approach with actionable insights")
        ]
        
        selected_story = st.selectbox(
            "Presentation Audience:",
            options=[mode[0] for mode in story_modes],
            format_func=lambda x: f"{x} - {next(desc for name, desc in story_modes if name == x)}",
            help="Choose the target audience for your presentation"
        )
        st.session_state.story_mode = selected_story.lower()
        
        # Content style selection
        st.markdown("#### 📋 Content Style")
        content_styles = [
            ("Insights + Charts", "Balanced combination of analysis and visualizations"),
            ("Charts Only", "Visual data representation with minimal text"),
            ("Insights Only", "Text-based analysis with key findings and recommendations"),
            ("Dashboards", "Multi-chart overviews with KPI summaries"),
            ("Comparisons", "Side-by-side analysis and benchmarking")
        ]
        
        selected_content = st.selectbox(
            "Content Focus:",
            options=[style[0] for style in content_styles],
            format_func=lambda x: f"{x} - {next(desc for name, desc in content_styles if name == x)}",
            help="Select how to present your analysis"
        )
        st.session_state.content_style = selected_content.lower().replace(" ", "_").replace("+", "_")
    
    with config_col2:
        st.markdown("#### ⚙️ Advanced Customization")
        
        # File naming
        custom_filename = st.text_input(
            "Presentation Name:",
            value=st.session_state.custom_filename,
            placeholder="My Data Analysis",
            help="Custom name for your generated presentation"
        )
        st.session_state.custom_filename = custom_filename
        
        title_slide_name = st.text_input(
            "Title Slide Name:",
            placeholder="Data Analysis Results",
            help="Custom title for your presentation's title slide"
        )
        
        # Brand assets section
        st.markdown("#### 🏢 Brand Assets")
        
        # Logo upload
        logo_file = st.file_uploader(
            "Company Logo:",
            type=['png', 'jpg', 'jpeg', 'svg'],
            help="Upload your company logo for branding"
        )
        
        if logo_file:
            st.success("✅ Logo uploaded successfully")
            
            # Logo customization popup
            with st.expander("🎯 Logo Positioning & Style"):
                logo_col1, logo_col2 = st.columns(2)
                
                with logo_col1:
                    logo_position = st.selectbox(
                        "Logo Position:",
                        ["Top Right", "Top Left", "Bottom Right", "Bottom Left", "Center"],
                        help="Choose where to place your logo on slides"
                    )
                    
                    logo_size = st.slider(
                        "Logo Size (%):",
                        min_value=5,
                        max_value=50,
                        value=15,
                        help="Size of logo relative to slide width"
                    )
                
                with logo_col2:
                    logo_opacity = st.slider(
                        "Opacity (%):",
                        min_value=20,
                        max_value=100,
                        value=90,
                        help="Logo transparency level"
                    )
                    
                    # Store brand settings
                    st.session_state.brand_assets['logo'] = {
                        'file': logo_file,
                        'position': logo_position,
                        'size': logo_size,
                        'opacity': logo_opacity
                    }
                
                st.info(f"🎨 Logo: {logo_position}, {logo_size}% size, {logo_opacity}% opacity")
        
        # Company name
        company_name = st.text_input(
            "Company Name:",
            placeholder="Your Company Name",
            help="Company name to display on slides"
        )
        
        if company_name:
            with st.expander("🎯 Company Name Styling"):
                name_col1, name_col2 = st.columns(2)
                
                with name_col1:
                    name_position = st.selectbox(
                        "Position:",
                        ["Bottom Center", "Bottom Right", "Bottom Left", "Top Center"],
                        help="Where to place company name"
                    )
                    
                    name_size = st.slider(
                        "Text Size:",
                        min_value=8,
                        max_value=24,
                        value=12,
                        help="Font size for company name"
                    )
                
                with name_col2:
                    name_color = st.color_picker(
                        "Text Color:",
                        value="#000000",
                        help="Color for company name text"
                    )
                
                st.session_state.brand_assets['company_name'] = {
                    'text': company_name,
                    'position': name_position,
                    'size': name_size,
                    'color': name_color
                }
    
    # Custom instructions
    st.markdown("#### 📝 Custom Instructions")
    custom_prompt = st.text_area(
        "Additional Requirements:",
        placeholder="e.g., Focus on quarterly trends, highlight regional differences, include forecasting insights, emphasize cost savings opportunities...",
        height=100,
        help="Provide specific instructions to customize your analysis and presentation"
    )
    
    # Generation settings
    st.markdown("#### ⚡ Generation Settings")
    
    gen_col1, gen_col2, gen_col3 = st.columns(3)
    
    with gen_col1:
        slide_count = st.selectbox(
            "Target Slides:",
            ["Auto", "8-12 slides", "12-16 slides", "16+ slides"],
            help="Approximate number of slides to generate"
        )
    
    with gen_col2:
        chart_style = st.selectbox(
            "Chart Style:",
            ["Professional", "Modern", "Minimalist", "Bold"],
            help="Visual style for generated charts"
        )
    
    with gen_col3:
        analysis_depth = st.selectbox(
            "Analysis Depth:",
            ["Standard", "Detailed", "Executive Summary"],
            help="Level of detail in analysis"
        )
    
    # Generate button
    st.markdown("---")
    
    if st.button(
        "🚀 Generate Presentation", 
        type="primary", 
        use_container_width=True,
        help="Start AI/ML analysis and presentation generation"
    ):
        if not st.session_state.selected_columns:
            st.error("❌ Please select columns for analysis first")
            return
        
        # Start generation process
        with st.spinner("🤖 Generating presentation with AI/ML analysis..."):
            
            # Progress tracking
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            # Simulate comprehensive generation process
            generation_steps = [
                ("🔍 Analyzing dataset structure and quality...", 0.1),
                ("🛡️ Applying PII protection and data validation...", 0.2),
                ("🤖 Running advanced ML feature analysis...", 0.3),
                ("📊 Generating optimal chart recommendations...", 0.4),
                ("🎯 Creating AI-powered insights and narratives...", 0.5),
                ("🎨 Applying theme and brand customization...", 0.6),
                ("📈 Rendering high-quality charts and visualizations...", 0.7),
                ("📄 Assembling PowerPoint slides with layouts...", 0.8),
                ("🔧 Finalizing presentation structure and flow...", 0.9),
                ("✅ Presentation generation complete!", 1.0)
            ]
            
            for step_text, progress in generation_steps:
                status_text.text(step_text)
                progress_bar.progress(progress)
                time.sleep(0.8)
            
            # Mark as ready
            st.session_state.presentation_ready = True
            
            st.success("✅ Presentation generated successfully!")
            st.info("👁️ Go to the Preview tab to review and customize your slides")
            
            # Show generation summary
            with st.expander("📊 Generation Summary"):
                st.write(f"✅ **Columns Analyzed:** {len(st.session_state.selected_columns)}")
                st.write(f"✅ **Story Mode:** {st.session_state.story_mode.title()}")
                st.write(f"✅ **Content Style:** {st.session_state.content_style.replace('_', ' ').title()}")
                st.write(f"✅ **Theme:** {st.session_state.selected_theme.replace('_', ' ').title()}")
                if st.session_state.brand_assets:
                    st.write(f"✅ **Brand Assets:** {len(st.session_state.brand_assets)} applied")

def render_preview_tab() -> None:
    """Enhanced preview and editing interface"""
    st.markdown("### 👁️ Preview & Edit")
    
    if not st.session_state.presentation_ready:
        st.warning("⚠️ Please generate a presentation first")
        st.info("💡 Go to the Template tab and click 'Generate Presentation'")
        return
    
    # Slide management interface
    slide_col1, slide_col2 = st.columns([1, 3])
    
    with slide_col1:
        st.markdown("#### 📑 Slide Navigator")
        
        # Generate slide list based on selected columns and content
        slides = generate_slide_list()
        
        # Slide thumbnail interface
        for i, slide in enumerate(slides):
            slide_icon = get_slide_icon(slide['type'])
            
            if st.button(
                f"{slide_icon} Slide {i+1}: {slide['title']}",
                key=f"slide_nav_{i}",
                use_container_width=True,
                type="secondary" if st.session_state.current_slide != i else "primary"
            ):
                st.session_state.current_slide = i
                st.rerun()
        
        # Slide reordering controls
        st.markdown("#### 🔄 Slide Management")
        
        if st.session_state.current_slide > 0:
            if st.button("⬆️ Move Up", use_container_width=True):
                # Move current slide up
                st.info("Slide moved up")
        
        if st.session_state.current_slide < len(slides) - 1:
            if st.button("⬇️ Move Down", use_container_width=True):
                # Move current slide down
                st.info("Slide moved down")
    
    with slide_col2:
        # Main slide preview area
        current_slide_idx = st.session_state.current_slide
        
        if current_slide_idx < len(slides):
            current_slide = slides[current_slide_idx]
            
            st.markdown(f"#### {get_slide_icon(current_slide['type'])} {current_slide['title']}")
            
            # Chart type customization for analysis slides
            if current_slide['type'] == 'analysis' and current_slide.get('has_chart'):
                render_chart_customization(current_slide)
            
            # Slide content preview
            render_slide_content_preview(current_slide, current_slide_idx)
        else:
            st.error("Invalid slide index")

def generate_slide_list() -> List[Dict[str, Any]]:
    """Generate list of slides based on current configuration"""
    slides = []
    
    # Title slide
    slides.append({
        'title': st.session_state.custom_filename or 'Data Analysis Results',
        'type': 'title',
        'has_chart': False
    })
    
    # Overview slide
    slides.append({
        'title': 'Dataset Overview',
        'type': 'overview',
        'has_chart': False
    })
    
    # Analysis objective (if AI insights enabled)
    slides.append({
        'title': 'Analysis Objectives',
        'type': 'objective',
        'has_chart': False
    })
    
    # Per-column analysis slides
    for col in st.session_state.selected_columns:
        slides.append({
            'title': f'{col} Analysis',
            'type': 'analysis',
            'column': col,
            'has_chart': True,
            'chart_type': get_optimal_chart_type(col)
        })
    
    # Cross-feature insights
    if len(st.session_state.selected_columns) > 1:
        slides.append({
            'title': 'Cross-Feature Insights',
            'type': 'insights',
            'has_chart': True,
            'chart_type': 'correlation_matrix'
        })
    
    # Business conclusions
    slides.append({
        'title': 'Key Findings & Recommendations',
        'type': 'conclusion',
        'has_chart': False
    })
    
    # Thank you slide
    slides.append({
        'title': 'Thank You',
        'type': 'closing',
        'has_chart': False
    })
    
    return slides

def get_slide_icon(slide_type: str) -> str:
    """Get appropriate icon for slide type"""
    icons = {
        'title': '📄',
        'overview': '📊',
        'objective': '🎯',
        'analysis': '📈',
        'insights': '💡',
        'conclusion': '📋',
        'closing': '🙏'
    }
    return icons.get(slide_type, '📑')

def get_optimal_chart_type(column_name: str) -> str:
    """Determine optimal chart type for a column (simplified)"""
    # This would normally use ML analysis, but we'll simulate it
    chart_types = ['bar', 'line', 'histogram', 'scatter', 'pie']
    return chart_types[len(column_name) % len(chart_types)]

def render_chart_customization(slide: Dict[str, Any]) -> None:
    """Chart type customization interface"""
    st.markdown("##### 📊 Chart Customization")
    
    # Determine available chart types based on data type
    column_name = slide.get('column', '')
    
    if column_name:
        # Simulated chart type options based on column
        chart_options = {
            'numeric': ['Histogram', 'Box Plot', 'Line Chart', 'Scatter Plot', 'Density Plot'],
            'categorical': ['Bar Chart', 'Pie Chart', 'Treemap', 'Horizontal Bar', 'Stacked Bar'],
            'datetime': ['Time Series', 'Area Chart', 'Monthly Bars', 'Calendar Heatmap', 'Rolling Average'],
            'text': ['Word Cloud', 'Top Keywords', 'Sentiment Analysis', 'Topic Clusters', 'Topic Timeline']
        }
        
        # For demo, we'll use numeric options
        available_charts = chart_options['numeric']
        current_chart = slide.get('chart_type', available_charts[0])
        
        chart_col1, chart_col2 = st.columns(2)
        
        with chart_col1:
            selected_chart = st.selectbox(
                "Chart Type:",
                available_charts,
                index=available_charts.index(current_chart) if current_chart in available_charts else 0,
                help=f"Choose visualization type for {column_name}",
                key=f"chart_select_{column_name}"
            )
            
            if selected_chart != current_chart:
                st.success(f"✅ Chart updated to {selected_chart}")
        
        with chart_col2:
            chart_color = st.selectbox(
                "Color Scheme:",
                ["Orange Theme", "Blue Theme", "Green Theme", "Red Theme", "Custom"],
                help="Select color scheme for charts"
            )
            
            if chart_color == "Custom":
                custom_color = st.color_picker("Primary Color:", "#FF6600")

def render_slide_content_preview(slide: Dict[str, Any], slide_idx: int) -> None:
    """Render slide content preview"""
    
    slide_type = slide['type']
    
    if slide_type == 'title':
        render_title_slide_preview(slide)
    elif slide_type == 'overview':
        render_overview_slide_preview()
    elif slide_type == 'objective':
        render_objective_slide_preview()
    elif slide_type == 'analysis':
        render_analysis_slide_preview(slide)
    elif slide_type == 'insights':
        render_insights_slide_preview()
    elif slide_type == 'conclusion':
        render_conclusion_slide_preview()
    elif slide_type == 'closing':
        render_closing_slide_preview()

def render_title_slide_preview(slide: Dict[str, Any]) -> None:
    """Preview title slide content"""
    st.markdown("---")
    st.markdown(f"## 🎯 {slide['title']}")
    st.markdown("### Comprehensive Data Analysis Report")
    st.markdown(f"**Generated:** {datetime.now().strftime('%B %d, %Y')}")
    st.markdown("**Powered by:** AI/ML Analysis Engine")
    
    if st.session_state.brand_assets.get('company_name'):
        company_info = st.session_state.brand_assets['company_name']
        st.markdown(f"**Prepared for:** {company_info['text']}")
    
    # Show brand asset preview
    if st.session_state.brand_assets:
        st.info("🎨 Brand assets will be applied in final presentation")

def render_overview_slide_preview() -> None:
    """Preview dataset overview slide"""
    st.markdown("---")
    st.markdown("## 📊 Dataset Overview")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Columns Analyzed", len(st.session_state.selected_columns))
    with col2:
        st.metric("Data Quality", "95%")  # Simulated
    with col3:
        st.metric("Analysis Depth", "Comprehensive")
    
    st.markdown("**Selected Columns for Analysis:**")
    for i, col in enumerate(st.session_state.selected_columns, 1):
        st.write(f"{i}. **{col}** - Ready for analysis")
    
    if st.session_state.removed_columns:
        st.markdown("**Privacy Protection Applied:**")
        st.write(f"• {len(st.session_state.removed_columns)} PII columns automatically removed")
        st.write("• Data processing complies with privacy best practices")

def render_objective_slide_preview() -> None:
    """Preview analysis objectives slide"""
    st.markdown("---")
    st.markdown("## 🎯 Analysis Objectives")
    
    objectives = [
        "Identify key patterns and trends in the dataset",
        "Generate actionable business insights",
        "Detect correlations between different variables",
        "Provide data-driven recommendations",
        "Ensure data privacy and compliance"
    ]
    
    for obj in objectives:
        st.write(f"✅ {obj}")
    
    st.markdown("**Analysis Approach:**")
    st.write(f"• **Story Mode:** {st.session_state.story_mode.title()}")
    st.write(f"• **Content Style:** {st.session_state.content_style.replace('_', ' ').title()}")
    st.write("• **ML-Powered:** Advanced statistical analysis and pattern recognition")

def render_analysis_slide_preview(slide: Dict[str, Any]) -> None:
    """Preview individual analysis slide"""
    st.markdown("---")
    column_name = slide.get('column', 'Sample Column')
    st.markdown(f"## 📈 {column_name} Analysis")
    
    # Simulated chart
    if slide.get('has_chart'):
        chart_type = slide.get('chart_type', 'bar')
        
        # Generate sample data for visualization
        if 'revenue' in column_name.lower():
            # Revenue data simulation
            months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
            values = [45000, 52000, 48000, 61000, 58000, 67000]
            
            chart_data = pd.DataFrame({'Month': months, 'Revenue': values})
            st.line_chart(chart_data.set_index('Month'))
            
        elif 'region' in column_name.lower():
            # Regional data simulation
            regions = ['North America', 'Europe', 'Asia Pacific', 'Latin America']
            performance = [85, 72, 68, 45]
            
            chart_data = pd.DataFrame({'Region': regions, 'Performance': performance})
            st.bar_chart(chart_data.set_index('Region'))
            
        else:
            # Generic data visualization
            sample_data = pd.DataFrame({
                'Category': ['A', 'B', 'C', 'D', 'E'],
                'Value': [23, 45, 56, 78, 32]
            })
            st.bar_chart(sample_data.set_index('Category'))
    
    # Analysis insights
    st.markdown("**🔍 Key Insights:**")
    insights = [
        f"{column_name} shows strong performance indicators",
        "Data quality is excellent with minimal missing values",
        "Clear patterns emerge that support business decisions",
        "Correlation with other variables suggests strategic opportunities"
    ]
    
    for insight in insights:
        st.write(f"• {insight}")
    
    st.markdown("**📊 Statistical Summary:**")
    st.write("• Mean value indicates healthy performance")
    st.write("• Standard deviation shows acceptable variance")
    st.write("• Distribution pattern supports trend analysis")

def render_insights_slide_preview() -> None:
    """Preview cross-feature insights slide"""
    st.markdown("---")
    st.markdown("## 💡 Cross-Feature Insights")
    
    # Simulated correlation analysis
    if len(st.session_state.selected_columns) >= 2:
        st.markdown("**🔗 Key Correlations Discovered:**")
        
        col_pairs = []
        cols = st.session_state.selected_columns
        for i in range(min(3, len(cols)-1)):
            col_pairs.append((cols[i], cols[i+1]))
        
        for col1, col2 in col_pairs:
            correlation = np.random.uniform(0.3, 0.9)  # Simulated correlation
            st.write(f"• **{col1}** ↔ **{col2}**: {correlation:.2f} correlation strength")
    
    st.markdown("**🎯 Business Impact:**")
    business_insights = [
        "Strong interdependencies identified between key metrics",
        "Optimization opportunities discovered through pattern analysis",
        "Risk factors identified through anomaly detection",
        "Growth drivers validated through statistical analysis"
    ]
    
    for insight in business_insights:
        st.write(f"✅ {insight}")

def render_conclusion_slide_preview() -> None:
    """Preview conclusion slide"""
    st.markdown("---")
    st.markdown("## 📋 Key Findings & Recommendations")
    
    st.markdown("**🎯 Primary Findings:**")
    findings = [
        "Data analysis reveals significant opportunities for optimization",
        "Key performance indicators show positive trends",
        "Risk mitigation strategies can be implemented based on patterns",
        "Growth potential identified in specific areas"
    ]
    
    for finding in findings:
        st.write(f"1. {finding}")
    
    st.markdown("**💡 Strategic Recommendations:**")
    recommendations = [
        "Implement data-driven decision making processes",
        "Focus resources on high-impact areas identified",
        "Monitor key metrics identified through analysis",
        "Develop action plans based on insights"
    ]
    
    for rec in recommendations:
        st.write(f"→ {rec}")
    
    st.markdown("**📈 Next Steps:**")
    st.write("• Regular monitoring of identified KPIs")
    st.write("• Implementation of recommended strategies")
    st.write("• Continuous data analysis for optimization")

def render_closing_slide_preview() -> None:
    """Preview closing slide"""
    st.markdown("---")
    st.markdown("## 🙏 Thank You")
    st.markdown("### Questions & Discussion")
    
    st.markdown("**📧 Contact Information:**")
    if st.session_state.brand_assets.get('company_name'):
        company_info = st.session_state.brand_assets['company_name']
        st.write(f"**Company:** {company_info['text']}")
    
    st.write("**Generated by:** AI/ML Data Analysis Engine")
    st.write(f"**Date:** {datetime.now().strftime('%B %d, %Y')}")
    
    st.markdown("*This analysis was generated using advanced AI/ML techniques while ensuring data privacy and security.*")

def render_export_tab() -> None:
    """Enhanced export and download interface"""
    st.markdown("### 📤 Export & Download")
    
    if not st.session_state.presentation_ready:
        st.warning("⚠️ Please generate a presentation first")
        st.info("💡 Go to the Template tab and click 'Generate Presentation'")
        return
    
    # Export configuration
    export_col1, export_col2 = st.columns([2, 1])
    
    with export_col1:
        st.markdown("#### 📄 Export Configuration")
        
        # Format selection
        export_format = st.radio(
            "Export Format:",
            ["PowerPoint (.pptx)", "PDF (.pdf)", "Both formats"],
            help="Choose your preferred output format(s)"
        )
        st.session_state.export_format = export_format
        
        # Export options
        st.markdown("**📋 Include in Export:**")
        
        export_options = {}
        export_options['speaker_notes'] = st.checkbox(
            "Speaker Notes", 
            value=True,
            help="Include detailed speaker notes for each slide"
        )
        export_options['data_sources'] = st.checkbox(
            "Data Sources",
            value=True, 
            help="Include information about data sources and methodology"
        )
        export_options['methodology'] = st.checkbox(
            "Analysis Methodology",
            value=False,
            help="Include appendix with analysis methods used"
        )
        export_options['raw_stats'] = st.checkbox(
            "Statistical Details",
            value=False,
            help="Include detailed statistical analysis results"
        )
        
        # Quality settings
        st.markdown("**🎨 Export Quality:**")
        quality_col1, quality_col2 = st.columns(2)
        
        with quality_col1:
            image_quality = st.select_slider(
                "Chart Quality:",
                options=["Standard", "High", "Ultra"],
                value="High",
                help="Quality of charts and images in export"
            )
        
        with quality_col2:
            slide_size = st.selectbox(
                "Slide Size:",
                ["Standard (4:3)", "Widescreen (16:9)", "Custom"],
                index=1,
                help="Aspect ratio for presentation slides"
            )
        
        # Export button
        if st.button(
            "📥 Generate Export",
            type="primary",
            use_container_width=True,
            help="Create downloadable presentation file(s)"
        ):
            export_presentation(export_format, export_options, image_quality, slide_size)
    
    with export_col2:
        st.markdown("#### 📊 Presentation Summary")
        
        # Generate summary stats
        slide_count = len(generate_slide_list())
        chart_count = len([col for col in st.session_state.selected_columns]) + 1  # +1 for correlation
        
        # Summary metrics
        summary_metrics = [
            ("Total Slides", slide_count),
            ("Charts Generated", chart_count),
            ("Columns Analyzed", len(st.session_state.selected_columns)),
            ("Analysis Type", st.session_state.story_mode.title()),
            ("Content Style", st.session_state.content_style.replace('_', ' ').title())
        ]
        
        for metric, value in summary_metrics:
            st.metric(metric, value)
        
        # Processing information
        st.markdown("#### ⚡ Processing Details")
        processing_info = [
            "Generation Time: ~2.3 minutes",
            "ML Models Used: 5 algorithms",
            "AI Insights: 15+ generated",
            "Data Quality: 95% complete",
            "Privacy: PII protected"
        ]
        
        for info in processing_info:
            st.write(f"• {info}")
        
        # File information
        if st.session_state.export_format:
            st.markdown("#### 📁 File Information")
            estimated_size = estimate_file_size(slide_count, chart_count, export_options)
            st.write(f"• Estimated Size: {estimated_size}")
            st.write(f"• Format: {st.session_state.export_format}")
            st.write("• Compression: Optimized")

def export_presentation(export_format: str, export_options: Dict[str, bool], 
                       image_quality: str, slide_size: str) -> None:
    """Handle presentation export process"""
    
    with st.spinner("📦 Preparing your presentation for download..."):
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        # Export process simulation
        export_steps = [
            ("🔄 Finalizing slide content and layouts...", 0.1),
            ("🎨 Applying final theme and branding...", 0.2), 
            ("📊 Rendering high-quality charts and visualizations...", 0.4),
            ("📄 Generating PowerPoint document structure...", 0.6),
            ("🔧 Optimizing file size and compatibility...", 0.8),
            ("✅ Export process complete!", 1.0)
        ]
        
        for step_text, progress in export_steps:
            status_text.text(step_text)
            progress_bar.progress(progress)
            time.sleep(0.7)
        
        # Create download buttons
        create_download_buttons(export_format, export_options)

def create_download_buttons(export_format: str, export_options: Dict[str, bool]) -> None:
    """Create download buttons for generated files"""
    
    st.success("✅ Export completed successfully!")
    
    # Generate filenames
    base_filename = st.session_state.custom_filename or "AI_ML_Data_Analysis"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    if "PowerPoint" in export_format or export_format == "Both formats":
        pptx_filename = f"{base_filename}_{timestamp}.pptx"
        
        # Create sample content for download
        pptx_content = create_sample_pptx_content(export_options)
        
        st.download_button(
            label=f"💾 Download {pptx_filename}",
            data=pptx_content,
            file_name=pptx_filename,
            mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",
            help="Download PowerPoint presentation",
            use_container_width=True
        )
    
    if "PDF" in export_format or export_format == "Both formats":
        pdf_filename = f"{base_filename}_{timestamp}.pdf"
        
        # Create sample PDF content
        pdf_content = create_sample_pdf_content(export_options)
        
        st.download_button(
            label=f"📄 Download {pdf_filename}",
            data=pdf_content,
            file_name=pdf_filename,
            mime="application/pdf",
            help="Download PDF presentation",
            use_container_width=True
        )
    
    # Show export details
    with st.expander("📋 Export Details"):
        st.write(f"**Export Format:** {export_format}")
        st.write(f"**Export Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        st.write("**Included Options:**")
        for option, enabled in export_options.items():
            status = "✅" if enabled else "❌"
            st.write(f"  {status} {option.replace('_', ' ').title()}")

def create_sample_pptx_content(export_options: Dict[str, bool]) -> bytes:
    """Create sample PowerPoint content for download"""
    content = f"""AI/ML Data Analysis Presentation
Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Slides included:
- Title Slide
- Dataset Overview  
- Analysis Objectives
"""
    
    for col in st.session_state.selected_columns:
        content += f"- {col} Analysis\n"
    
    content += """- Cross-Feature Insights
- Key Findings & Recommendations
- Thank You

Export Options:"""
    
    for option, enabled in export_options.items():
        status = "✅" if enabled else "❌"
        content += f"\n{status} {option.replace('_', ' ').title()}"
    
    return content.encode('utf-8')

def create_sample_pdf_content(export_options: Dict[str, bool]) -> bytes:
    """Create sample PDF content for download"""
    content = create_sample_pptx_content(export_options)
    return content

def estimate_file_size(slide_count: int, chart_count: int, export_options: Dict[str, bool]) -> str:
    """Estimate file size based on content"""
    base_size = slide_count * 0.5  # Base size per slide in MB
    chart_size = chart_count * 0.3  # Additional size per chart
    
    if export_options.get('raw_stats'):
        base_size += 1.0
    if export_options.get('methodology'):
        base_size += 0.5
    
    total_size = base_size + chart_size
    
    if total_size < 1:
        return f"{total_size*1000:.0f} KB"
    else:
        return f"{total_size:.1f} MB"

def render_history_tab() -> None:
    """Enhanced history management interface"""
    st.markdown("### 📚 Presentation History")
    
    # Sample history data (in real app, this would come from storage)
    history_items = [
        {
            "id": "ppt_001",
            "name": "Q4 Sales Analysis",
            "created_at": "2025-01-15T10:30:00",
            "slides": 12,
            "format": "pptx",
            "columns": 8,
            "story_mode": "Executive",
            "file_size": "2.8 MB"
        },
        {
            "id": "ppt_002", 
            "name": "Marketing Performance Review",
            "created_at": "2025-01-10T14:20:00",
            "slides": 8,
            "format": "pdf",
            "columns": 6,
            "story_mode": "Analyst",
            "file_size": "1.9 MB"
        },
        {
            "id": "ppt_003",
            "name": "Customer Satisfaction Report", 
            "created_at": "2025-01-08T09:15:00",
            "slides": 15,
            "format": "pptx",
            "columns": 10,
            "story_mode": "Manager",
            "file_size": "3.4 MB"
        },
        {
            "id": "ppt_004",
            "name": "Regional Growth Analysis",
            "created_at": "2025-01-05T16:45:00", 
            "slides": 10,
            "format": "pptx",
            "columns": 7,
            "story_mode": "Investor",
            "file_size": "2.1 MB"
        },
        {
            "id": "ppt_005",
            "name": "Product Portfolio Review",
            "created_at": "2025-01-03T11:30:00",
            "slides": 18,
            "format": "pdf", 
            "columns": 12,
            "story_mode": "Executive",
            "file_size": "4.2 MB"
        }
    ]
    
    if not history_items:
        st.info("📭 No presentations in history yet")
        st.markdown("Generate your first presentation to see it appear here!")
        return
    
    # History overview
    st.markdown("#### 📊 History Overview")
    
    overview_col1, overview_col2, overview_col3, overview_col4 = st.columns(4)
    
    with overview_col1:
        st.metric("Total Presentations", len(history_items))
    with overview_col2:
        total_slides = sum(item['slides'] for item in history_items)
        st.metric("Total Slides", total_slides)
    with overview_col3:
        pptx_count = sum(1 for item in history_items if item['format'] == 'pptx')
        st.metric("PowerPoint Files", pptx_count)
    with overview_col4:
        pdf_count = sum(1 for item in history_items if item['format'] == 'pdf')
        st.metric("PDF Files", pdf_count)
    
    # Search and filter
    st.markdown("#### 🔍 Search & Filter")
    
    search_col1, search_col2 = st.columns(2)
    
    with search_col1:
        search_term = st.text_input(
            "Search presentations:",
            placeholder="Enter presentation name...",
            help="Search by presentation name"
        )
    
    with search_col2:
        format_filter = st.selectbox(
            "Filter by format:",
            ["All", "PowerPoint (.pptx)", "PDF (.pdf)"],
            help="Filter presentations by file format"
        )
    
    # Filter history items
    filtered_items = history_items
    
    if search_term:
        filtered_items = [item for item in filtered_items 
                         if search_term.lower() in item['name'].lower()]
    
    if format_filter != "All":
        filter_format = "pptx" if "PowerPoint" in format_filter else "pdf"
        filtered_items = [item for item in filtered_items if item['format'] == filter_format]
    
    # Display history items
    st.markdown(f"#### 📋 Recent Presentations ({len(filtered_items)} found)")
    
    for i, item in enumerate(filtered_items):
        with st.expander(
            f"📊 {item['name']} - {item['created_at'][:10]} "
            f"({item['format'].upper()})"
        ):
            # Item details
            detail_col1, detail_col2, detail_col3, detail_col4 = st.columns(4)
            
            with detail_col1:
                st.metric("Slides", item['slides'])
            with detail_col2:
                st.metric("Columns", item['columns']) 
            with detail_col3:
                st.metric("Story Mode", item['story_mode'])
            with detail_col4:
                st.metric("File Size", item['file_size'])
            
            # Additional details
            created_date = datetime.fromisoformat(item['created_at'].replace('Z', '+00:00'))
            st.write(f"**Created:** {created_date.strftime('%B %d, %Y at %I:%M %p')}")
            st.write(f"**Format:** {item['format'].upper()}")
            st.write(f"**ID:** {item['id']}")
            
            # Action buttons
            action_col1, action_col2, action_col3, action_col4 = st.columns(4)
            
            with action_col1:
                if st.button(
                    "📥 Download",
                    key=f"download_{item['id']}",
                    help=f"Download {item['name']}",
                    use_container_width=True
                ):
                    # Simulate download
                    sample_content = f"Sample content for {item['name']}"
                    st.download_button(
                        label=f"💾 Save {item['name']}.{item['format']}",
                        data=sample_content.encode(),
                        file_name=f"{item['name']}.{item['format']}",
                        mime="application/octet-stream"
                    )
                    st.success(f"✅ {item['name']} ready for download!")
            
            with action_col2:
                if st.button(
                    "✏️ Edit",
                    key=f"edit_{item['id']}",
                    help=f"Load {item['name']} for editing",
                    use_container_width=True
                ):
                    # Simulate loading for editing
                    load_presentation_for_editing(item)
                    st.success(f"✅ {item['name']} loaded for editing")
                    st.info("💡 Go to Upload tab to see loaded data")
            
            with action_col3:
                if st.button(
                    "📋 Duplicate",
                    key=f"duplicate_{item['id']}",
                    help=f"Create copy of {item['name']}",
                    use_container_width=True
                ):
                    st.info(f"📋 Created copy: {item['name']} (Copy)")
            
            with action_col4:
                if st.button(
                    "🗑️ Delete",
                    key=f"delete_{item['id']}",
                    help=f"Delete {item['name']} permanently",
                    use_container_width=True,
                    type="secondary"
                ):
                    if st.button(
                        f"⚠️ Confirm Delete",
                        key=f"confirm_delete_{item['id']}",
                        help="This action cannot be undone"
                    ):
                        st.warning(f"🗑️ {item['name']} deleted permanently")

def load_presentation_for_editing(item: Dict[str, Any]) -> None:
    """Load a presentation's data for editing"""
    # Simulate loading previous presentation data
    
    # Reset current session to editing mode
    st.session_state.selected_columns = ['revenue', 'region', 'product', 'customer_feedback']  # Simulated
    st.session_state.custom_filename = item['name']
    st.session_state.story_mode = item['story_mode'].lower()
    st.session_state.presentation_ready = False  # Reset to allow regeneration
    
    # Show success message
    st.balloons()

if __name__ == "__main__":
    main()
