"""
Theme Manager Component
Handles UI theme management and styling
"""
import streamlit as st
from typing import Dict, Any

class ThemeManager:
    """Manages UI themes and styling"""
    
    def __init__(self):
        self.themes = {
            'corporate': {
                'name': 'Corporate Black/Orange',
                'primary_color': '#FF6600',
                'secondary_color': '#000000',
                'background_color': '#FFFFFF',
                'text_color': '#1A1A1A',
                'accent_color': '#F5F5F5'
            },
            'modern': {
                'name': 'Modern Blue',
                'primary_color': '#007ACC',
                'secondary_color': '#2C3E50',
                'background_color': '#FFFFFF',
                'text_color': '#2C3E50',
                'accent_color': '#ECF0F1'
            },
            'minimal': {
                'name': 'Minimal Gray',
                'primary_color': '#4A4A4A',
                'secondary_color': '#2C3E50',
                'background_color': '#FFFFFF',
                'text_color': '#2C3E50',
                'accent_color': '#F8F9FA'
            }
        }
    
    def load_theme_css(self, theme_name: str = 'corporate') -> str:
        """Load CSS for specified theme"""
        
        theme = self.themes.get(theme_name, self.themes['corporate'])
        
        css = f"""
        <style>
        :root {{
            --primary-color: {theme['primary_color']};
            --secondary-color: {theme['secondary_color']};
            --background-color: {theme['background_color']};
            --text-color: {theme['text_color']};
            --accent-color: {theme['accent_color']};
        }}
        
        .main-header {{
            background: linear-gradient(135deg, var(--secondary-color) 0%, var(--primary-color) 100%);
            padding: 2rem;
            border-radius: 15px;
            color: white;
            text-align: center;
            margin-bottom: 2rem;
            box-shadow: 0 8px 25px rgba({self._hex_to_rgb(theme['primary_color'])}, 0.3);
        }}
        
        .stButton > button {{
            background: linear-gradient(135deg, var(--primary-color), {self._lighten_color(theme['primary_color'])}) !important;
            color: white !important;
            border: none !important;
            border-radius: 8px !important;
            font-weight: bold !important;
            transition: all 0.3s ease !important;
        }}
        
        .stButton > button:hover {{
            background: linear-gradient(135deg, {self._darken_color(theme['primary_color'])}, var(--primary-color)) !important;
            transform: translateY(-2px) !important;
        }}
        
        .metric-card {{
            background: linear-gradient(135deg, var(--primary-color), {self._lighten_color(theme['primary_color'])});
            color: white;
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            margin: 0.5rem 0;
            box-shadow: 0 4px 12px rgba({self._hex_to_rgb(theme['primary_color'])}, 0.3);
        }}
        
        .feature-card {{
            background: var(--background-color);
            border: 2px solid var(--accent-color);
            border-radius: 12px;
            padding: 1.5rem;
            margin: 1rem 0;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }}
        
        .feature-card:hover {{
            border-color: var(--primary-color);
            box-shadow: 0 8px 25px rgba({self._hex_to_rgb(theme['primary_color'])}, 0.2);
            transform: translateY(-2px);
        }}
        
        .pii-warning {{
            background: linear-gradient(90deg, #FFE6E6, #FFF0F0);
            border-left: 5px solid var(--primary-color);
            padding: 1.5rem;
            border-radius: 8px;
            margin: 1rem 0;
            box-shadow: 0 2px 8px rgba({self._hex_to_rgb(theme['primary_color'])}, 0.2);
        }}
        
        .success-message {{
            background: linear-gradient(90deg, #E6FFE6, #F0FFF0);
            border-left: 5px solid #28A745;
            padding: 1.5rem;
            border-radius: 8px;
            margin: 1rem 0;
        }}
        
        .stFileUploader > div > div {{
            border: 2px dashed var(--primary-color) !important;
            border-radius: 12px !important;
            background-color: {self._lighten_color(theme['primary_color'], 0.95)} !important;
        }}
        
        .stProgress > div > div > div {{
            background-color: var(--primary-color) !important;
        }}
        
        .stCheckbox > label > div[data-testid="stCheckbox"] > div {{
            background-color: var(--primary-color) !important;
        }}
        </style>
        """
        
        return css
    
    def render_theme_selector(self) -> str:
        """Render theme selection interface"""
        
        st.markdown("#### 🎨 Theme Selection")
        
        theme_options = [(key, theme['name']) for key, theme in self.themes.items()]
        
        selected_theme_key = st.selectbox(
            "Choose UI Theme:",
            options=[option[0] for option in theme_options],
            format_func=lambda x: next(name for key, name in theme_options if key == x),
            help="Select the visual theme for the application"
        )
        
        # Show theme preview
        if selected_theme_key:
            theme = self.themes[selected_theme_key]
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.color_picker(
                    "Primary Color", 
                    theme['primary_color'], 
                    disabled=True,
                    help="Main theme color"
                )
            
            with col2:
                st.color_picker(
                    "Secondary Color", 
                    theme['secondary_color'], 
                    disabled=True,
                    help="Secondary theme color"
                )
            
            with col3:
                st.color_picker(
                    "Accent Color", 
                    theme['accent_color'], 
                    disabled=True,
                    help="Accent theme color"
                )
        
        return selected_theme_key
    
    def get_theme_colors(self, theme_name: str = 'corporate') -> Dict[str, str]:
        """Get color palette for specified theme"""
        return self.themes.get(theme_name, self.themes['corporate'])
    
    def _hex_to_rgb(self, hex_color: str) -> str:
        """Convert hex color to RGB string"""
        hex_color = hex_color.lstrip('#')
        
        try:
            rgb = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
            return f"{rgb[0]}, {rgb[1]}, {rgb[2]}"
        except:
            return "255, 102, 0"  # Default orange
    
    def _lighten_color(self, hex_color: str, factor: float = 0.8) -> str:
        """Lighten a hex color by a factor"""
        hex_color = hex_color.lstrip('#')
        
        try:
            rgb = [int(hex_color[i:i+2], 16) for i in (0, 2, 4)]
            rgb = [int(min(255, c + (255 - c) * (1 - factor))) for c in rgb]
            return f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}"
        except:
            return "#FF8533"  # Default light orange
    
    def _darken_color(self, hex_color: str, factor: float = 0.8) -> str:
        """Darken a hex color by a factor"""
        hex_color = hex_color.lstrip('#')
        
        try:
            rgb = [int(hex_color[i:i+2], 16) for i in (0, 2, 4)]
            rgb = [int(c * factor) for c in rgb]
            return f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}"
        except:
            return "#E55A00"  # Default dark orange
