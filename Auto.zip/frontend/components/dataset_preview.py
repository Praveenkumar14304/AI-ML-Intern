"""
Dataset Preview Component with Dynamic Toggle
Handles the preview functionality with column selection toggle
"""
import streamlit as st
import pandas as pd
from typing import List

class DatasetPreview:
    """Handles dataset preview with dynamic toggle functionality"""
    
    def render_dataset_preview_with_toggle(
        self, 
        df: pd.DataFrame, 
        selected_columns: List[str], 
        show_selected_only: bool
    ) -> bool:
        """Render dataset preview with toggle functionality"""
        
        st.markdown("### 📋 Dataset Preview")
        
        # Preview controls
        preview_col1, preview_col2, preview_col3 = st.columns([1, 1, 2])
        
        with preview_col1:
            show_selected_only = st.toggle(
                "📊 Show selected only",
                value=show_selected_only,
                help="Toggle between all columns and selected columns view"
            )
        
        with preview_col2:
            preview_rows = st.selectbox(
                "Rows:",
                [5, 10, 20, 50],
                index=1
            )
        
        with preview_col3:
            if show_selected_only:
                if selected_columns:
                    st.info(f"Showing {len(selected_columns)} selected columns")
                else:
                    st.warning("No columns selected")
                    return show_selected_only
            else:
                st.info(f"Showing all {len(df.columns)} columns")
        
        # Generate preview dataframe
        if show_selected_only and selected_columns:
            preview_df = df[selected_columns].head(preview_rows)
        else:
            preview_df = df.head(preview_rows)
        
        # Enhanced dataframe display
        st.dataframe(
            preview_df,
            use_container_width=True,
            hide_index=False,
            height=min(400, (len(preview_df) + 1) * 35 + 50)
        )
        
        # Quick analysis preview
        if selected_columns:
            self.render_quick_analysis_preview(df, selected_columns)
        
        return show_selected_only
    
    def render_quick_analysis_preview(self, df: pd.DataFrame, selected_columns: List[str]) -> None:
        """Display quick analysis insights for selected columns"""
        
        st.markdown("#### 📈 Quick Analysis Preview")
        
        # Categorize columns by type
        numeric_cols = []
        categorical_cols = []
        text_cols = []
        
        for col in selected_columns:
            if pd.api.types.is_numeric_dtype(df[col]):
                numeric_cols.append(col)
            elif df[col].nunique() < len(df) * 0.1:
                categorical_cols.append(col)
            else:
                text_cols.append(col)
        
        # Display insights by type
        insight_col1, insight_col2 = st.columns(2)
        
        with insight_col1:
            if numeric_cols:
                st.markdown("**🔢 Numeric Insights:**")
                for col in numeric_cols[:3]:
                    mean_val = df[col].mean()
                    std_val = df[col].std()
                    st.write(f"• **{col}**: μ={mean_val:.2f}, σ={std_val:.2f}")
        
        with insight_col2:
            if categorical_cols:
                st.markdown("**🏷️ Categorical Insights:**")
                for col in categorical_cols[:3]:
                    top_value = df[col].value_counts().index[0]
                    top_pct = (df[col].value_counts().iloc[0] / len(df)) * 100
                    st.write(f"• **{col}**: '{top_value}' ({top_pct:.1f}%)")
            
            if text_cols:
                st.markdown("**📝 Text Insights:**")
                for col in text_cols[:2]:
                    avg_length = df[col].astype(str).str.len().mean()
                    st.write(f"• **{col}**: ~{avg_length:.0f} chars avg")
    
    def render_column_selection_interface(
        self, 
        df: pd.DataFrame, 
        pii_columns: List[Dict], 
        auto_remove_pii: bool
    ) -> List[str]:
        """Render enhanced column selection interface"""
        
        st.markdown("### 🎯 Column Selection")
        
        # Get available columns
        pii_column_names = [col['name'] for col in pii_columns] if auto_remove_pii else []
        available_columns = [col for col in df.columns if col not in pii_column_names]
        
        if not available_columns:
            st.warning("⚠️ No columns available for selection")
            return []
        
        # Selection controls
        control_col1, control_col2, control_col3 = st.columns([1, 1, 2])
        
        with control_col1:
            if st.button("✅ Select All"):
                return available_columns
        
        with control_col2:
            if st.button("❌ Clear All"):
                return []
        
        with control_col3:
            st.info(f"Available: {len(available_columns)} columns")
        
        # Column selection with enhanced info
        selected_columns = st.multiselect(
            "Choose columns for analysis:",
            available_columns,
            default=available_columns[:5] if len(available_columns) >= 5 else available_columns,
            help="Select the columns you want to include in your analysis"
        )
        
        return selected_columns
    
    def get_column_stats(self, df: pd.DataFrame, column: str) -> Dict[str, Any]:
        """Get comprehensive statistics for a column"""
        
        col_data = df[column]
        
        stats = {
            'name': column,
            'type': self.detect_column_type(col_data),
            'null_count': int(col_data.isnull().sum()),
            'null_percentage': float((col_data.isnull().sum() / len(col_data)) * 100),
            'unique_count': int(col_data.nunique()),
            'duplicate_count': int(len(col_data) - col_data.nunique()),
        }
        
        # Add example value
        if not col_data.dropna().empty:
            stats['example_value'] = str(col_data.dropna().iloc[0])
        else:
            stats['example_value'] = "N/A"
        
        # Type-specific statistics
        if stats['type'] == 'numeric':
            stats.update({
                'mean': float(col_data.mean()),
                'median': float(col_data.median()),
                'std': float(col_data.std()),
                'min': float(col_data.min()),
                'max': float(col_data.max())
            })
        
        elif stats['type'] == 'categorical':
            value_counts = col_data.value_counts()
            stats.update({
                'top_value': str(value_counts.index[0]) if not value_counts.empty else "N/A",
                'top_count': int(value_counts.iloc[0]) if not value_counts.empty else 0,
                'categories': min(10, len(value_counts))
            })
        
        return stats
    
    def detect_column_type(self, series: pd.Series) -> str:
        """Detect column data type with enhanced logic"""
        
        if pd.api.types.is_numeric_dtype(series):
            # Check if it's actually categorical despite being numeric
            unique_ratio = series.nunique() / len(series)
            if unique_ratio < 0.05 and series.nunique() < 20:
                return 'categorical'
            return 'numeric'
        
        elif pd.api.types.is_datetime64_any_dtype(series):
            return 'datetime'
        
        else:
            # Check average string length to distinguish text from categorical
            avg_length = series.astype(str).str.len().mean()
            if avg_length > 15:
                return 'text'
            else:
                return 'categorical'
