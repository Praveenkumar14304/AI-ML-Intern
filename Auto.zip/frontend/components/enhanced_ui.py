"""
Enhanced UI Components for Professional Design
"""
import streamlit as st
import pandas as pd
from typing import Dict, List, Any

def render_metric_cards(metrics: List[Dict[str, Any]]):
    """Render metric cards in a grid"""
    cols = st.columns(len(metrics))
    
    for i, metric in enumerate(metrics):
        with cols[i]:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{metric['value']}</div>
                <div class="metric-label">{metric['label']}</div>
                <div class="metric-change {metric.get('change_type', '')}">{metric.get('change', '')}</div>
            </div>
            """, unsafe_allow_html=True)

def render_progress_indicator(current_step: int, total_steps: int, step_names: List[str]):
    """Render progress indicator"""
    progress_html = '<div class="progress-indicator">'
    
    for i, step_name in enumerate(step_names):
        status = 'completed' if i < current_step else 'active' if i == current_step else 'pending'
        progress_html += f"""
        <div class="progress-step {status}">
            <div class="progress-step-number">{i + 1}</div>
            <div class="progress-step-name">{step_name}</div>
        </div>
        """
        
        if i < len(step_names) - 1:
            progress_html += f'<div class="progress-connector {status}"></div>'
    
    progress_html += '</div>'
    st.markdown(progress_html, unsafe_allow_html=True)

def render_data_quality_indicator(quality_score: float):
    """Render data quality indicator"""
    if quality_score >= 90:
        color = "#28a745"
        label = "Excellent"
    elif quality_score >= 80:
        color = "#ffc107"
        label = "Good"
    elif quality_score >= 70:
        color = "#fd7e14"
        label = "Fair"
    else:
        color = "#dc3545"
        label = "Poor"
    
    st.markdown(f"""
    <div class="quality-indicator">
        <div class="quality-score" style="color: {color}">
            <div class="quality-value">{quality_score:.1f}%</div>
            <div class="quality-label">{label}</div>
        </div>
        <div class="quality-bar">
            <div class="quality-fill" style="width: {quality_score}%; background: {color};"></div>
        </div>
    </div>
    """, unsafe_allow_html=True)

def render_column_type_badge(column_type: str):
    """Render column type badge"""
    type_colors = {
        'numeric': '#28a745',
        'categorical': '#fd7e14', 
        'datetime': '#6f42c1',
        'text': '#20c997',
        'boolean': '#17a2b8'
    }
    
    color = type_colors.get(column_type, '#6c757d')
    
    return f"""
    <span class="column-type-badge" style="background: {color};">
        {column_type}
    </span>
    """

def render_interactive_table(df: pd.DataFrame, max_rows: int = 10):
    """Render interactive data table"""
    table_html = """
    <div class="interactive-table">
        <div class="table-controls">
            <div class="table-search">
                <input type="text" placeholder="Search..." class="search-input">
            </div>
            <div class="table-pagination">
                <button class="pagination-btn">← Previous</button>
                <span class="pagination-info">Page 1 of 10</span>
                <button class="pagination-btn">Next →</button>
            </div>
        </div>
        <div class="table-wrapper">
    """
    
    # Add table content
    table_html += df.head(max_rows).to_html(
        classes="data-table",
        escape=False,
        index=False
    )
    
    table_html += """
        </div>
    </div>
    """
    
    st.markdown(table_html, unsafe_allow_html=True)

def render_loading_spinner(message: str = "Processing..."):
    """Render loading spinner"""
    st.markdown(f"""
    <div class="loading-spinner">
        <div class="spinner"></div>
        <div class="loading-message">{message}</div>
    </div>
    """, unsafe_allow_html=True)

def render_notification(message: str, type: str = "info", dismissible: bool = True):
    """Render notification toast"""
    icons = {
        'success': '✅',
        'error': '❌', 
        'warning': '⚠️',
        'info': 'ℹ️'
    }
    
    icon = icons.get(type, 'ℹ️')
    dismiss_btn = '<button class="notification-dismiss">×</button>' if dismissible else ''
    
    st.markdown(f"""
    <div class="notification notification-{type}">
        <div class="notification-content">
            <span class="notification-icon">{icon}</span>
            <span class="notification-message">{message}</span>
        </div>
        {dismiss_btn}
    </div>
    """, unsafe_allow_html=True)
