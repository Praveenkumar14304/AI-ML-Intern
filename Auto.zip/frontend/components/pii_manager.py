"""
PII Manager Component for Streamlit
Handles PII detection display and override functionality
"""
import streamlit as st
import pandas as pd
from typing import List, Dict, Any

class PIIManager:
    """Handles PII detection and management in the UI"""
    
    def __init__(self):
        self.pii_keywords = ['email', 'phone', 'name', 'id', 'ssn', 'address']
    
    def render_pii_section(self, pii_results: Dict[str, Any], auto_remove_pii: bool) -> None:
        """Render PII management section with override options"""
        
        st.markdown("### 🛡️ PII Protection & Management")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.toggle(
                "🛡️ Auto-remove PII columns",
                value=auto_remove_pii,
                help="Automatically detect and remove personally identifiable information"
            )
        
        with col2:
            if pii_results['removed_columns']:
                st.error(f"⚠️ {pii_results['removed_count']} PII columns detected")
            else:
                st.success("✅ No PII detected")
        
        # Show PII details with override options
        if pii_results['removed_columns'] and auto_remove_pii:
            self.render_pii_details(pii_results['removed_columns'])
    
    def render_pii_details(self, removed_columns: List[Dict[str, Any]]) -> str:
        """Render detailed PII information with override options"""
        
        st.markdown("#### 🚨 Auto-Removed Columns")
        
        for i, col_info in enumerate(removed_columns):
            with st.expander(
                f"🔒 {col_info['name']} - {col_info.get('reason', 'PII detected')}"
            ):
                detail_col1, detail_col2, detail_col3 = st.columns([2, 2, 1])
                
                with detail_col1:
                    st.write(f"**Method:** {col_info.get('method', 'standard')}")
                    st.write(f"**Confidence:** {col_info.get('confidence', 0.8):.0%}")
                
                with detail_col2:
                    st.write(f"**Reason:** {col_info.get('reason', 'PII pattern detected')}")
                    st.write(f"**Override:** {'Yes' if col_info.get('can_override', True) else 'No'}")
                
                with detail_col3:
                    if st.button(
                        "🔓 Restore",
                        key=f"restore_{i}",
                        help=f"Restore {col_info['name']} for analysis"
                    ):
                        st.success(f"✅ {col_info['name']} restored")
                        return col_info['name']  # Return restored column name
        
        return None
    
    def detect_pii_columns(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Enhanced PII detection for demo purposes"""
        
        pii_columns = []
        
        for col in df.columns:
            col_lower = col.lower()
            
            # Method 1: Keyword detection
            for keyword in self.pii_keywords:
                if keyword in col_lower:
                    pii_columns.append({
                        'name': col,
                        'reason': f'Contains PII keyword: {keyword}',
                        'method': 'keyword_detection',
                        'confidence': 0.9,
                        'can_override': True,
                        'pii_type': keyword
                    })
                    break
            
            # Method 2: Content-based detection
            if col not in [pc['name'] for pc in pii_columns]:
                sample_values = df[col].dropna().head(10).astype(str)
                
                # Email pattern
                if any('@' in str(val) and '.' in str(val) for val in sample_values):
                    pii_columns.append({
                        'name': col,
                        'reason': 'Email pattern detected in values',
                        'method': 'content_pattern',
                        'confidence': 0.95,
                        'can_override': True,
                        'pii_type': 'email'
                    })
                
                # Phone pattern
                elif any(len(str(val).replace('-', '').replace(' ', '')) >= 10 
                        and any(c.isdigit() for c in str(val)) for val in sample_values):
                    pii_columns.append({
                        'name': col,
                        'reason': 'Phone pattern detected in values',
                        'method': 'content_pattern',
                        'confidence': 0.85,
                        'can_override': True,
                        'pii_type': 'phone'
                    })
        
        return {
            'removed_columns': pii_columns,
            'removed_count': len(pii_columns),
            'detection_methods': list(set([col['method'] for col in pii_columns]))
        }
    
    def get_pii_summary(self, pii_results: Dict[str, Any]) -> str:
        """Generate summary of PII detection results"""
        
        if pii_results['removed_count'] == 0:
            return "✅ No PII detected - dataset appears privacy-safe"
        
        summary = f"⚠️ {pii_results['removed_count']} PII columns detected:\n"
        
        # Group by PII type
        pii_types = {}
        for col in pii_results['removed_columns']:
            pii_type = col.get('pii_type', 'unknown')
            if pii_type not in pii_types:
                pii_types[pii_type] = []
            pii_types[pii_type].append(col['name'])
        
        for pii_type, columns in pii_types.items():
            summary += f"• {pii_type.title()}: {', '.join(columns)}\n"
        
        return summary.strip()
