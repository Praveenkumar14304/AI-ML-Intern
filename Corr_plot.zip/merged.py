import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
import json
import csv
from scipy.stats import entropy, chi2_contingency

# ========== FEATURE SELECTION FUNCTIONS (from nachi.py) ==========
def dataset_feature_analysis(df, num_corr_threshold=0.7, chi2_p_threshold=0.05):
    numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns.tolist()
    categorical_cols = df.select_dtypes(include=['object', 'category', 'bool']).columns.tolist()
    datetime_cols = df.select_dtypes(include=['datetime64[ns]', 'datetime64']).columns.tolist()

    categorical_cols = [c for c in categorical_cols if df[c].nunique() < 50]
    feature_scores = {}
    
    # Store detailed correlation information
    correlation_details = {
        "numerical": {},
        "categorical": {},
        "datetime": {}
    }

    # --- Numerical correlation ---
    if len(numerical_cols) > 1:
        pearson_corr = df[numerical_cols].corr(method="pearson").abs()
        num_scores = pearson_corr.max().to_dict()
        min_s, max_s = min(num_scores.values()), max(num_scores.values())
        
        for col, score in num_scores.items():
            feature_scores[col] = (score - min_s) / (max_s - min_s) if max_s > min_s else 0.0
            
            # Store correlation details for numerical features
            corr_series = pearson_corr[col].sort_values(ascending=False)
            top_correlations = []
            for other_col, corr_value in corr_series.items():
                if other_col != col and corr_value > 0.1:  # Only include meaningful correlations
                    top_correlations.append({
                        "feature": other_col,
                        "correlation": float(corr_value),
                        "type": "numerical"
                    })
            
            correlation_details["numerical"][col] = {
                "score": float(feature_scores[col]),
                "top_correlations": top_correlations[:5]  # Top 5 correlations
            }

    # --- Categorical association ---
    if len(categorical_cols) > 1:
        cat_strength = {col: 0 for col in categorical_cols}
        cat_correlations = {col: [] for col in categorical_cols}
        
        for i, col1 in enumerate(categorical_cols):
            for col2 in categorical_cols[i + 1:]:
                table = pd.crosstab(df[col1], df[col2])
                if not table.empty and table.shape[0] > 1 and table.shape[1] > 1:
                    try:
                        _, p, _, _ = chi2_contingency(table)
                        score = 1 - p
                        cat_strength[col1] = max(cat_strength[col1], score)
                        cat_strength[col2] = max(cat_strength[col2], score)
                        
                        # Store correlation details
                        if score > 0.1:  # Only store meaningful associations
                            cat_correlations[col1].append({
                                "feature": col2,
                                "association": float(score),
                                "type": "categorical"
                            })
                            cat_correlations[col2].append({
                                "feature": col1,
                                "association": float(score),
                                "type": "categorical"
                            })
                    except ValueError:
                        pass
        
        min_s, max_s = min(cat_strength.values()), max(cat_strength.values())
        for col, score in cat_strength.items():
            feature_scores[col] = (score - min_s) / (max_s - min_s) if max_s > min_s else 0.0
            
            # Store correlation details for categorical features
            sorted_correlations = sorted(cat_correlations[col], key=lambda x: x["association"], reverse=True)
            correlation_details["categorical"][col] = {
                "score": float(feature_scores[col]),
                "top_correlations": sorted_correlations[:5]  # Top 5 associations
            }

    # --- Datetime variability ---
    if len(datetime_cols) > 0:
        dt_scores = {}
        for col in datetime_cols:
            df[col] = pd.to_datetime(df[col], errors='coerce')
            year_var = df[col].dt.year.var() if hasattr(df[col].dt, "year") else 0
            month_var = df[col].dt.month.var() if hasattr(df[col].dt, "month") else 0
            day_var = df[col].dt.day.var() if hasattr(df[col].dt, "day") else 0
            dt_scores[col] = year_var + month_var + day_var
            
            # For datetime features, we'll check correlation with numerical features
            dt_correlations = []
            for num_col in numerical_cols:
                if num_col in df.columns and col in df.columns:
                    try:
                        # Convert datetime to ordinal for correlation calculation
                        dt_ordinal = df[col].map(pd.Timestamp.toordinal)
                        corr_value = df[num_col].corr(dt_ordinal)
                        if not pd.isna(corr_value) and abs(corr_value) > 0.1:
                            dt_correlations.append({
                                "feature": num_col,
                                "correlation": float(abs(corr_value)),
                                "type": "numerical"
                            })
                    except:
                        pass
        
        min_s, max_s = min(dt_scores.values()), max(dt_scores.values())
        for col, score in dt_scores.items():
            feature_scores[col] = (score - min_s) / (max_s - min_s) if max_s > min_s else 0.0
            
            # Store correlation details for datetime features
            sorted_correlations = sorted(dt_correlations, key=lambda x: x["correlation"], reverse=True)
            correlation_details["datetime"][col] = {
                "score": float(feature_scores[col]),
                "top_correlations": sorted_correlations[:5]  # Top 5 correlations
            }

    col_types = {col: "numerical" for col in numerical_cols}
    col_types.update({col: "categorical" for col in categorical_cols})
    col_types.update({col: "datetime" for col in datetime_cols})

    return {"feature_scores": feature_scores, "col_types": col_types, "correlation_details": correlation_details}


def get_top_features(df, top_num=2, top_cat=2, top_dt=1):
    report = dataset_feature_analysis(df)
    feature_scores = report["feature_scores"]
    col_types = report["col_types"]
    correlation_details = report["correlation_details"]

    overall_ranked = sorted(feature_scores.items(), key=lambda item: item[1], reverse=True)

    top_numerical = [col for col, _ in overall_ranked if col_types.get(col) == "numerical"][:top_num]
    top_categorical = [col for col, _ in overall_ranked if col_types.get(col) == "categorical"][:top_cat]
    top_datetime = [col for col, _ in overall_ranked if col_types.get(col) == "datetime"][:top_dt]

    # Create JSON output with top features and their correlations
    top_features_json = {
        "top_numerical_features": [
            {
                "feature": col,
                "score": float(feature_scores[col]),
                "correlations": correlation_details["numerical"].get(col, {}).get("top_correlations", [])
            } for col in top_numerical
        ],
        "top_categorical_features": [
            {
                "feature": col,
                "score": float(feature_scores[col]),
                "associations": correlation_details["categorical"].get(col, {}).get("top_correlations", [])
            } for col in top_categorical
        ],
        "top_datetime_features": [
            {
                "feature": col,
                "score": float(feature_scores[col]),
                "correlations": correlation_details["datetime"].get(col, {}).get("top_correlations", [])
            } for col in top_datetime
        ]
    }
    
    return top_numerical, top_categorical, top_datetime, top_features_json


def load_dataset(path):
    with open(path, 'r') as f:
        first_line = f.readline()
        dialect = csv.Sniffer().sniff(first_line, delimiters=[",", ";", "\t", "|", "/"])
        sep = dialect.delimiter
    return pd.read_csv(path, sep=sep)


# ========== FEATURE PROCESSING FUNCTIONS ==========
def process_numerical(df, col):
    s = df[col].dropna()

    stats = {
        "column_name": col,
        "mean": float(s.mean()),
        "median": float(s.median()),
        "mode": float(s.mode().iloc[0]) if not s.mode().empty else None,
        "std": float(s.std()),
        "min": float(s.min()),
        "max": float(s.max()),
        "skewness": float(s.skew()),
        "kurtosis": float(s.kurt()),
        "missing_values": int(df[col].isna().sum()),
        "unique_values": int(s.nunique())
    }

    # Conditional Plot
    plot_path = f"plots/{col}.png"
    plt.figure(figsize=(6, 4))

    if stats["unique_values"] > 20 and abs(stats["skewness"]) < 2:
        sns.histplot(s, kde=True, bins=30)
        plt.title(f"Histogram of {col}")
    elif stats["unique_values"] > 20 and abs(stats["skewness"]) >= 2:
        sns.boxplot(x=s)
        plt.title(f"Boxplot of {col} (Skewed)")
    else:
        s.value_counts().plot(kind="bar")
        plt.title(f"Bar Chart of {col}")

    plt.tight_layout()
    plt.savefig(plot_path)
    plt.close()

    stats["plot_path"] = plot_path
    return stats


def process_categorical(df, col):
    s = df[col].dropna()
    value_counts = s.value_counts(dropna=False)
    percentages = value_counts / value_counts.sum() * 100

    stats = {
        "column_name": col,
        "unique_values": int(s.nunique(dropna=False)),
        "most_frequent": str(value_counts.idxmax()) if not value_counts.empty else None,
        "most_frequent_count": int(value_counts.max()) if not value_counts.empty else None,
        "least_frequent": str(value_counts.idxmin()) if not value_counts.empty else None,
        "least_frequent_count": int(value_counts.min()) if not value_counts.empty else None,
        "missing_values": int(df[col].isna().sum()),
        "entropy": float(entropy(value_counts)) if not value_counts.empty else None
    }

    # If unique values < 10, log counts
    if stats["unique_values"] < 10:
        stats["value_counts"] = value_counts.to_dict()

    # Conditional Plot
    plot_path = f"plots/{col}.png"
    plt.figure(figsize=(6, 4))

    if stats["unique_values"] <= 5 and percentages.max() < 80:
        value_counts.plot(kind="pie", autopct="%1.1f%%")
        plt.ylabel("")
        plt.title(f"Pie Chart of {col}")
    else:
        value_counts.head(10).plot(kind="bar")
        plt.title(f"Bar Chart of {col} (Top 10)")
        plt.ylabel("Count")

    plt.tight_layout()
    plt.savefig(plot_path)
    plt.close()

    stats["plot_path"] = plot_path
    return stats


def process_datetime(df, col):
    df[col] = pd.to_datetime(df[col], errors="coerce")
    series = df[col].dropna().sort_values()

    stats = {"column_name": col, "missing_values": int(df[col].isna().sum())}

    if series.empty:
        stats.update({"error": "No valid dates"})
        return stats

    gaps = series.diff().dropna().dt.days

    stats.update({
        "min_date": str(series.min().date()),
        "max_date": str(series.max().date()),
        "time_span_days": int((series.max() - series.min()).days),
        "most_frequent_date": str(series.value_counts().idxmax().date()),
        "repeated_dates": int((series.value_counts() > 1).sum()),
        "avg_gap_days": float(gaps.mean()) if not gaps.empty else None,
        "median_gap_days": float(gaps.median()) if not gaps.empty else None,
    })

    plot_path = f"plots/{col}.png"
    plt.figure(figsize=(8, 4))

    if stats["time_span_days"] > 365:
        series.groupby(series.dt.to_period("Y")).count().plot()
        plt.title(f"Yearly Trend of {col}")
    else:
        series.value_counts().sort_index().plot()
        plt.title(f"Daily Trend of {col}")

    plt.xlabel("Date")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(plot_path)
    plt.close()

    stats["plot_path"] = plot_path
    return stats


# ========== MAIN PROCESSING FUNCTION ==========
def generate_insights(df, num_cols, cat_cols, datetime_cols, print_stats=False, save_json=True, save_dir="feature_json"):
    insights = {"numerical": {}, "categorical": {}, "datetime": {}}

    for col in num_cols:
        insights["numerical"][col] = process_numerical(df, col)
        if print_stats:
            print(json.dumps(insights["numerical"][col], indent=4))

    for col in cat_cols:
        insights["categorical"][col] = process_categorical(df, col)
        if print_stats:
            print(json.dumps(insights["categorical"][col], indent=4))

    for col in datetime_cols:
        insights["datetime"][col] = process_datetime(df, col)
        if print_stats:
            print(json.dumps(insights["datetime"][col], indent=4))

    if save_json:
        os.makedirs(save_dir, exist_ok=True)

        if insights["numerical"]:
            with open(os.path.join(save_dir, "numerical_insights.json"), "w") as f:
                json.dump(insights["numerical"], f, indent=4)

        if insights["categorical"]:
            with open(os.path.join(save_dir, "categorical_insights.json"), "w") as f:
                json.dump(insights["categorical"], f, indent=4)

        if insights["datetime"]:
            with open(os.path.join(save_dir, "datetime_insights.json"), "w") as f:
                json.dump(insights["datetime"], f, indent=4)

    return insights


# ========== MAIN EXECUTION ==========
if __name__ == "__main__":
    # Load dataset
    df = load_dataset("Viral_Social_Media_Trends.csv")
    
    # Ensure output folders exist
    os.makedirs("plots", exist_ok=True)
    os.makedirs("feature_json", exist_ok=True)
    os.makedirs("top_features", exist_ok=True)
    
    # Step 1: Feature selection with correlation details
    print("Performing feature selection with correlation analysis...")
    num_cols, cat_cols, datetime_cols, top_features_json = get_top_features(df)
    
    print("Top Numerical Features:", num_cols)
    print("Top Categorical Features:", cat_cols)
    print("Top Datetime Features:", datetime_cols)
    
    # Save top features with correlation details to JSON
    with open("top_features/top_features_with_correlations.json", "w") as f:
        json.dump(top_features_json, f, indent=4)
    
    print("\n📊 Top features with correlation details saved to: top_features/top_features_with_correlations.json")
    
    # Step 2: Generate insights for selected features
    print("\nGenerating insights for selected features...")
    all_insights = generate_insights(df, num_cols, cat_cols, datetime_cols,
                                     print_stats=True, save_json=True)

    print("\n✅ Feature selection completed!")
    print("✅ Top features with correlations saved!")
    print("✅ Conditional plots + JSONs created.")
    print(f"📊 Plots saved in: plots/")
    print(f"📁 JSON insights saved in: feature_json/")
    print(f"⭐ Top features saved in: top_features/")