# === step1_feature_selection.py ===
import pandas as pd
import csv
import json
from scipy.stats import chi2_contingency
import os

def dataset_feature_analysis(df, num_corr_threshold=0.7, chi2_p_threshold=0.05):
    numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns.tolist()
    categorical_cols = df.select_dtypes(include=['object', 'category', 'bool']).columns.tolist()
    datetime_cols = df.select_dtypes(include=['datetime64[ns]', 'datetime64']).columns.tolist()

    categorical_cols = [c for c in categorical_cols if df[c].nunique() < 50]
    feature_scores = {}

    # --- Numerical correlation ---
    if len(numerical_cols) > 1:
        pearson_corr = df[numerical_cols].corr(method="pearson").abs()
        num_scores = pearson_corr.max().to_dict()
        min_s, max_s = min(num_scores.values()), max(num_scores.values())
        for col, score in num_scores.items():
            feature_scores[col] = (score - min_s) / (max_s - min_s) if max_s > min_s else 0.0

    # --- Categorical association ---
    if len(categorical_cols) > 1:
        cat_strength = {col: 0 for col in categorical_cols}
        for i, col1 in enumerate(categorical_cols):
            for col2 in categorical_cols[i + 1:]:
                table = pd.crosstab(df[col1], df[col2])
                if not table.empty and table.shape[0] > 1 and table.shape[1] > 1:
                    try:
                        _, p, _, _ = chi2_contingency(table)
                        score = 1 - p
                        cat_strength[col1] = max(cat_strength[col1], score)
                        cat_strength[col2] = max(cat_strength[col2], score)
                    except ValueError:
                        pass
        min_s, max_s = min(cat_strength.values()), max(cat_strength.values())
        for col, score in cat_strength.items():
            feature_scores[col] = (score - min_s) / (max_s - min_s) if max_s > min_s else 0.0

    # --- Datetime variability ---
    if len(datetime_cols) > 0:
        dt_scores = {}
        for col in datetime_cols:
            df[col] = pd.to_datetime(df[col], errors='coerce')
            year_var = df[col].dt.year.var() if hasattr(df[col].dt, "year") else 0
            month_var = df[col].dt.month.var() if hasattr(df[col].dt, "month") else 0
            day_var = df[col].dt.day.var() if hasattr(df[col].dt, "day") else 0
            dt_scores[col] = year_var + month_var + day_var
        min_s, max_s = min(dt_scores.values()), max(dt_scores.values())
        for col, score in dt_scores.items():
            feature_scores[col] = (score - min_s) / (max_s - min_s) if max_s > min_s else 0.0

    col_types = {col: "numerical" for col in numerical_cols}
    col_types.update({col: "categorical" for col in categorical_cols})
    col_types.update({col: "datetime" for col in datetime_cols})

    return {"feature_scores": feature_scores, "col_types": col_types}


def get_top_features(df, top_num=2, top_cat=2, top_dt=1):
    report = dataset_feature_analysis(df)
    feature_scores = report["feature_scores"]
    col_types = report["col_types"]

    overall_ranked = sorted(feature_scores.items(), key=lambda item: item[1], reverse=True)

    top_numerical = [col for col, _ in overall_ranked if col_types.get(col) == "numerical"][:top_num]
    top_categorical = [col for col, _ in overall_ranked if col_types.get(col) == "categorical"][:top_cat]
    top_datetime = [col for col, _ in overall_ranked if col_types.get(col) == "datetime"][:top_dt]

    return top_numerical, top_categorical, top_datetime


def load_dataset(path):
    with open(path, 'r') as f:
        first_line = f.readline()
        dialect = csv.Sniffer().sniff(first_line, delimiters=[",", ";", "\t", "|", "/"])
        sep = dialect.delimiter
    return pd.read_csv(path, sep=sep)


if __name__ == "__main__":
    df = load_dataset("Viral_Social_Media_Trends.csv")
    num_cols, cat_cols, dt_cols = get_top_features(df)
    
    print("Top Numerical Features:", num_cols)
    print("Top Categorical Features:", cat_cols)
    print("Top Datetime Features:", dt_cols)
    
    # Create JSON output with top features
    top_features_json = {
        "top_numerical_features": num_cols,
        "top_categorical_features": cat_cols,
        "top_datetime_features": dt_cols
    }
    
    # Ensure output directory exists
    os.makedirs("feature_selection_output", exist_ok=True)
    
    # Save to JSON file
    with open("feature_selection_output/top_features.json", "w") as f:
        json.dump(top_features_json, f, indent=4)
    
    print("\n✅ Top features saved to: feature_selection_output/top_features.json")