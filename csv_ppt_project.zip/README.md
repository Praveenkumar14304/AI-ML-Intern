
# CSV to PPT Converter

This project provides a minimal end-to-end pipeline:
1. **FastAPI backend** for CSV upload, simple analysis, plot generation, and PowerPoint creation.
2. **Streamlit frontend** for user interaction.

## Setup

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scriptsctivate
pip install -r requirements.txt
```

## Running

Open two terminals:

```bash
# Terminal 1: start backend
uvicorn backend.app:app --reload --port 8000

# Terminal 2: start frontend
streamlit run frontend/streamlit_app.py --server.port 8501
```

Navigate to `http://localhost:8501` in your browser.

Upload a CSV, preview it, choose columns, generate PPT, and download.
