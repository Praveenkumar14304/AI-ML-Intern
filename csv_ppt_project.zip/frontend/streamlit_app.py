
import streamlit as st
import requests, json, os
import pandas as pd

BACKEND = 'http://localhost:8000'

st.title('CSV to PPT Converter')

file = st.file_uploader('Upload CSV')
if file:
    res = requests.post(f'{BACKEND}/upload/', files={'file': (file.name, file.getvalue(), 'text/csv')})
    if res.ok:
        data = res.json()
        st.write('Preview', pd.DataFrame(data['preview']))
        cols = st.multiselect('Select columns', data['columns'], default=data['columns'])
        if st.button('Generate PPT'):
            proc = requests.post(f'{BACKEND}/process/', data={'selected_cols': json.dumps(cols), 'filename': data['filename']})
            if proc.ok:
                out = proc.json()
                ppt_name = out['ppt']
                dl_link = f"{BACKEND}/download/{ppt_name}"
                st.success('PPT ready!')
                st.markdown(f"[Download PPT]({dl_link})")
