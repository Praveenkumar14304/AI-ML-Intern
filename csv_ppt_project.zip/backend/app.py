
from fastapi import FastAPI, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import pandas as pd
import numpy as np
import os, json
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
from python_pptx import Presentation
from python_pptx.util import Inches
from typing import List, Optional

app = FastAPI(title="CSV to PPT Service")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, '..', 'data')
UPLOAD_DIR = os.path.join(DATA_DIR, 'uploads')
PLOT_DIR = os.path.join(DATA_DIR, 'plots')
PPT_DIR = os.path.join(DATA_DIR, 'presentations')
for d in [UPLOAD_DIR, PLOT_DIR, PPT_DIR]:
    os.makedirs(d, exist_ok=True)

def simple_plot(df, column):
    plt.figure()
    if pd.api.types.is_numeric_dtype(df[column]):
        sns.histplot(df[column], kde=True)
    else:
        df[column].value_counts().head(10).plot.barh()
    plt.tight_layout()
    path = os.path.join(PLOT_DIR, f"{column}.png")
    plt.savefig(path)
    plt.close()
    return path

def create_ppt(metadata: dict, plot_paths: List[str]):
    prs = Presentation()
    slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(slide_layout)
    slide.shapes.title.text = "CSV Analysis Report"
    slide.placeholders[1].text = f"Generated {datetime.now().strftime('%Y-%m-%d')}"
    # Metadata slide
    md_slide = prs.slides.add_slide(prs.slide_layouts[1])
    md_slide.shapes.title.text = "Dataset Overview"
    body = md_slide.placeholders[1].text_frame
    body.text = f"Rows: {metadata['rows']}, Columns: {metadata['cols']}"
    # Plot slides
    for pth in plot_paths:
        s = prs.slides.add_slide(prs.slide_layouts[5])
        s.shapes.add_picture(pth, Inches(1), Inches(1.5), width=Inches(8))
    ppt_name = f"report_{datetime.now().strftime('%H%M%S')}.pptx"
    ppt_path = os.path.join(PPT_DIR, ppt_name)
    prs.save(ppt_path)
    return ppt_path

@app.post('/upload/')
async def upload(file: UploadFile = File(...)):
    dest = os.path.join(UPLOAD_DIR, file.filename)
    with open(dest, 'wb') as f:
        f.write(await file.read())
    df = pd.read_csv(dest, nrows=5)
    return {"message": "uploaded", "preview": df.to_dict('records'), "columns": df.columns.tolist(), "filename": file.filename}

@app.post('/process/')
async def process(selected_cols: Optional[str] = Form(None), filename: str = Form(...)):
    path = os.path.join(UPLOAD_DIR, filename)
    df = pd.read_csv(path)
    if selected_cols:
        cols = json.loads(selected_cols)
        df = df[cols]
    else:
        cols = df.columns.tolist()
    meta = {"rows": len(df), "cols": len(df.columns)}
    plot_paths = [simple_plot(df, col) for col in cols[:3]]
    ppt_path = create_ppt(meta, plot_paths)
    return {"ppt": os.path.basename(ppt_path), "meta": meta, "plots": plot_paths}

@app.get('/download/{ppt_name}')
def download(ppt_name: str):
    path = os.path.join(PPT_DIR, ppt_name)
    return FileResponse(path, media_type='application/vnd.openxmlformats-officedocument.presentationml.presentation', filename=ppt_name)
