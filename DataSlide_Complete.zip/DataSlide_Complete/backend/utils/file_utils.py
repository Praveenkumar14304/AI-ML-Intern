import os, matplotlib.pyplot as plt

PLOTS_DIR = "data/plots"
os.makedirs(PLOTS_DIR, exist_ok=True)

USELESS_COLS = ["name","phone","email","userid","password","address"]

def is_useless(col: str) -> bool:
    return any(key in col.lower() for key in USELESS_COLS)

def detect_dtype(series):
    import pandas as pd
    if pd.api.types.is_numeric_dtype(series): return "numeric"
    elif pd.api.types.is_datetime64_any_dtype(series): return "datetime"
    else: return "categorical"

def save_plot(fig, name):
    path = os.path.join(PLOTS_DIR, f"{name}.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path
