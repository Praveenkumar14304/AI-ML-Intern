import shutil
import os
import json
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from services import data_processor, llm_service, ppt_generator

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

JSON_DIR = "data/outputs"
os.makedirs(JSON_DIR, exist_ok=True)
os.makedirs(data_processor.PLOTS_DIR, exist_ok=True)

ALLOWED_EXTENSIONS = [".csv", ".xls", ".xlsx"]

import pandas as pd

@app.post("/upload-csv/")
async def upload_csv(file: UploadFile = File(...)):
    if not (file.filename.endswith(".csv") or file.filename.endswith(".xlsx")):
        return {"error": "Only CSV/Excel files are allowed"}

    # Save file temporarily
    file_path = os.path.join(data_processor.PLOTS_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Load dataset
    if file.filename.endswith(".csv"):
        df = pd.read_csv(file_path)
    else:
        df = pd.read_excel(file_path)

    # Prepare response
    response = {
        "filename": file.filename,
        "rows": df.shape[0],
        "columns": df.shape[1],        
    }

    return response


@app.post("/describe-dataset")
async def describe_dataset(file: UploadFile = File(...)):
    return data_processor.describe_dataset(file)

@app.post("/correlation-analysis")
async def correlation_analysis(file: UploadFile = File(...), selected_cols: str = Form(None)):
    cols = json.loads(selected_cols) if selected_cols else None
    return data_processor.correlation_analysis(file, cols)

@app.post("/feature-insights")
async def feature_insights(file: UploadFile = File(...), selected_cols: str = Form(...)):
    cols = json.loads(selected_cols)
    return data_processor.feature_insights(file, cols)

@app.post("/generate-ppt-content")
async def generate_ppt_content():
    return llm_service.generate_business_insights()

@app.post("/generate-ppt")
async def generate_ppt():
    return ppt_generator.generate_ppt()
