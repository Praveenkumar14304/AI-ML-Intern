import json, os
import google.generativeai as genai

JSON_DIR = "data/outputs"

# Configure API key from environment variable
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

def generate_business_insights():
    # Load JSONs
    with open(os.path.join(JSON_DIR, "data_description.json")) as f: desc = json.load(f)
    with open(os.path.join(JSON_DIR, "correlation.json")) as f: corr = json.load(f)
    with open(os.path.join(JSON_DIR, "insights.json")) as f: ins = json.load(f)

    # Construct prompt
    prompt = f"""
    You are a business analyst. Summarize dataset insights for a PPT.

    1. Data Description: {json.dumps(desc)}
    2. Correlation: {json.dumps(corr)}
    3. Insights: {json.dumps(ins)}

    Generate JSON with this structure:
    {{
      "business_insights": ["3-5 concise bullet points"],
      "conclusion": "1-2 sentence conclusion summarizing overall insights"
    }}
    """

    # Call Gemini model
    model = genai.GenerativeModel("gemini-1.5-flash")
    response = model.generate_content(prompt)

    # Clean response (sometimes it wraps JSON in markdown)
    text = response.text.strip()
    if text.startswith("```json"):
        text = text.replace("```json", "").replace("```", "").strip()

    try:
        result = json.loads(text)
    except:
        result = {"business_insights": ["Failed to parse insights"], "conclusion": "Parsing error"}

    # Save to file
    with open(os.path.join(JSON_DIR, "ppt_content.json"), "w") as f:
        json.dump(result, f, indent=2)

    return result
