import pandas as pd, numpy as np, json, os, io
import matplotlib.pyplot as plt, seaborn as sns
from utils.file_utils import save_plot, detect_dtype, is_useless

JSON_DIR = "data/outputs"
PLOTS_DIR = "data/plots"
os.makedirs(JSON_DIR, exist_ok=True)
os.makedirs(PLOTS_DIR, exist_ok=True)

# ---------- Stage 1: Dataset Description ----------
def describe_dataset(file):
    content = file.file.read()
    df = pd.read_csv(io.BytesIO(content)) if file.filename.endswith(".csv") else pd.read_excel(io.BytesIO(content))
    desc = {
        "dataset_name": file.filename,
        "dataset_size_MB": round(len(content)/(1024*1024), 2),
        "num_rows": df.shape[0],
        "num_columns": df.shape[1],
        "null_counts": df.isnull().sum().to_dict(),
        "columns": [{"name": c, "dtype": str(df[c].dtype)} for c in df.columns]
    }
    with open(os.path.join(JSON_DIR, "data_description.json"), "w") as f:
        json.dump(desc, f, indent=2)
    return desc

# ---------- Stage 2: Correlation ----------
def correlation_analysis(file, selected_cols):
    content = file.file.read()
    df = pd.read_csv(io.BytesIO(content)) if file.filename.endswith(".csv") else pd.read_excel(io.BytesIO(content))

    if selected_cols:
        import ast
        chosen = ast.literal_eval(selected_cols)
    else:
        valid_df = df[[c for c in df.columns if not is_useless(c)]]
        num_cols = [c for c in valid_df if pd.api.types.is_numeric_dtype(valid_df[c])]
        cat_cols = [c for c in valid_df if detect_dtype(valid_df[c]) == "categorical"]
        dt_cols = [c for c in valid_df if detect_dtype(valid_df[c]) == "datetime"]
        chosen = num_cols[:3] + cat_cols[:2] + dt_cols[:1]

    corr = df[chosen].corr(numeric_only=True).fillna(0).to_dict()
    result = {"selected_features": chosen, "correlation_matrix": corr}
    with open(os.path.join(JSON_DIR, "correlation.json"), "w") as f:
        json.dump(result, f, indent=2)
    return result

# ---------- Stage 3: Feature Insights ----------
def feature_insights(file, selected_cols):
    import ast
    content = file.file.read()
    df = pd.read_csv(io.BytesIO(content)) if file.filename.endswith(".csv") else pd.read_excel(io.BytesIO(content))
    selected_cols = ast.literal_eval(selected_cols)

    insights = {}
    for col in selected_cols:
        series = df[col].dropna()
        dtype = detect_dtype(series)
        plots, auto_msg = [], ""

        if dtype == "numeric":
            stats = {
                "mean": float(series.mean()), "median": float(series.median()),
                "mode": float(series.mode().iloc[0]) if not series.mode().empty else None,
                "min": float(series.min()), "max": float(series.max()),
                "skew": float(series.skew()),
                "outlier_pct": float(((series > series.mean()+3*series.std()) | (series < series.mean()-3*series.std())).mean()*100)
            }
            fig, ax = plt.subplots(); sns.histplot(series, ax=ax); plots.append(save_plot(fig, f"{col}_hist"))
            fig, ax = plt.subplots(); sns.boxplot(series, ax=ax); plots.append(save_plot(fig, f"{col}_box"))
            auto_msg = f"{col} mean={stats['mean']:.2f}, {stats['outlier_pct']:.1f}% outliers."
            insights[col] = {"type": "numeric", "stats": stats, "plot_paths": plots, "auto_insight": auto_msg}

        elif dtype == "categorical":
            vc = series.value_counts()
            stats = {"unique": int(series.nunique()), "most_frequent": str(vc.index[0])}
            fig, ax = plt.subplots(); vc.head(10).plot.bar(ax=ax); plots.append(save_plot(fig, f"{col}_bar"))
            auto_msg = f"{col} has {stats['unique']} categories, most frequent {stats['most_frequent']}."
            insights[col] = {"type": "categorical", "stats": stats, "plot_paths": plots, "auto_insight": auto_msg}

        elif dtype == "datetime":
            stats = {"min_date": str(series.min()), "max_date": str(series.max())}
            fig, ax = plt.subplots(); series.dt.year.value_counts().plot.bar(ax=ax); plots.append(save_plot(fig, f"{col}_year"))
            auto_msg = f"{col} ranges {stats['min_date']} → {stats['max_date']}."
            insights[col] = {"type": "datetime", "stats": stats, "plot_paths": plots, "auto_insight": auto_msg}

        else:  # text
            from textblob import TextBlob
            sentiment = series.astype(str).apply(lambda x: TextBlob(x).sentiment.polarity).mean()
            auto_msg = f"{col} avg sentiment={sentiment:.2f}."
            insights[col] = {"type": "text", "sentiment": sentiment, "plot_paths": [], "auto_insight": auto_msg}

    with open(os.path.join(JSON_DIR, "insights.json"), "w") as f:
        json.dump(insights, f, indent=2)
    return insights
