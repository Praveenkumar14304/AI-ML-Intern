import streamlit as st
import requests
import pandas as pd
import json
import numpy as np
from io import BytesIO
from PIL import Image


st.set_page_config(
    page_title="DataSlide - CSV to PPT Converter",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Fixed header and no-scroll CSS
st.markdown("""
    <div style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        z-index: 10000;
        background: linear-gradient(90deg, #2C6AA0 70%, #90caf9 100%);
        color: white;
        padding: 1.2rem 2rem 1.2rem 2rem;
        font-size: 1.7rem;
        font-weight: bold;
        letter-spacing: 1px;
        box-shadow: 0 2px 8px rgba(44,106,160,0.08);
        border-bottom-left-radius: 12px;
        border-bottom-right-radius: 12px;
        margin-bottom: 2rem;
    ">
        📊 DataSlide - CSV to PPT Converter
    </div>
    <div style="height: 70px;"></div>
""", unsafe_allow_html=True)

API_BASE_URL = "http://127.0.0.1:8000"


def show_floating_popup(msg):
    st.markdown(
        f"""
        <div class="floating-popup" id="popup">
            <span class="close-btn" onclick="document.getElementById('popup').style.display='none'">&times;</span>
            {msg}
        </div>
        <script>
        document.addEventListener('click', function(e) {{
            var popup = document.getElementById('popup');
            if (popup && !popup.contains(e.target)) {{
                popup.style.display = 'none';
            }}
        }});
        </script>
        """,
        unsafe_allow_html=True
    )


def main():
    if 'session_id' not in st.session_state:
        st.session_state.session_id = None
    if 'csv_data' not in st.session_state:
        st.session_state.csv_data = None
    if 'columns_info' not in st.session_state:
        st.session_state.columns_info = []
    if 'selected_columns' not in st.session_state:
        st.session_state.selected_columns = []
    if 'use_template' not in st.session_state:
        st.session_state.use_template = False
    if 'selected_theme' not in st.session_state:
        st.session_state.selected_theme = "Corporate Blue"
    if 'slide_previews' not in st.session_state:
        st.session_state.slide_previews = []
    if 'error_msg' not in st.session_state:
        st.session_state.error_msg = None
    if 'download_ready' not in st.session_state:
        st.session_state.download_ready = False

    st.markdown('<div class="main-content-noscroll">', unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1, 2, 1])

    with col1:
        st.markdown("### 📁 Upload CSV File")
        csv_uploader() # type: ignore

    with col2:
        st.markdown("### 📋 Data Preview & Column Selection")
        data_preview()

    with col3:
        st.markdown("### 🎨 Template & Theme Selection")
        template_theme_selection()
        if st.session_state.slide_previews:
            st.markdown("**PPT Slide Preview:**")
            slide_preview_section()

    st.markdown("---")
    progress_section()

    if st.session_state.error_msg:
        show_floating_popup(st.session_state.error_msg)
        st.stop()  # prevent multiple reruns with bad state

    st.markdown('</div>', unsafe_allow_html=True)


def csv_uploader():
    uploaded_file = st.file_uploader(
        "Choose a CSV/Excel file",
        type=["csv", "xlsx"],
        help="Upload your CSV or Excel file to convert to PowerPoint"
    )

    if uploaded_file is not None:
        with st.spinner("Uploading and analyzing file..."):
            upload_response = upload_csv_file(uploaded_file, API_BASE_URL)

            if "error" in upload_response:
                st.error(upload_response["error"])
            else:
                st.success(f"✅ File '{upload_response['filename']}' uploaded successfully!")
                st.write(f"📊 Shape: {upload_response['rows']} rows × {upload_response['columns']} columns")

                # Show missing values as table
                if "missing_summary" in upload_response:
                    st.subheader("Missing Values Summary")
                    missing_df = pd.DataFrame.from_dict(upload_response["missing_summary"], orient="index", columns=["Missing Values"])
                    st.dataframe(missing_df)

def upload_csv_file(uploaded_file, api_base_url):
    try:
        filename = uploaded_file.name
        if filename.lower().endswith(".csv"):
            mime_type = "text/csv"
        elif filename.lower().endswith(".xls"):
            mime_type = "application/vnd.ms-excel"
        elif filename.lower().endswith(".xlsx"):
            mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        else:
            mime_type = "application/octet-stream"

        files = {"file": (filename, uploaded_file.getvalue(), mime_type)}
        response = requests.post(f"{api_base_url}/upload-csv/", files=files)
        response.raise_for_status()
        return response.json()

    except requests.exceptions.HTTPError:
        try:
            return {"error": response.json().get("detail", response.text)}
        except Exception:
            return {"error": f"Error uploading file: {response.text}"}
    except Exception as e:
        return {"error": f"Connection error: {e}"}
    
def data_preview():
    if st.session_state.csv_data:
        df = pd.DataFrame(st.session_state.csv_data['preview'])
        total_rows = st.session_state.csv_data['shape'][0]
        total_cols = st.session_state.csv_data['shape'][1]
        null_count = int(np.sum(pd.DataFrame(st.session_state.csv_data['preview']).isnull().values))
        st.markdown(
            f"""
            <div class="info-box">
                <b>Rows:</b> {total_rows} &nbsp; | &nbsp;
                <b>Columns:</b> {total_cols} &nbsp; | &nbsp;
                <b>Total Null Values:</b> {null_count}
            </div>
            """, unsafe_allow_html=True
        )

        st.markdown("**Select Columns for Analysis:**")
        col_names = [col['name'] for col in st.session_state.columns_info]
        col_types = {col['name']: col['data_type'] for col in st.session_state.columns_info}

        selected = st.multiselect(
            "Select columns",
            options=col_names,
            default=st.session_state.selected_columns,
            key="multiselect_columns"
        )
        st.session_state.selected_columns = selected

        pill_html = ""
        for col in selected:
            dtype = col_types.get(col, "other").lower()
            pill_class = "pill-other"
            if "int" in dtype:
                pill_class = "pill-int"
            elif "float" in dtype:
                pill_class = "pill-float"
            elif "str" in dtype or "object" in dtype:
                pill_class = "pill-str"
            pill_html += f'<span class="pill {pill_class}">{col}</span>'
        if pill_html:
            st.markdown(pill_html, unsafe_allow_html=True)

        if selected:
            st.info(f"📊 Selected {len(selected)} columns for analysis")
    else:
        st.info("Upload a CSV file to see data preview and select columns")


def template_theme_selection():
    use_template = st.toggle("Use Template", value=st.session_state.use_template)
    st.session_state.use_template = use_template

    if use_template:
        st.markdown("**Upload PowerPoint Template:**")
        template_file = st.file_uploader(
            "Upload .pptx template",
            type=['pptx'],
            help="Upload your custom PowerPoint template"
        )

        if template_file and st.session_state.session_id:
            if st.button("Upload Template"):
                with st.spinner("Uploading template..."):
                    upload_response = upload_template(template_file)
                    if upload_response:
                        st.success("✅ Template uploaded successfully!")
    else:
        st.markdown("**Select Theme:**")
        themes = ["Corporate Blue", "Modern Green", "Creative Orange", "Minimal Gray"]

        selected_theme = st.selectbox(
            "Choose a theme",
            themes,
            index=themes.index(st.session_state.selected_theme)
        )
        st.session_state.selected_theme = selected_theme

        theme_colors = {
            "Corporate Blue": "#2C6AA0",
            "Modern Green": "#4CAF50",
            "Creative Orange": "#FF9800",
            "Minimal Gray": "#607D8B"
        }

        st.markdown(f"""
        <div style="background-color: {theme_colors[selected_theme]}; color: white; padding: 1rem; border-radius: 8px; text-align: center; margin: 1rem 0;">
            <strong>{selected_theme}</strong> Theme Preview
        </div>
        """, unsafe_allow_html=True)


def upload_template(template_file):
    try:
        mime_type = template_file.type or "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        files = {"file": (template_file.name, template_file.getvalue(), mime_type)}
        data = {"session_id": st.session_state.session_id}
        response = requests.post(f"{API_BASE_URL}/upload-template/", files=files, data=data)
        if response.status_code == 200:
            return response.json()
        else:
            st.session_state.error_msg = f"Error uploading template: {response.text}"
            return None
    except Exception as e:
        st.session_state.error_msg = f"Connection error: {e}"
        return None


def slide_preview_section():
    slide_imgs = st.session_state.slide_previews
    if slide_imgs:
        st.markdown('<div class="slide-preview">', unsafe_allow_html=True)
        for img_bytes in slide_imgs:
            st.image(img_bytes, width=120)
        st.markdown('</div>', unsafe_allow_html=True)


def progress_section():
    steps = [
        "1. Upload",
        "2. Column Selection",
        "3. PPT Themes",
        "4. PPT Generating",
        "5. Download PPT"
    ]
    current_step = 0
    if st.session_state.session_id:
        current_step = 1
        if st.session_state.selected_columns:
            current_step = 2
        if st.session_state.use_template or st.session_state.selected_theme:
            current_step = 3
        if st.session_state.slide_previews:
            current_step = 4
        if st.session_state.download_ready:
            current_step = 5

    progress_cols = st.columns(len(steps))
    for i, step in enumerate(steps):
        with progress_cols[i]:
            if i < current_step:
                st.markdown(f"✅ **{step}**")
            elif i == current_step:
                st.markdown(f"🔵 **{step}**")
            else:
                st.markdown(f"⭕ {step}")

    st.markdown("---")

    can_generate = (
        st.session_state.session_id and
        (st.session_state.selected_columns or len(st.session_state.columns_info) > 0)
    )

    if can_generate:
        if st.button("🚀 Generate Presentation", type="primary", use_container_width=True):
            generate_presentation()
    else:
        st.button("🚀 Generate Presentation", disabled=True, use_container_width=True)
        if not st.session_state.session_id:
            st.info("Please upload a CSV file first")


def generate_presentation():
    with st.spinner("🔄 Generating presentation... This may take a few minutes."):
        data = {
            "session_id": st.session_state.session_id,
            "selected_columns": json.dumps(st.session_state.selected_columns),
            "use_template": st.session_state.use_template,
            "theme": st.session_state.selected_theme
        }
        try:
            response = requests.post(f"{API_BASE_URL}/generate-presentation/", data=data)
            if response.status_code == 200:
                result = response.json()
                st.success("✅ Presentation generated successfully!")
                slide_imgs = get_slide_previews()
                st.session_state.slide_previews = slide_imgs
                st.session_state.download_ready = True
                st.rerun()
            else:
                st.session_state.error_msg = f"Error generating presentation: {response.text}"
        except Exception as e:
            st.session_state.error_msg = f"Connection error: {e}"

    if st.session_state.get("download_ready", False):
        download_presentation()


def get_slide_previews():
    try:
        resp = requests.get(f"{API_BASE_URL}/slide-previews/{st.session_state.session_id}/")
        if resp.status_code == 200:
            img_list = resp.json().get("slides", [])
            return [BytesIO(bytes.fromhex(img)) for img in img_list]
        else:
            return []
    except Exception:
        return []


def download_presentation():
    try:
        response = requests.get(f"{API_BASE_URL}/download/{st.session_state.session_id}/")
        if response.status_code == 200:
            st.download_button(
                label="📥 Download PowerPoint",
                data=response.content,
                file_name=f"DataSlide_Presentation_{st.session_state.session_id[:8]}.pptx",
                mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",
                key="download_ppt"
            )
        else:
            st.session_state.error_msg = "Error downloading presentation"
    except Exception as e:
        st.session_state.error_msg = f"Download error: {e}"


if __name__ == "__main__":
    main()
