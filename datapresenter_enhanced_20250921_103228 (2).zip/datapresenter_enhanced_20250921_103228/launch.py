#!/usr/bin/env python3
"""
DataPresenter Enhanced - Launch Script
Advanced data-to-presentation system with dynamic column management
"""
import os
import sys
import subprocess
import time
import webbrowser
from pathlib import Path

def open_browser():
    time.sleep(3)
    try:
        # Try multiple methods for Windows
        import webbrowser
        webbrowser.open("http://localhost:8000")
        print("🌐 Browser opened automatically")
    except Exception as e:
        print("⚠️  Could not open browser automatically")
        print("🌐 Please manually open: http://localhost:8000")

def check_python_version():
    """Check Python version compatibility"""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8+ required. Please upgrade Python.")
        return False
    print(f"✅ Python {sys.version.split()[0]} detected")
    return True

def check_dependencies():
    """Check if required packages are installed"""
    required_packages = ['fastapi', 'uvicorn', 'pandas', 'numpy']
    missing_packages = []

    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)

    if missing_packages:
        print(f"❌ Missing packages: {', '.join(missing_packages)}")
        print("📦 Installing required packages...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing_packages)
            print("✅ All packages installed successfully")
        except subprocess.CalledProcessError:
            print("❌ Failed to install packages. Please run: pip install fastapi uvicorn pandas numpy")
            return False
    else:
        print("✅ All required packages are installed")

    return True

def check_frontend_files():
    """Check if enhanced frontend files exist"""
    required_files = ['static/index.html', 'static/style.css', 'static/app.js']
    missing_files = [f for f in required_files if not os.path.exists(f)]

    if missing_files:
        print("❌ Missing frontend files:")
        for file in missing_files:
            print(f"   - {file}")
        print("\n📱 Please create the frontend files or download them")
        print("📂 You need to create index.html, style.css, and app.js in the static/ directory")
        return False

    print("✅ All enhanced frontend files found")
    return True

def create_directories():
    """Create necessary directories"""
    directories = ['static', 'temp', 'uploads']
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"✅ Created directory: {directory}/")

def create_enhanced_main():
    """Create the enhanced_main.py file if it doesn't exist"""
    if not os.path.exists("enhanced_main.py"):
        print("📝 Creating enhanced_main.py...")
        
        backend_code = '''import os
import io
import uuid
import json
import tempfile
from datetime import datetime
from typing import List, Optional, Dict, Any
from pathlib import Path

import pandas as pd
import numpy as np
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import re
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# FastAPI app initialization
app = FastAPI(
    title="DataPresenter API",
    description="Backend API for data analysis and presentation generation",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create necessary directories
os.makedirs("temp", exist_ok=True)

# In-memory session storage
sessions = {}

class EnhancedDataAnalyzer:
    """Enhanced data analysis with dynamic column management"""

    @staticmethod
    def detect_pii_columns(df: pd.DataFrame) -> Dict[str, List[str]]:
        """Detect PII columns using pattern matching and heuristics"""
        pii_patterns = {
            'email': r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$',
            'phone': r'^[\\+]?[1-9]?[0-9]{7,15}$',
            'ssn': r'^\\d{3}-?\\d{2}-?\\d{4}$',
        }

        pii_columns = {}

        for column in df.columns:
            column_lower = column.lower()
            detected_types = []

            # Check column name patterns
            name_patterns = {
                'email': ['email', 'mail', 'e-mail'],
                'phone': ['phone', 'tel', 'mobile', 'cell'],
                'name': ['name', 'firstname', 'lastname', 'fullname'],
                'address': ['address', 'street', 'city', 'zip', 'postal'],
                'ssn': ['ssn', 'social', 'social_security']
            }

            for pii_type, keywords in name_patterns.items():
                if any(keyword in column_lower for keyword in keywords):
                    detected_types.append(pii_type)

            # Check data patterns in sample
            if len(df[column]) > 0:
                sample_data = df[column].dropna().astype(str).head(50)

                for pii_type, pattern in pii_patterns.items():
                    matches = sum(1 for value in sample_data if re.match(pattern, str(value)))
                    if matches > len(sample_data) * 0.3:
                        if pii_type not in detected_types:
                            detected_types.append(pii_type)

            if detected_types:
                pii_columns[column] = detected_types

        return pii_columns

    @staticmethod
    def calculate_correlations(df: pd.DataFrame) -> Dict[str, float]:
        """Calculate correlation matrix for numeric columns"""
        numeric_df = df.select_dtypes(include=[np.number])

        if len(numeric_df.columns) < 2:
            return {}

        correlations = {}
        corr_matrix = numeric_df.corr()

        for i, col1 in enumerate(corr_matrix.columns):
            for j, col2 in enumerate(corr_matrix.columns):
                if i < j:
                    corr_value = corr_matrix.iloc[i, j]
                    if not pd.isna(corr_value) and abs(corr_value) > 0.3:
                        pair_name = f"{col1} vs {col2}"
                        correlations[pair_name] = round(float(corr_value), 3)

        sorted_corr = dict(sorted(correlations.items(), 
                                key=lambda x: abs(x[1]), reverse=True)[:6])
        return sorted_corr

    @staticmethod
    def generate_column_insights(df: pd.DataFrame) -> Dict[str, Dict]:
        """Generate comprehensive insights for each column"""
        insights = {}

        for column in df.columns:
            col_data = df[column].dropna()
            col_insights = {
                'data_type': str(df[column].dtype),
                'null_count': int(df[column].isnull().sum()),
                'null_percentage': round(float(df[column].isnull().sum() / len(df) * 100), 2),
                'unique_count': int(df[column].nunique()),
                'uniqueness_percentage': round(float(df[column].nunique() / len(df) * 100), 2),
                'total_count': len(df)
            }

            if pd.api.types.is_numeric_dtype(df[column]):
                try:
                    col_insights.update({
                        'mean': round(float(col_data.mean()), 2) if len(col_data) > 0 else None,
                        'median': round(float(col_data.median()), 2) if len(col_data) > 0 else None,
                        'std': round(float(col_data.std()), 2) if len(col_data) > 0 else None,
                        'min': round(float(col_data.min()), 2) if len(col_data) > 0 else None,
                        'max': round(float(col_data.max()), 2) if len(col_data) > 0 else None,
                        'is_numeric': True
                    })
                except Exception as e:
                    logger.warning(f"Error processing numeric column {column}: {e}")
                    col_insights['is_numeric'] = False
            else:
                col_insights['is_numeric'] = False
                try:
                    top_values = df[column].value_counts().head(5).to_dict()
                    col_insights['top_values'] = {str(k): int(v) for k, v in top_values.items()}
                except Exception as e:
                    logger.warning(f"Error processing categorical column {column}: {e}")
                    col_insights['top_values'] = {}

            insights[column] = col_insights

        return insights

class ChartConfigurationManager:
    """Manages chart configurations and column availability"""

    def __init__(self, session_data: Dict):
        self.session_data = session_data
        self.selected_columns = session_data.get('selected_columns', [])
        self.chart_configs = session_data.get('chart_configurations', {
            'dashboard': [],
            'insights_charts': [],
            'comparison': {'xAxis': '', 'yAxis': '', 'chartType': 'scatter'},
            'insights_only': {'columns': []}
        })

    def get_available_columns_for_analysis_type(self, analysis_type: str, chart_index: int = None) -> List[str]:
        """Get available columns for specific analysis type and chart position"""
        available = self.selected_columns.copy()

        if analysis_type == 'dashboard':
            used_columns = set()
            for i, config in enumerate(self.chart_configs['dashboard']):
                if i != chart_index and config.get('column'):
                    used_columns.add(config['column'])
            available = [col for col in available if col not in used_columns]

        elif analysis_type == 'insights_charts':
            used_columns = set()
            for i, config in enumerate(self.chart_configs['insights_charts']):
                if i != chart_index and config.get('column'):
                    used_columns.add(config['column'])
            available = [col for col in available if col not in used_columns]

        elif analysis_type == 'comparison':
            if chart_index == 'xAxis':
                y_axis = self.chart_configs['comparison'].get('yAxis')
                if y_axis:
                    available = [col for col in available if col != y_axis]
            elif chart_index == 'yAxis':
                x_axis = self.chart_configs['comparison'].get('xAxis')
                if x_axis:
                    available = [col for col in available if col != x_axis]

        return available

    def update_chart_configuration(self, analysis_type: str, config_data: Dict) -> bool:
        """Update chart configuration for analysis type"""
        try:
            if analysis_type == 'dashboard':
                chart_index = config_data.get('chartIndex', 0)
                while len(self.chart_configs['dashboard']) <= chart_index:
                    self.chart_configs['dashboard'].append({})

                if chart_index < len(self.chart_configs['dashboard']):
                    self.chart_configs['dashboard'][chart_index] = {
                        'column': config_data.get('column'),
                        'chartType': config_data.get('chartType', 'bar'),
                        'title': config_data.get('title', f"Chart {chart_index + 1}")
                    }

            elif analysis_type == 'insights_charts':
                insight_index = config_data.get('insightIndex', 0)
                while len(self.chart_configs['insights_charts']) <= insight_index:
                    self.chart_configs['insights_charts'].append({})

                if insight_index < len(self.chart_configs['insights_charts']):
                    self.chart_configs['insights_charts'][insight_index] = {
                        'column': config_data.get('column'),
                        'chartType': config_data.get('chartType', 'bar'),
                        'title': config_data.get('title', f"Insight {insight_index + 1}")
                    }

            elif analysis_type == 'comparison':
                if 'xAxis' in config_data:
                    self.chart_configs['comparison']['xAxis'] = config_data['xAxis']
                if 'yAxis' in config_data:
                    self.chart_configs['comparison']['yAxis'] = config_data['yAxis']
                if 'chartType' in config_data:
                    self.chart_configs['comparison']['chartType'] = config_data['chartType']

            elif analysis_type == 'insights_only':
                if 'columns' in config_data:
                    self.chart_configs['insights_only']['columns'] = config_data['columns']

            self.session_data['chart_configurations'] = self.chart_configs
            return True

        except Exception as e:
            logger.error(f"Error updating chart configuration: {str(e)}")
            return False

# Pydantic models
class ColumnSelectionRequest(BaseModel):
    sessionId: str
    selectedColumns: List[str]

class ChartConfigRequest(BaseModel):
    sessionId: str
    analysisType: str
    chartIndex: Optional[int] = None
    column: Optional[str] = None
    chartType: Optional[str] = None

class ComparisonConfigRequest(BaseModel):
    sessionId: str
    xAxis: Optional[str] = None
    yAxis: Optional[str] = None
    chartType: Optional[str] = None

class InsightsOnlyRequest(BaseModel):
    sessionId: str
    columns: List[str]

# API Routes
@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...)):
    """Handle file upload and initial processing"""
    try:
        allowed_extensions = ['.csv', '.xlsx', '.xls']
        file_extension = Path(file.filename).suffix.lower()

        if file_extension not in allowed_extensions:
            raise HTTPException(status_code=400, detail=f"Unsupported file type: {file_extension}")

        content = await file.read()

        try:
            if file_extension == '.csv':
                df = pd.read_csv(io.BytesIO(content))
            else:
                df = pd.read_excel(io.BytesIO(content))
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error reading file: {str(e)}")

        if df.empty:
            raise HTTPException(status_code=400, detail="Uploaded file is empty")

        if len(df.columns) == 0:
            raise HTTPException(status_code=400, detail="No columns found in the file")

        session_id = str(uuid.uuid4())

        analyzer = EnhancedDataAnalyzer()
        pii_columns = analyzer.detect_pii_columns(df)
        correlations = analyzer.calculate_correlations(df)
        column_insights = analyzer.generate_column_insights(df)

        total_cells = len(df) * len(df.columns)
        null_cells = df.isnull().sum().sum()
        completeness = round((1 - null_cells / total_cells) * 100, 2) if total_cells > 0 else 0

        dataset_metrics = {
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'null_values': int(null_cells),
            'completeness': completeness
        }

        sessions[session_id] = {
            'filename': file.filename,
            'columns': df.columns.tolist(),
            'preview_data': df.head(100).replace({np.nan: None}).to_dict('records'),
            'pii_columns': pii_columns,
            'correlations': correlations,
            'column_insights': column_insights,
            'dataset_metrics': dataset_metrics,
            'upload_time': datetime.now().isoformat(),
            'all_columns': df.columns.tolist(),
            'selected_columns': [],
            'chart_configurations': {
                'dashboard': [],
                'insights_charts': [],
                'comparison': {'xAxis': '', 'yAxis': '', 'chartType': 'scatter'},
                'insights_only': {'columns': []}
            }
        }

        response_data = {
            'session_id': session_id,
            'filename': file.filename,
            'dataset_metrics': dataset_metrics,
            'columns': df.columns.tolist(),
            'preview_data': df.head(10).replace({np.nan: None}).to_dict('records'),
            'pii_columns': pii_columns,
            'correlations': correlations,
            'column_insights': column_insights
        }

        logger.info(f"File processed successfully: {file.filename} (Session: {session_id})")
        return JSONResponse(content=response_data)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing file: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")

@app.post("/api/update-selected-columns")
async def update_selected_columns(request: ColumnSelectionRequest):
    """Update selected columns from Tab 1"""
    try:
        session_id = request.sessionId

        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        available_columns = sessions[session_id]['all_columns']
        invalid_columns = [col for col in request.selectedColumns if col not in available_columns]
        
        if invalid_columns:
            raise HTTPException(status_code=400, detail=f"Invalid columns selected: {invalid_columns}")

        sessions[session_id]['selected_columns'] = request.selectedColumns

        sessions[session_id]['chart_configurations'] = {
            'dashboard': [],
            'insights_charts': [],
            'comparison': {'xAxis': '', 'yAxis': '', 'chartType': 'scatter'},
            'insights_only': {'columns': []}
        }

        logger.info(f"Updated selected columns for session {session_id}: {request.selectedColumns}")

        return JSONResponse(content={
            'success': True,
            'selectedColumns': request.selectedColumns,
            'message': f"Selected {len(request.selectedColumns)} columns successfully"
        })

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating selected columns: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error updating selected columns: {str(e)}")

@app.get("/api/available-columns/{session_id}/{analysis_type}")
async def get_available_columns(session_id: str, analysis_type: str, chart_index: int = None):
    """Get available columns for specific analysis type and chart position"""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        session_data = sessions[session_id]
        
        valid_analysis_types = ['dashboard', 'insights_charts', 'comparison', 'insights_only']
        if analysis_type not in valid_analysis_types:
            raise HTTPException(status_code=400, detail=f"Invalid analysis type: {analysis_type}")

        chart_manager = ChartConfigurationManager(session_data)

        available_columns = chart_manager.get_available_columns_for_analysis_type(
            analysis_type, chart_index
        )

        return JSONResponse(content={
            'availableColumns': available_columns,
            'analysisType': analysis_type,
            'chartIndex': chart_index
        })

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting available columns: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting available columns: {str(e)}")

@app.post("/api/update-chart-config")
async def update_chart_config(request: ChartConfigRequest):
    """Update chart configuration"""
    try:
        session_id = request.sessionId

        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        session_data = sessions[session_id]
        chart_manager = ChartConfigurationManager(session_data)

        valid_analysis_types = ['dashboard', 'insights_charts', 'comparison', 'insights_only']
        if request.analysisType not in valid_analysis_types:
            raise HTTPException(status_code=400, detail=f"Invalid analysis type: {request.analysisType}")

        config_data = {
            'chartIndex': request.chartIndex,
            'column': request.column,
            'chartType': request.chartType
        }

        success = chart_manager.update_chart_configuration(request.analysisType, config_data)

        if success:
            return JSONResponse(content={
                'success': True,
                'chartConfigurations': chart_manager.chart_configs,
                'message': f"Chart configuration updated for {request.analysisType}"
            })
        else:
            raise HTTPException(status_code=400, detail="Failed to update chart configuration")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating chart configuration: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error updating chart configuration: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy", 
        "timestamp": datetime.now().isoformat(),
        "active_sessions": len(sessions)
    }

@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "DataPresenter API Server",
        "version": "1.0.0",
        "endpoints": {
            "upload": "POST /api/upload",
            "update_columns": "POST /api/update-selected-columns",
            "chart_config": "POST /api/update-chart-config",
            "health": "GET /health"
        }
    }

if __name__ == "__main__":
    import uvicorn
    logger.info("Starting DataPresenter API server on http://localhost:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)
'''

        with open("enhanced_main.py", "w", encoding="utf-8") as f:
            f.write(backend_code)
        print("✅ Created enhanced_main.py")

    return True

def start_enhanced_server():
    """Start the enhanced FastAPI server"""
    print("\n🚀 Starting Enhanced DataPresenter server...")
    print("🌐 Server will be available at: http://localhost:8000")
    print("\n📖 Features:")
    print("1. Upload CSV or Excel files")
    print("2. Select columns in Tab 1")
    print("3. Configure dynamic charts in Tab 2")
    print("4. Preview and download presentations")
    print("\n🛑 Press Ctrl+C to stop the server\n")

    # Auto-open browser
    def open_browser():       
       time.sleep(2)
    try:
        import webbrowser
        import os
        import subprocess
        
        # Try different methods for Windows
        urls = ["http://localhost:8000", "http://127.0.0.1:8000"]
        
        for url in urls:
            try:
                # Method 1: Default browser
                webbrowser.open(url)
                print(f"✅ Browser opened: {url}")
                break
            except:
                try:
                    # Method 2: Specific browsers on Windows
                    browsers = [
                        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                        r"C:\Program Files\Mozilla Firefox\firefox.exe",
                        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
                    ]
                    
                    for browser in browsers:
                        if os.path.exists(browser):
                            subprocess.Popen([browser, url])
                            print(f"✅ Opened with {browser}: {url}")
                            break
                except:
                    continue
        else:
            print("❌ Could not open browser automatically")
            print("🌐 Please manually open: http://localhost:8000")
            
    except Exception as e:
        print(f"⚠️  Browser open error: {e}")
        print("🌐 Please manually open: http://localhost:8000")
    import threading
    browser_thread = threading.Thread(target=open_browser)
    browser_thread.daemon = True
    browser_thread.start()

    try:
        # Import and run the server directly
        sys.path.append('.')
        from enhanced_main import app
        import uvicorn
        uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
    except KeyboardInterrupt:
        print("\n\n🛑 Enhanced server stopped by user")
    except Exception as e:
        print(f"❌ Error starting enhanced server: {e}")

def main():
    """Main function"""
    print("=" * 60)
    print("📊 DATAPRESENTER ENHANCED - DATA-TO-PPT SYSTEM 📊")
    print("=" * 60)

    # System checks
    if not check_python_version():
        sys.exit(1)

    create_directories()
    
    if not create_enhanced_main():
        sys.exit(1)

    if not check_dependencies():
        sys.exit(1)

    print("\n✅ All checks passed! Starting enhanced server...")
    start_enhanced_server()

if __name__ == "__main__":
    main()