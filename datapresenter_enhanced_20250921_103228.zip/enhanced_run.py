#!/usr/bin/env python3
"""
DataPresenter Enhanced - Launch Script
Advanced data-to-presentation system with dynamic column management
"""
import os
import sys
import subprocess
import time
import webbrowser
from pathlib import Path

def check_python_version():
    """Check Python version compatibility"""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8+ required. Please upgrade Python.")
        return False
    print(f"✅ Python {sys.version.split()[0]} detected")
    return True

def check_dependencies():
    """Check if required packages are installed"""
    required_packages = ['fastapi', 'uvicorn', 'pandas', 'pptx', 'openpyxl', 'plotly', 'matplotlib']
    missing_packages = []

    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)

    if missing_packages:
        print(f"❌ Missing packages: {', '.join(missing_packages)}")
        print("📦 Installing required packages...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "enhanced_requirements.txt"])
            print("✅ All packages installed successfully")
        except subprocess.CalledProcessError:
            print("❌ Failed to install packages. Please run: pip install -r enhanced_requirements.txt")
            return False
    else:
        print("✅ All required packages are installed")

    return True

def check_frontend_files():
    """Check if enhanced frontend files exist"""
    required_files = ['static/index.html', 'static/style.css', 'static/app.js']
    missing_files = [f for f in required_files if not os.path.exists(f)]

    if missing_files:
        print("❌ Missing frontend files:")
        for file in missing_files:
            print(f"   - {file}")
        print("\n📱 Please download enhanced frontend files from:")
        print("   https://ppl-ai-code-interpreter-files.s3.amazonaws.com/web/direct-files/c5b00e63a4fc2582bc50a6dae60a653b/1977ab94-5cd7-4ab7-9bc9-20c13ac5a3bb/index.html")
        print("\n📂 Copy index.html, style.css, and app.js to the static/ directory")
        return False

    print("✅ All enhanced frontend files found")
    return True

def create_directories():
    """Create necessary directories"""
    directories = ['static', 'temp', 'uploads']
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
    print("✅ Required directories created/verified")

def start_enhanced_server():
    """Start the enhanced FastAPI server"""
    print("\n🚀 Starting Enhanced DataPresenter server...")
    print("🌐 Server will be available at: http://localhost:8000")
    print("\n📖 Enhanced Features:")
    print("1. Upload your CSV or Excel file")
    print("2. Select columns in Tab 1 - only these appear in Tab 2")
    print("3. Configure dynamic charts with unique column constraints:")
    print("   • Dashboard: Add 1-6 unique charts with live previews")
    print("   • Insights+Charts: Individual insights with chart previews") 
    print("   • Comparison: X vs Y axis analysis with preview")
    print("   • Insights Only: Text-based analysis")
    print("4. Preview generated slides with configured charts")
    print("5. Download professional PowerPoint presentations")
    print("\n🔧 Dynamic Features:")
    print("   • Columns used in one chart removed from other dropdowns")
    print("   • Real-time chart previews using your actual data")
    print("   • Live preview container updates as you add/remove charts")
    print("\n🛑 Press Ctrl+C to stop the server\n")

    # Auto-open browser
    def open_browser():
        time.sleep(3)
        try:
            webbrowser.open("http://localhost:8000")
            print("🌐 Browser opened automatically")
        except:
            print("🌐 Please open http://localhost:8000 in your browser")

    import threading
    browser_thread = threading.Thread(target=open_browser)
    browser_thread.daemon = True
    browser_thread.start()

    try:
        subprocess.run([sys.executable, "enhanced_main.py"])
    except KeyboardInterrupt:
        print("\n\n🛑 Enhanced server stopped by user")
    except Exception as e:
        print(f"❌ Error starting enhanced server: {e}")

def main():
    """Main function"""
    print("=" * 70)
    print("📊 DATAPRESENTER ENHANCED - ADVANCED DATA-TO-PPT SYSTEM 📊")
    print("=" * 70)

    # System checks
    if not check_python_version():
        return

    create_directories()

    if not check_dependencies():
        return

    if not check_frontend_files():
        return

    print("\n✅ All checks passed! Starting enhanced server...")
    start_enhanced_server()

if __name__ == "__main__":
    main()
