
import os
import io
import uuid
import json
import tempfile
import zipfile
from datetime import datetime
from typing import List, Optional, Dict, Any, Union
from pathlib import Path

import pandas as pd
import numpy as np
from fastapi import FastAPI, File, UploadFile, HTTPException, Form, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
import re
import logging

# PowerPoint generation
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# FastAPI app initialization
app = FastAPI(
    title="Enhanced DataPresenter API",
    description="Transform CSV/Excel data into presentations with dynamic column management",
    version="2.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create necessary directories
os.makedirs("static", exist_ok=True)
os.makedirs("temp", exist_ok=True)
os.makedirs("uploads", exist_ok=True)

# Serve static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# In-memory session storage (use Redis in production)
sessions = {}

class EnhancedDataAnalyzer:
    """Enhanced data analysis with dynamic column management"""

    @staticmethod
    def detect_pii_columns(df: pd.DataFrame) -> Dict[str, List[str]]:
        """Detect PII columns using pattern matching and heuristics"""
        pii_patterns = {
            'email': r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
            'phone': r'^[\+]?[1-9]?[0-9]{7,15}$|^\(?[0-9]{3}\)?[-. ]?[0-9]{3}[-. ]?[0-9]{4}$',
            'ssn': r'^\d{3}-?\d{2}-?\d{4}$',
            'credit_card': r'^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})$'
        }

        pii_columns = {}

        for column in df.columns:
            column_lower = column.lower()
            detected_types = []

            # Check column name patterns
            name_patterns = {
                'email': ['email', 'mail', 'e-mail'],
                'phone': ['phone', 'tel', 'mobile', 'cell'],
                'name': ['name', 'first_name', 'last_name', 'full_name'],
                'address': ['address', 'street', 'city', 'zip', 'postal'],
                'ssn': ['ssn', 'social', 'social_security']
            }

            for pii_type, keywords in name_patterns.items():
                if any(keyword in column_lower for keyword in keywords):
                    detected_types.append(pii_type)

            # Check data patterns in sample
            if len(df[column]) > 0:
                sample_data = df[column].dropna().astype(str).head(50)

                for pii_type, pattern in pii_patterns.items():
                    matches = sum(1 for value in sample_data if re.match(pattern, str(value)))
                    if matches > len(sample_data) * 0.7:  # 70% match threshold
                        if pii_type not in detected_types:
                            detected_types.append(pii_type)

            if detected_types:
                pii_columns[column] = detected_types

        return pii_columns

    @staticmethod
    def calculate_correlations(df: pd.DataFrame) -> Dict[str, float]:
        """Calculate correlation matrix for numeric columns"""
        numeric_df = df.select_dtypes(include=[np.number])

        if len(numeric_df.columns) < 2:
            return {}

        correlations = {}
        corr_matrix = numeric_df.corr()

        # Get top correlations excluding self-correlation
        for i, col1 in enumerate(corr_matrix.columns):
            for j, col2 in enumerate(corr_matrix.columns):
                if i < j:  # Avoid duplicates and self-correlation
                    corr_value = corr_matrix.loc[col1, col2]
                    if not pd.isna(corr_value) and abs(corr_value) > 0.3:
                        pair_name = f"{col1} vs {col2}"
                        correlations[pair_name] = round(float(corr_value), 3)

        # Sort by absolute correlation value and return top 6
        sorted_corr = dict(sorted(correlations.items(), 
                                key=lambda x: abs(x[1]), reverse=True)[:6])
        return sorted_corr

    @staticmethod
    def generate_column_insights(df: pd.DataFrame) -> Dict[str, Dict]:
        """Generate comprehensive insights for each column"""
        insights = {}

        for column in df.columns:
            col_data = df[column]
            col_insights = {
                'data_type': str(col_data.dtype),
                'null_count': int(col_data.isnull().sum()),
                'null_percentage': round(float(col_data.isnull().sum() / len(col_data) * 100), 2),
                'unique_count': int(col_data.nunique()),
                'uniqueness_percentage': round(float(col_data.nunique() / len(col_data) * 100), 2),
                'total_count': len(col_data)
            }

            # Add type-specific insights
            if col_data.dtype in ['int64', 'float64', 'int32', 'float32']:
                try:
                    col_insights.update({
                        'mean': round(float(col_data.mean()), 2) if not pd.isna(col_data.mean()) else None,
                        'median': round(float(col_data.median()), 2) if not pd.isna(col_data.median()) else None,
                        'std': round(float(col_data.std()), 2) if not pd.isna(col_data.std()) else None,
                        'min': round(float(col_data.min()), 2) if not pd.isna(col_data.min()) else None,
                        'max': round(float(col_data.max()), 2) if not pd.isna(col_data.max()) else None,
                        'is_numeric': True,
                        'sample_data': col_data.head(10).tolist()
                    })
                except:
                    col_insights['is_numeric'] = False
            else:
                col_insights['is_numeric'] = False
                try:
                    top_values = col_data.value_counts().head(5).to_dict()
                    # Convert numpy types to Python types
                    col_insights['top_values'] = {str(k): int(v) for k, v in top_values.items()}
                    col_insights['sample_data'] = col_data.head(10).tolist()
                except:
                    col_insights['top_values'] = {}
                    col_insights['sample_data'] = []

            insights[column] = col_insights

        return insights

class ChartConfigurationManager:
    """Manages chart configurations and column availability"""

    def __init__(self, session_data: Dict):
        self.session_data = session_data
        self.selected_columns = session_data.get('selected_columns', [])
        self.chart_configs = session_data.get('chart_configurations', {
            'dashboard': [],
            'insights_charts': [],
            'comparison': {'xAxis': '', 'yAxis': '', 'chartType': 'scatter'},
            'insights_only': {'columns': []}
        })

    def get_available_columns_for_analysis_type(self, analysis_type: str, chart_index: int = None) -> List[str]:
        """Get available columns for specific analysis type and chart position"""
        available = self.selected_columns.copy()

        if analysis_type == 'dashboard':
            # Remove columns already used in other dashboard charts
            used_columns = set()
            for i, config in enumerate(self.chart_configs['dashboard']):
                if i != chart_index and config.get('column'):
                    used_columns.add(config['column'])
            available = [col for col in available if col not in used_columns]

        elif analysis_type == 'insights_charts':
            # Remove columns already used in other insights
            used_columns = set()
            for i, config in enumerate(self.chart_configs['insights_charts']):
                if i != chart_index and config.get('column'):
                    used_columns.add(config['column'])
            available = [col for col in available if col not in used_columns]

        elif analysis_type == 'comparison':
            # For comparison, X and Y axis should be different
            if chart_index == 'xAxis':
                y_axis = self.chart_configs['comparison'].get('yAxis')
                if y_axis:
                    available = [col for col in available if col != y_axis]
            elif chart_index == 'yAxis':
                x_axis = self.chart_configs['comparison'].get('xAxis')
                if x_axis:
                    available = [col for col in available if col != x_axis]

        return available

    def update_chart_configuration(self, analysis_type: str, config_data: Dict) -> bool:
        """Update chart configuration for analysis type"""
        try:
            if analysis_type == 'dashboard':
                chart_index = config_data.get('chartIndex', 0)
                # Ensure we have enough chart slots
                while len(self.chart_configs['dashboard']) <= chart_index:
                    self.chart_configs['dashboard'].append({})

                self.chart_configs['dashboard'][chart_index] = {
                    'column': config_data.get('column'),
                    'chartType': config_data.get('chartType'),
                    'title': config_data.get('title', f"Chart {chart_index + 1}")
                }

            elif analysis_type == 'insights_charts':
                insight_index = config_data.get('insightIndex', 0)
                # Ensure we have enough insight slots
                while len(self.chart_configs['insights_charts']) <= insight_index:
                    self.chart_configs['insights_charts'].append({})

                self.chart_configs['insights_charts'][insight_index] = {
                    'column': config_data.get('column'),
                    'chartType': config_data.get('chartType'),
                    'title': config_data.get('title', f"Insight {insight_index + 1}")
                }

            elif analysis_type == 'comparison':
                self.chart_configs['comparison'].update(config_data)

            elif analysis_type == 'insights_only':
                self.chart_configs['insights_only']['columns'] = config_data.get('columns', [])

            # Update session data
            self.session_data['chart_configurations'] = self.chart_configs
            return True

        except Exception as e:
            logger.error(f"Error updating chart configuration: {str(e)}")
            return False

    def remove_chart(self, analysis_type: str, chart_index: int) -> bool:
        """Remove a chart configuration"""
        try:
            if analysis_type == 'dashboard':
                if chart_index < len(self.chart_configs['dashboard']):
                    self.chart_configs['dashboard'][chart_index] = {}

            elif analysis_type == 'insights_charts':
                if chart_index < len(self.chart_configs['insights_charts']):
                    self.chart_configs['insights_charts'][chart_index] = {}

            # Update session data
            self.session_data['chart_configurations'] = self.chart_configs
            return True

        except Exception as e:
            logger.error(f"Error removing chart: {str(e)}")
            return False

# Pydantic models for request validation
class ColumnSelectionRequest(BaseModel):
    sessionId: str
    selectedColumns: List[str]

class ChartConfigRequest(BaseModel):
    sessionId: str
    analysisType: str
    chartIndex: Optional[int] = None
    column: Optional[str] = None
    chartType: Optional[str] = None
    title: Optional[str] = None

class ComparisonConfigRequest(BaseModel):
    sessionId: str
    xAxis: Optional[str] = None
    yAxis: Optional[str] = None
    chartType: Optional[str] = None

class InsightsOnlyRequest(BaseModel):
    sessionId: str
    columns: List[str]

# API Routes
@app.get("/", response_class=HTMLResponse)
async def serve_app():
    """Serve the main application"""
    try:
        with open("static/index.html", "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    except FileNotFoundError:
        return HTMLResponse(content="""
        <html>
            <head><title>DataPresenter Enhanced</title></head>
            <body style="font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5;">
                <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                    <h1 style="color: #1f4e79;">🚀 DataPresenter Enhanced</h1>
                    <p style="color: #666; font-size: 16px;">Backend server is running successfully.</p>
                    <h3 style="color: #1f4e79;">Frontend Setup Required:</h3>
                    <ol style="color: #666; font-size: 14px;">
                        <li>Download frontend files: index.html, style.css, app.js</li>
                        <li>Place them in the static/ directory</li>
                        <li>Restart the server</li>
                    </ol>
                </div>
            </body>
        </html>
        """)

@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...)):
    """Handle file upload and initial processing"""
    try:
        # Validate file type
        allowed_extensions = ['.csv', '.xlsx', '.xls']
        file_extension = os.path.splitext(file.filename)[1].lower()

        if file_extension not in allowed_extensions:
            raise HTTPException(status_code=400, detail=f"Unsupported file type: {file_extension}")

        # Read file content
        content = await file.read()

        # Process based on file type
        try:
            if file_extension == '.csv':
                df = pd.read_csv(io.StringIO(content.decode('utf-8')))
            else:  # Excel files
                df = pd.read_excel(io.BytesIO(content))
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error reading file: {str(e)}")

        # Generate session ID
        session_id = str(uuid.uuid4())

        # Analyze data
        analyzer = EnhancedDataAnalyzer()
        pii_columns = analyzer.detect_pii_columns(df)
        correlations = analyzer.calculate_correlations(df)
        column_insights = analyzer.generate_column_insights(df)

        # Calculate dataset metrics
        dataset_metrics = {
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'null_values': int(df.isnull().sum().sum()),
            'completeness': round(float((1 - df.isnull().sum().sum() / (len(df) * len(df.columns))) * 100), 2)
        }

        # Store session data
        sessions[session_id] = {
            'filename': file.filename,
            'dataframe': df,
            'pii_columns': pii_columns,
            'correlations': correlations,
            'column_insights': column_insights,
            'dataset_metrics': dataset_metrics,
            'upload_time': datetime.now(),
            'all_columns': list(df.columns),
            'selected_columns': [],  # Will be updated when user selects columns
            'chart_configurations': {
                'dashboard': [],
                'insights_charts': [],
                'comparison': {'xAxis': '', 'yAxis': '', 'chartType': 'scatter'},
                'insights_only': {'columns': []}
            }
        }

        # Prepare response
        response_data = {
            'session_id': session_id,
            'filename': file.filename,
            'dataset_metrics': dataset_metrics,
            'columns': df.columns.tolist(),
            'preview_data': df.head(100).fillna('').to_dict('records'),
            'pii_columns': pii_columns,
            'correlations': correlations,
            'column_insights': column_insights
        }

        logger.info(f"File processed successfully: {file.filename} (Session: {session_id})")
        return JSONResponse(content=response_data)

    except Exception as e:
        logger.error(f"Error processing file: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")

@app.post("/api/update-selected-columns")
async def update_selected_columns(request: ColumnSelectionRequest):
    """Update selected columns from Tab 1"""
    try:
        session_id = request.sessionId

        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        # Update selected columns
        sessions[session_id]['selected_columns'] = request.selectedColumns

        # Reset chart configurations when columns change
        sessions[session_id]['chart_configurations'] = {
            'dashboard': [],
            'insights_charts': [],
            'comparison': {'xAxis': '', 'yAxis': '', 'chartType': 'scatter'},
            'insights_only': {'columns': []}
        }

        logger.info(f"Updated selected columns for session {session_id}: {request.selectedColumns}")

        return JSONResponse(content={
            'success': True,
            'selectedColumns': request.selectedColumns
        })

    except Exception as e:
        logger.error(f"Error updating selected columns: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error updating selected columns: {str(e)}")

@app.get("/api/available-columns/{session_id}/{analysis_type}")
async def get_available_columns(session_id: str, analysis_type: str, chart_index: int = None):
    """Get available columns for specific analysis type and chart position"""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        session_data = sessions[session_id]
        chart_manager = ChartConfigurationManager(session_data)

        available_columns = chart_manager.get_available_columns_for_analysis_type(
            analysis_type, chart_index
        )

        return JSONResponse(content={
            'availableColumns': available_columns,
            'analysisType': analysis_type,
            'chartIndex': chart_index
        })

    except Exception as e:
        logger.error(f"Error getting available columns: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting available columns: {str(e)}")

@app.post("/api/update-chart-config")
async def update_chart_config(request: ChartConfigRequest):
    """Update chart configuration"""
    try:
        session_id = request.sessionId

        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        session_data = sessions[session_id]
        chart_manager = ChartConfigurationManager(session_data)

        config_data = {
            'chartIndex': request.chartIndex,
            'column': request.column,
            'chartType': request.chartType,
            'title': request.title
        }

        success = chart_manager.update_chart_configuration(request.analysisType, config_data)

        if success:
            return JSONResponse(content={
                'success': True,
                'chartConfigurations': chart_manager.chart_configs
            })
        else:
            raise HTTPException(status_code=400, detail="Failed to update chart configuration")

    except Exception as e:
        logger.error(f"Error updating chart configuration: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error updating chart configuration: {str(e)}")

@app.post("/api/update-comparison-config")
async def update_comparison_config(request: ComparisonConfigRequest):
    """Update comparison analysis configuration"""
    try:
        session_id = request.sessionId

        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        session_data = sessions[session_id]
        chart_manager = ChartConfigurationManager(session_data)

        config_data = {}
        if request.xAxis is not None:
            config_data['xAxis'] = request.xAxis
        if request.yAxis is not None:
            config_data['yAxis'] = request.yAxis
        if request.chartType is not None:
            config_data['chartType'] = request.chartType

        success = chart_manager.update_chart_configuration('comparison', config_data)

        if success:
            return JSONResponse(content={
                'success': True,
                'comparisonConfig': chart_manager.chart_configs['comparison']
            })
        else:
            raise HTTPException(status_code=400, detail="Failed to update comparison configuration")

    except Exception as e:
        logger.error(f"Error updating comparison configuration: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error updating comparison configuration: {str(e)}")

@app.post("/api/update-insights-only")
async def update_insights_only(request: InsightsOnlyRequest):
    """Update insights only configuration"""
    try:
        session_id = request.sessionId

        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        session_data = sessions[session_id]
        chart_manager = ChartConfigurationManager(session_data)

        config_data = {'columns': request.columns}
        success = chart_manager.update_chart_configuration('insights_only', config_data)

        if success:
            return JSONResponse(content={
                'success': True,
                'insightsOnlyConfig': chart_manager.chart_configs['insights_only']
            })
        else:
            raise HTTPException(status_code=400, detail="Failed to update insights only configuration")

    except Exception as e:
        logger.error(f"Error updating insights only configuration: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error updating insights only configuration: {str(e)}")

@app.delete("/api/remove-chart/{session_id}/{analysis_type}/{chart_index}")
async def remove_chart(session_id: str, analysis_type: str, chart_index: int):
    """Remove a chart configuration"""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        session_data = sessions[session_id]
        chart_manager = ChartConfigurationManager(session_data)

        success = chart_manager.remove_chart(analysis_type, chart_index)

        if success:
            return JSONResponse(content={
                'success': True,
                'chartConfigurations': chart_manager.chart_configs
            })
        else:
            raise HTTPException(status_code=400, detail="Failed to remove chart")

    except Exception as e:
        logger.error(f"Error removing chart: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error removing chart: {str(e)}")

@app.get("/api/chart-preview-data/{session_id}/{column}")
async def get_chart_preview_data(session_id: str, column: str):
    """Get data for chart preview"""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        session_data = sessions[session_id]
        df = session_data['dataframe']

        if column not in df.columns:
            raise HTTPException(status_code=404, detail="Column not found")

        # Get sample data for preview (limit to 50 points for performance)
        sample_df = df.sample(min(50, len(df))) if len(df) > 50 else df

        column_data = sample_df[column].dropna()

        # Generate appropriate data structure based on column type
        if df[column].dtype in ['int64', 'float64', 'int32', 'float32']:
            # Numeric data
            if len(column_data) > 10:
                # Create bins for histogram-like data
                bins = pd.cut(column_data, bins=10)
                bin_counts = bins.value_counts().sort_index()

                chart_data = {
                    'labels': [str(interval) for interval in bin_counts.index],
                    'data': bin_counts.values.tolist(),
                    'type': 'numeric'
                }
            else:
                chart_data = {
                    'labels': [str(i) for i in range(len(column_data))],
                    'data': column_data.tolist(),
                    'type': 'numeric'
                }
        else:
            # Categorical data
            value_counts = column_data.value_counts().head(10)  # Top 10 categories
            chart_data = {
                'labels': value_counts.index.tolist(),
                'data': value_counts.values.tolist(),
                'type': 'categorical'
            }

        return JSONResponse(content={
            'success': True,
            'column': column,
            'chartData': chart_data
        })

    except Exception as e:
        logger.error(f"Error getting chart preview data: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting chart preview data: {str(e)}")

@app.get("/api/comparison-preview-data/{session_id}")
async def get_comparison_preview_data(session_id: str, x_axis: str, y_axis: str):
    """Get data for comparison chart preview"""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        session_data = sessions[session_id]
        df = session_data['dataframe']

        if x_axis not in df.columns or y_axis not in df.columns:
            raise HTTPException(status_code=404, detail="Columns not found")

        # Get sample data for preview (limit to 50 points)
        sample_df = df.sample(min(50, len(df))) if len(df) > 50 else df
        sample_df = sample_df[[x_axis, y_axis]].dropna()

        chart_data = {
            'xData': sample_df[x_axis].tolist(),
            'yData': sample_df[y_axis].tolist(),
            'xAxis': x_axis,
            'yAxis': y_axis
        }

        return JSONResponse(content={
            'success': True,
            'chartData': chart_data
        })

    except Exception as e:
        logger.error(f"Error getting comparison preview data: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting comparison preview data: {str(e)}")

@app.get("/api/session/{session_id}")
async def get_session_data(session_id: str):
    """Get complete session data"""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")

        session_data = sessions[session_id]

        response = {
            'session_id': session_id,
            'filename': session_data['filename'],
            'dataset_metrics': session_data['dataset_metrics'],
            'all_columns': session_data['all_columns'],
            'selected_columns': session_data['selected_columns'],
            'column_insights': session_data['column_insights'],
            'correlations': session_data['correlations'],
            'pii_columns': session_data['pii_columns'],
            'chart_configurations': session_data['chart_configurations'],
            'upload_time': session_data['upload_time'].isoformat()
        }

        return JSONResponse(content=response)

    except Exception as e:
        logger.error(f"Error retrieving session: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error retrieving session: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

if __name__ == "__main__":
    logger.info("Starting Enhanced DataPresenter API server...")
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
