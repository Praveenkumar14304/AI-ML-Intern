#!/usr/bin/env python3
"""
DataSlide Project Runner
Automatically starts both backend and frontend servers
"""

import subprocess
import sys
import time
import os
import platform

def install_requirements():
    """Install required packages"""
    print("📦 Installing requirements...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Requirements installed successfully!")
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing requirements: {e}")
        return False
    return True

def start_backend():
    """Start FastAPI backend"""
    print("🚀 Starting FastAPI backend...")
    os.chdir("backend")

    if platform.system() == "Windows":
        return subprocess.Popen([sys.executable, "main.py"], shell=True)
    else:
        return subprocess.Popen([sys.executable, "main.py"])

def start_frontend():
    """Start Streamlit frontend"""
    print("🎨 Starting Streamlit frontend...")
    os.chdir("../frontend")

    if platform.system() == "Windows":
        return subprocess.Popen([sys.executable, "-m", "streamlit", "run", "app.py"], shell=True)
    else:
        return subprocess.Popen([sys.executable, "-m", "streamlit", "run", "app.py"])

def main():
    print("🌟 DataSlide - CSV to PPT Converter")
    print("=====================================")

    if not install_requirements():
        return

    try:
        backend_process = start_backend()
        time.sleep(5)

        frontend_process = start_frontend()

        print("\n✅ Both servers are starting...")
        print("📱 Frontend: http://localhost:8501")
        print("⚡ Backend: http://localhost:8000")
        print("\n🔄 Waiting for servers to initialize...")
        print("📝 Check the terminal output above for any errors")
        print("\n❌ Press Ctrl+C to stop both servers")

        try:
            backend_process.wait()
            frontend_process.wait()
        except KeyboardInterrupt:
            print("\n🛑 Stopping servers...")
            backend_process.terminate()
            frontend_process.terminate()
            print("✅ Servers stopped successfully!")

    except Exception as e:
        print(f"❌ Error starting servers: {e}")

if __name__ == "__main__":
    main()