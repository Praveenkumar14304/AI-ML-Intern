import streamlit as st
import requests
import pandas as pd
import json
import time
import os
from io import BytesIO

st.set_page_config(
    page_title="DataSlide - CSV to PPT Converter",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

st.markdown("""
<style>
    .main > div {
        padding-top: 2rem;
    }

    .stApp > header {
        background-color: transparent;
    }

    .header-container {
        background: linear-gradient(90deg, #2C6AA0 0%, #1e4a72 100%);
        padding: 1rem 2rem;
        margin: -1rem -1rem 2rem -1rem;
        border-radius: 0;
    }

    .header-title {
        color: white;
        font-size: 2rem;
        font-weight: bold;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .upload-container {
        border: 2px dashed #2C6AA0;
        border-radius: 10px;
        padding: 2rem;
        text-align: center;
        background-color: #f8f9fa;
        margin: 1rem 0;
    }

    .theme-card {
        border: 2px solid #e0e0e0;
        border-radius: 8px;
        padding: 1rem;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .theme-card:hover {
        border-color: #2C6AA0;
        box-shadow: 0 4px 8px rgba(44, 106, 160, 0.2);
    }

    .theme-card.selected {
        border-color: #2C6AA0;
        background-color: #e3f2fd;
    }

    .generate-button {
        background: linear-gradient(90deg, #2C6AA0 0%, #1e4a72 100%);
        color: white;
        border: none;
        padding: 0.75rem 2rem;
        border-radius: 8px;
        font-size: 1.1rem;
        font-weight: bold;
        cursor: pointer;
        width: 100%;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

API_BASE_URL = "http://localhost:8000"

def main():
    st.markdown("""
    <div class="header-container">
        <div class="header-title">
            📊 DataSlide
        </div>
    </div>
    """, unsafe_allow_html=True)

    if 'session_id' not in st.session_state:
        st.session_state.session_id = None
    if 'csv_data' not in st.session_state:
        st.session_state.csv_data = None
    if 'columns_info' not in st.session_state:
        st.session_state.columns_info = []
    if 'selected_columns' not in st.session_state:
        st.session_state.selected_columns = []
    if 'use_template' not in st.session_state:
        st.session_state.use_template = False
    if 'selected_theme' not in st.session_state:
        st.session_state.selected_theme = "Corporate Blue"

    col1, col2, col3 = st.columns([1, 2, 1])

    with col1:
        st.markdown("### 📁 Upload CSV File")
        csv_uploader()

    with col2:
        st.markdown("### 📋 Data Preview & Column Selection")
        data_preview()

    with col3:
        st.markdown("### 🎨 Template & Theme Selection")
        template_theme_selection()

    st.markdown("---")
    progress_section()

def csv_uploader():
    uploaded_file = st.file_uploader(
        "Choose a CSV file",
        type=['csv', 'xlsx'],
        help="Upload your CSV or Excel file to convert to PowerPoint"
    )

    if uploaded_file is not None:
        if st.session_state.session_id is None or uploaded_file.name != getattr(st.session_state, 'uploaded_filename', ''):
            with st.spinner("Uploading and analyzing file..."):
                upload_response = upload_csv_file(uploaded_file)
                if upload_response:
                    st.session_state.session_id = upload_response['session_id']
                    st.session_state.csv_data = upload_response
                    st.session_state.columns_info = upload_response['columns']
                    st.session_state.uploaded_filename = uploaded_file.name
                    st.success(f"✅ File uploaded successfully! ({upload_response['shape'][0]} rows, {upload_response['shape'][1]} columns)")
                    st.rerun()

def upload_csv_file(uploaded_file):
    try:
        files = {"file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type)}
        response = requests.post(f"{API_BASE_URL}/upload-csv", files=files)
        if response.status_code == 200:
            return response.json()
        else:
            st.error(f"Error uploading file: {response.text}")
            return None
    except Exception as e:
        st.error(f"Connection error: {e}")
        return None

def data_preview():
    if st.session_state.csv_data:
        st.markdown("**Data Preview:**")
        preview_df = pd.DataFrame(st.session_state.csv_data['preview'])
        st.dataframe(preview_df.head(), use_container_width=True)

        st.markdown("**Select Columns for Analysis:**")

        select_all = st.checkbox("Select All Columns")

        if select_all:
            st.session_state.selected_columns = [col['name'] for col in st.session_state.columns_info]

        selected_cols = []
        for col_info in st.session_state.columns_info:
            col_name = col_info['name']
            is_selected = st.checkbox(
                f"{col_name} ({col_info['data_type']})", 
                value=col_name in st.session_state.selected_columns or select_all,
                key=f"col_{col_name}"
            )
            if is_selected:
                selected_cols.append(col_name)

        st.session_state.selected_columns = selected_cols

        if selected_cols:
            st.info(f"📊 Selected {len(selected_cols)} columns for analysis")
    else:
        st.info("Upload a CSV file to see data preview and select columns")

def template_theme_selection():
    use_template = st.toggle("Use Template", value=st.session_state.use_template)
    st.session_state.use_template = use_template

    if use_template:
        st.markdown("**Upload PowerPoint Template:**")
        template_file = st.file_uploader(
            "Upload .pptx template",
            type=['pptx'],
            help="Upload your custom PowerPoint template"
        )

        if template_file and st.session_state.session_id:
            if st.button("Upload Template"):
                with st.spinner("Uploading template..."):
                    upload_response = upload_template(template_file)
                    if upload_response:
                        st.success("✅ Template uploaded successfully!")
    else:
        st.markdown("**Select Theme:**")
        themes = ["Corporate Blue", "Modern Green", "Creative Orange", "Minimal Gray"]

        selected_theme = st.selectbox(
            "Choose a theme",
            themes,
            index=themes.index(st.session_state.selected_theme)
        )
        st.session_state.selected_theme = selected_theme

        theme_colors = {
            "Corporate Blue": "#2C6AA0",
            "Modern Green": "#4CAF50", 
            "Creative Orange": "#FF9800",
            "Minimal Gray": "#607D8B"
        }

        st.markdown(f"""
        <div style="background-color: {theme_colors[selected_theme]}; color: white; padding: 1rem; border-radius: 8px; text-align: center; margin: 1rem 0;">
            <strong>{selected_theme}</strong> Theme Preview
        </div>
        """, unsafe_allow_html=True)

def upload_template(template_file):
    try:
        files = {"file": (template_file.name, template_file.getvalue(), template_file.type)}
        data = {"session_id": st.session_state.session_id}
        response = requests.post(f"{API_BASE_URL}/upload-template", files=files, data=data)
        if response.status_code == 200:
            return response.json()
        else:
            st.error(f"Error uploading template: {response.text}")
            return None
    except Exception as e:
        st.error(f"Connection error: {e}")
        return None

def progress_section():
    steps = ["1. Upload", "2. Settings", "3. Convert"]
    current_step = 0

    if st.session_state.session_id:
        current_step = 1
        if st.session_state.selected_columns or st.session_state.use_template:
            current_step = 2

    progress_cols = st.columns(3)
    for i, step in enumerate(steps):
        with progress_cols[i]:
            if i <= current_step:
                st.markdown(f"✅ **{step}**")
            else:
                st.markdown(f"⭕ {step}")

    st.markdown("---")

    can_generate = (
        st.session_state.session_id and 
        (st.session_state.selected_columns or len(st.session_state.columns_info) > 0)
    )

    if can_generate:
        if st.button("🚀 Generate Presentation", type="primary", use_container_width=True):
            generate_presentation()
    else:
        st.button("🚀 Generate Presentation", disabled=True, use_container_width=True)
        if not st.session_state.session_id:
            st.info("Please upload a CSV file first")

def generate_presentation():
    with st.spinner("🔄 Generating presentation... This may take a few minutes."):

        data = {
            "session_id": st.session_state.session_id,
            "selected_columns": json.dumps(st.session_state.selected_columns),
            "use_template": st.session_state.use_template,
            "theme": st.session_state.selected_theme
        }

        try:
            response = requests.post(f"{API_BASE_URL}/generate-presentation", data=data)

            if response.status_code == 200:
                result = response.json()
                st.success("✅ Presentation generated successfully!")

                if st.button("📥 Download Presentation", type="primary"):
                    download_presentation()

            else:
                st.error(f"Error generating presentation: {response.text}")

        except Exception as e:
            st.error(f"Connection error: {e}")

def download_presentation():
    try:
        response = requests.get(f"{API_BASE_URL}/download/{st.session_state.session_id}")
        if response.status_code == 200:
            st.download_button(
                label="📥 Download PowerPoint",
                data=response.content,
                file_name=f"DataSlide_Presentation_{st.session_state.session_id[:8]}.pptx",
                mime="application/vnd.openxmlformats-officedocument.presentationml.presentation"
            )
        else:
            st.error("Error downloading presentation")
    except Exception as e:
        st.error(f"Download error: {e}")

if __name__ == "__main__":
    main()