from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
import os
import json
from PIL import Image

class PPTGenerator:
    def __init__(self):
        self.themes = {
            "Corporate Blue": {
                "primary_color": RGBColor(44, 106, 160),
                "secondary_color": RGBColor(255, 255, 255),
                "accent_color": RGBColor(76, 175, 80),
                "text_color": RGBColor(33, 33, 33)
            },
            "Modern Green": {
                "primary_color": RGBColor(76, 175, 80),
                "secondary_color": RGBColor(255, 255, 255),
                "accent_color": RGBColor(255, 193, 7),
                "text_color": RGBColor(33, 33, 33)
            },
            "Creative Orange": {
                "primary_color": RGBColor(255, 152, 0),
                "secondary_color": RGBColor(255, 255, 255),
                "accent_color": RGBColor(233, 30, 99),
                "text_color": RGBColor(33, 33, 33)
            },
            "Minimal Gray": {
                "primary_color": RGBColor(96, 125, 139),
                "secondary_color": RGBColor(255, 255, 255),
                "accent_color": RGBColor(158, 158, 158),
                "text_color": RGBColor(33, 33, 33)
            }
        }

    def create_presentation(self, narrative, analysis_results, session_id, template_path=None, theme="Corporate Blue"):
        if template_path and os.path.exists(template_path):
            prs = Presentation(template_path)
            print(f"Using uploaded template: {template_path}")
        else:
            prs = Presentation()
            print(f"Using theme: {theme}")

        theme_colors = self.themes.get(theme, self.themes["Corporate Blue"])

        if template_path:
            slide_ids = [slide._element for slide in prs.slides][1:]
            for slide_id in slide_ids:
                prs.slides._sldIdLst.remove(slide_id)

        slides_data = narrative.get("slides", [])

        for i, slide_data in enumerate(slides_data):
            slide = self._create_slide(prs, slide_data, theme_colors, i == 0)
            self._add_charts_to_slide(slide, slide_data.get("chart_references", []))

        output_path = f"../data/outputs/{session_id}_presentation.pptx"
        prs.save(output_path)

        print(f"Presentation saved to: {output_path}")
        return output_path

    def _create_slide(self, prs, slide_data, theme_colors, is_title_slide=False):
        if is_title_slide:
            slide_layout = prs.slide_layouts[0]
            slide = prs.slides.add_slide(slide_layout)

            title = slide.shapes.title
            title.text = slide_data.get("title", "Data Analysis Report")
            self._format_title(title, theme_colors, size=Pt(44))

            if slide.shapes.placeholders[1] and slide_data.get("content"):
                subtitle = slide.shapes.placeholders[1]
                subtitle.text = "\n".join(slide_data["content"][:2])
                self._format_text(subtitle, theme_colors, size=Pt(24))

        else:
            slide_layout = prs.slide_layouts[1]
            slide = prs.slides.add_slide(slide_layout)

            title = slide.shapes.title
            title.text = slide_data.get("title", "Analysis")
            self._format_title(title, theme_colors, size=Pt(32))

            content_placeholder = slide.shapes.placeholders[1]
            tf = content_placeholder.text_frame

            for i, bullet_point in enumerate(slide_data.get("content", [])):
                if i == 0:
                    tf.text = bullet_point
                else:
                    p = tf.add_paragraph()
                    p.text = bullet_point

                if i < len(tf.paragraphs):
                    self._format_paragraph(tf.paragraphs[i], theme_colors)

        return slide

    def _add_charts_to_slide(self, slide, chart_references):
        if not chart_references:
            return

        chart_left = Inches(6)
        chart_top = Inches(2)
        chart_width = Inches(4)
        chart_height = Inches(3)

        for i, chart_path in enumerate(chart_references[:2]):
            if os.path.exists(chart_path):
                try:
                    top_position = chart_top + (i * Inches(3.5))
                    slide.shapes.add_picture(
                        chart_path, 
                        chart_left, 
                        top_position, 
                        chart_width, 
                        chart_height
                    )
                    print(f"Added chart: {chart_path}")
                except Exception as e:
                    print(f"Error adding chart {chart_path}: {e}")

    def _format_title(self, title_shape, theme_colors, size=Pt(32)):
        if hasattr(title_shape, 'text_frame'):
            tf = title_shape.text_frame
            if tf.paragraphs:
                p = tf.paragraphs[0]
                run = p.runs[0] if p.runs else p.add_run()
                run.font.size = size
                run.font.color.rgb = theme_colors["primary_color"]
                run.font.bold = True
                p.alignment = PP_ALIGN.CENTER

    def _format_text(self, text_shape, theme_colors, size=Pt(18)):
        if hasattr(text_shape, 'text_frame'):
            tf = text_shape.text_frame
            for p in tf.paragraphs:
                for run in p.runs:
                    run.font.size = size
                    run.font.color.rgb = theme_colors["text_color"]

    def _format_paragraph(self, paragraph, theme_colors, size=Pt(18)):
        for run in paragraph.runs:
            run.font.size = size
            run.font.color.rgb = theme_colors["text_color"]

        paragraph.level = 0