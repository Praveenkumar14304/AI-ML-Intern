import aiofiles
import os
from fastapi import UploadFile
import pandas as pd

async def save_upload_file(upload_file: UploadFile, destination: str) -> str:
    """Save uploaded file to destination"""
    os.makedirs(os.path.dirname(destination), exist_ok=True)

    async with aiofiles.open(destination, 'wb') as f:
        content = await upload_file.read()
        await f.write(content)

    return destination

def validate_csv_file(file: UploadFile) -> bool:
    """Validate if uploaded file is a valid CSV"""
    if not file.filename.lower().endswith(('.csv', '.xlsx')):
        return False

    return True

def cleanup_session_files(session_id: str):
    """Clean up temporary files for a session"""
    directories = ["../data/uploads", "../data/outputs", "../data/plots"]

    for directory in directories:
        if os.path.exists(directory):
            for filename in os.listdir(directory):
                if filename.startswith(session_id):
                    file_path = os.path.join(directory, filename)
                    try:
                        os.remove(file_path)
                        print(f"Cleaned up: {file_path}")
                    except Exception as e:
                        print(f"Error cleaning up {file_path}: {e}")