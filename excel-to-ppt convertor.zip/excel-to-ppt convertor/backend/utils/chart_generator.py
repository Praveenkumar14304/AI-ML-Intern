import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from plotly.subplots import make_subplots

def generate_chart_preview(df, chart_type, x_col, y_cols):
    """Generate HTML preview for a chart"""
    try:
        if chart_type == 'bar':
            fig = go.Figure(data=[go.Bar(x=df[x_col], y=df[y_cols[0]] if y_cols else df[df.columns[0]])])
        elif chart_type == 'line':
            fig = go.Figure(data=[go.Scatter(x=df[x_col], y=df[y_cols[0]] if y_cols else df[df.columns[0]], mode='lines')])
        elif chart_type == 'scatter':
            fig = go.Figure(data=[go.Scatter(x=df[x_col], y=df[y_cols[0]] if y_cols else df[df.columns[0]], mode='markers')])
        else:
            fig = go.Figure(data=[go.Bar(x=df[x_col], y=df[y_cols[0]] if y_cols else df[df.columns[0]])])
        
        fig.update_layout(
            autosize=True,
            margin=dict(l=20, r=20, t=30, b=20),
            showlegend=False
        )
        
        return fig.to_html(include_plotlyjs=False, div_id=f"chart-{x_col}")
    except Exception as e:
        return f"<div>Error generating chart: {str(e)}</div>"

def generate_dashboard_preview(df, chart_configs):
    """Generate HTML preview for a dashboard"""
    try:
        rows = min(2, len(chart_configs))
        cols = min(3, len(chart_configs))
        
        fig = make_subplots(rows=rows, cols=cols)
        
        for i, config in enumerate(chart_configs[:6]):
            row = (i // cols) + 1
            col = (i % cols) + 1
            
            if config['type'] == 'bar':
                trace = go.Bar(x=df[config['x_column']], 
                              y=df[config['y_columns'][0]],
                              name=config['x_column'])
            elif config['type'] == 'line':
                trace = go.Scatter(x=df[config['x_column']], 
                                  y=df[config['y_columns'][0]],
                                  name=config['x_column'],
                                  mode='lines+markers')
            else:
                trace = go.Bar(x=df[config['x_column']], 
                              y=df[config['y_columns'][0]],
                              name=config['x_column'])
            
            fig.add_trace(trace, row=row, col=col)
            fig.update_xaxes(title_text=config['x_column'], row=row, col=col)
            fig.update_yaxes(title_text=config['y_columns'][0], row=row, col=col)
        
        fig.update_layout(height=400, showlegend=False)
        return fig.to_html(include_plotlyjs=False, div_id="dashboard-preview")
    except Exception as e:
        return f"<div>Error generating dashboard: {str(e)}</div>"