from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
from pptx.chart.data import ChartData
from pptx.enum.chart import XL_CHART_TYPE
import pandas as pd
import tempfile
import os

def generate_slides(prs, df, config, logo_path=None):
    """Generate PowerPoint slides based on configuration"""
    # Title slide
    title_slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(title_slide_layout)
    title = slide.shapes.title
    subtitle = slide.placeholders[1]
    
    title.text = config.get('title', 'Data Presentation')
    subtitle.text = f"Generated from {df.shape[0]} rows of data"
    
    # Add logo if provided
    if logo_path and os.path.exists(logo_path):
        try:
            slide.shapes.add_picture(logo_path, Inches(0.5), Inches(0.5), 
                                    height=Inches(1))
        except:
            pass  # Skip if logo can't be added
    
    # Summary slide
    summary_slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(summary_slide_layout)
    title = slide.shapes.title
    title.text = "Data Summary"
    
    content = slide.placeholders[1]
    tf = content.text_frame
    tf.text = f"Dataset contains {df.shape[0]} rows and {df.shape[1]} columns"
    
    # Add key statistics
    p = tf.add_paragraph()
    p.text = "Key metrics:"
    
    for col in config.get('selected_columns', [])[:3]:
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            p = tf.add_paragraph()
            p.text = f"{col}: Mean={df[col].mean():.2f}, Range={df[col].min():.2f}-{df[col].max():.2f}"
            p.level = 1
    
    # Data slides
    for col in config.get('selected_columns', []):
        if col not in df.columns:
            continue
            
        # Different layouts based on data type
        if pd.api.types.is_numeric_dtype(df[col]):
            # Numerical data - create chart slide
            chart_slide_layout = prs.slide_layouts[5]  # Blank layout
            slide = prs.slides.add_slide(chart_slide_layout)
            title = slide.shapes.title
            title.text = f"Analysis of {col}"
            
            # Add chart
            chart_data = ChartData()
            chart_data.categories = [str(x) for x in df[col].value_counts().index[:10]]
            chart_data.add_series('Count', df[col].value_counts().values[:10])
            
            x, y, cx, cy = Inches(1), Inches(1.5), Inches(8), Inches(5)
            chart = slide.shapes.add_chart(
                XL_CHART_TYPE.COLUMN_CLUSTERED, x, y, cx, cy, chart_data
            ).chart
            
            # Add summary
            left = Inches(1)
            top = Inches(5)
            width = Inches(8)
            height = Inches(1.5)
            
            txBox = slide.shapes.add_textbox(left, top, width, height)
            tf = txBox.text_frame
            tf.text = f"Summary: Mean={df[col].mean():.2f}, Std={df[col].std():.2f}"
            
        else:
            # Categorical data - create table slide
            table_slide_layout = prs.slide_layouts[5]  # Blank layout
            slide = prs.slides.add_slide(table_slide_layout)
            title = slide.shapes.title
            title.text = f"Analysis of {col}"
            
            # Add table
            value_counts = df[col].value_counts()
            rows = min(8, len(value_counts)) + 1
            cols = 2
            
            left = Inches(1)
            top = Inches(1.5)
            width = Inches(8)
            height = Inches(0.8 * rows)
            
            table = slide.shapes.add_table(rows, cols, left, top, width, height).table
            
            # Set column headers
            table.cell(0, 0).text = "Value"
            table.cell(0, 1).text = "Count"
            
            # Fill table with data
            for i, (val, count) in enumerate(value_counts.items()[:rows-1]):
                table.cell(i+1, 0).text = str(val)
                table.cell(i+1, 1).text = str(count)
    
    # Add conclusion slide
    conclusion_slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(conclusion_slide_layout)
    title = slide.shapes.title
    title.text = "Conclusion"
    
    content = slide.placeholders[1]
    tf = content.text_frame
    tf.text = "Key insights from the data analysis:"
    
    # Add key insights
    insights = [
        "Data quality appears good with minimal missing values",
        "Several interesting patterns and correlations identified",
        "Recommend further analysis on specific metrics"
    ]
    
    for insight in insights:
        p = tf.add_paragraph()
        p.text = insight
        p.level = 1