
import pandas as pd
import numpy as np
from sklearn.feature_selection import mutual_info_classif, mutual_info_regression

def suggest_best_columns(df, max_columns=6):
    """Suggest the most relevant columns based on statistical analysis"""
    suggestions = []
    
    # Analyze each column
    for col in df.columns:
        col_data = df[col]
        
        # Skip if too many missing values
        if col_data.isnull().mean() > 0.5:
            continue
            
        # Calculate metrics based on data type
        if col_data.dtype in ['object', 'category', 'bool']:
            # Categorical data - use uniqueness and distribution
            uniqueness = col_data.nunique() / len(col_data)
            if 0.05 <= uniqueness <= 0.95:  # Avoid IDs and constants
                suggestions.append({
                    'column': col,
                    'score': min(uniqueness, 1 - uniqueness) * 10,
                    'type': 'categorical'
                })
        else:
            # Numerical data - use variance and distribution
            if col_data.std() > 0:  # Avoid constants
                cv = col_data.std() / col_data.mean() if col_data.mean() != 0 else col_data.std()
                suggestions.append({
                    'column': col,
                    'score': min(cv * 10, 10),
                    'type': 'numerical'
                })
    
    # Sort by score and return top columns
    suggestions.sort(key=lambda x: x['score'], reverse=True)
    return [s['column'] for s in suggestions[:max_columns]]

def suggest_charts(df):
    """Suggest appropriate chart types based on data"""
    suggestions = []
    
    # Get column types
    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.select_dtypes(exclude=[np.number]).columns.tolist()
    
    # Suggest charts based on data composition
    if len(numerical_cols) >= 1 and len(categorical_cols) >= 1:
        # Bar charts for categorical vs numerical
        for cat_col in categorical_cols[:2]:
            for num_col in numerical_cols[:3]:
                suggestions.append({
                    'type': 'bar',
                    'x_column': cat_col,
                    'y_columns': [num_col],
                    'plotly_type': 'bar'
                })
    
    if len(numerical_cols) >= 2:
        # Scatter plots for numerical correlations
        for i in range(min(2, len(numerical_cols))):
            for j in range(i+1, min(4, len(numerical_cols))):
                suggestions.append({
                    'type': 'scatter',
                    'x_column': numerical_cols[i],
                    'y_columns': [numerical_cols[j]],
                    'plotly_type': 'scatter'
                })
    
    if len(numerical_cols) >= 1 and df.shape[0] > 5:
        # Line charts for trends (if data has natural order)
        suggestions.append({
            'type': 'line',
            'x_column': df.index.name if df.index.name else 'index',
            'y_columns': numerical_cols[:2],
            'plotly_type': 'line'
        })
    
    return suggestions[:5]  # Return top 5 suggestions

def suggest_slide_count(df):
    """Suggest number of slides based on data size"""
    rows, cols = df.shape
    if rows <= 10 and cols <= 5:
        return 3
    elif rows <= 20 and cols <= 8:
        return 5
    else:
        return min(8, cols + 1)  # One slide per column plus summary