from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
import pandas as pd
import numpy as np
import tempfile
import uuid
from io import BytesIO
import json

app = FastAPI(title="Excel to PPT Generator API")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Temporary storage for user sessions
user_sessions = {}

# Root endpoint - FIX FOR THE 404 ERROR
@app.get("/")
def read_root():
    return {"message": "Excel to PPT Generator API is running!", "status": "success"}

@app.get("/api/test")
def test_endpoint():
    return {"status": "success", "message": "API test endpoint is working!"}

@app.post("/api/upload/")
async def upload_files(excel_file: UploadFile = File(...)):
    try:
        # Generate session ID
        session_id = str(uuid.uuid4())
        user_sessions[session_id] = {}
        
        # Read Excel file
        excel_content = await excel_file.read()
        df = pd.read_excel(BytesIO(excel_content))
        
        # Store data in session
        user_sessions[session_id]['data'] = df.to_dict(orient='records')
        user_sessions[session_id]['columns'] = list(df.columns)
        user_sessions[session_id]['dtypes'] = df.dtypes.astype(str).to_dict()
        
        return JSONResponse({
            "session_id": session_id,
            "columns": list(df.columns),
            "dtypes": df.dtypes.astype(str).to_dict(),
            "preview_data": df.head(5).to_dict(orient='records'),
            "status": "success"
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/analyze-columns/{session_id}")
async def analyze_columns(session_id: str):
    try:
        if session_id not in user_sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        df = pd.DataFrame(user_sessions[session_id]['data'])
        
        # Simple analysis - just return first 4 columns
        selected_columns = df.columns.tolist()[:4]
        
        # Simple chart suggestions
        chart_suggestions = [
            {
                'type': 'bar',
                'x_column': selected_columns[0] if len(selected_columns) > 0 else df.columns[0],
                'y_columns': [selected_columns[1]] if len(selected_columns) > 1 else [df.columns[1]],
                'plotly_type': 'bar'
            }
        ]
        
        return JSONResponse({
            "selected_columns": selected_columns,
            "chart_suggestions": chart_suggestions,
            "slide_count_suggestion": 4,
            "status": "success"
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Health check endpoint
@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "excel-to-ppt-api"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)