# Excel to PowerPoint Generator

A web application that converts Excel data into PowerPoint presentations with beautiful charts and visualizations.

## Features

- Upload Excel files and optional PowerPoint templates
- Automatic data analysis and column suggestions
- Interactive chart preview and customization
- Multiple output formats (charts only, content only, dashboard)
- Real-time preview of presentations
- AI-powered chat assistant for guidance
- Responsive design with smooth animations

## Technology Stack

### Frontend
- React with Material-UI
- Framer Motion for animations
- Plotly.js for interactive charts
- Axios for API calls

### Backend
- FastAPI (Python)
- pandas for data analysis
- python-pptx for PowerPoint generation
- scikit-learn for data suggestions

## Installation

### Backend Setup
1. Navigate to the backend directory:
   ```bash
   cd backend