import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor to handle errors
api.interceptors.request.use(
  (config) => {
    console.log('Making request to:', config.url);
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle errors
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    console.error('API Error:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

export const uploadFiles = (formData) => {
  return api.post('/api/upload/', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
};

export const analyzeColumns = (sessionId, selectedColumns) => {
  return api.post(`/api/analyze-columns/${sessionId}`, {
    selected_columns: selectedColumns,
  });
};

export const generatePreview = (sessionId, config) => {
  return api.post(`/api/generate-preview/${sessionId}`, config);
};

export const generatePPT = (sessionId, config) => {
  return api.post(`/api/generate-ppt/${sessionId}`, config, {
    responseType: 'blob',
  });
};

export default api;