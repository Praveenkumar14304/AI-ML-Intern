import React, { useState } from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Container from '@mui/material/Container';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import { motion, AnimatePresence } from 'framer-motion';

// Import components
import UploadSection from './components/UploadSection';
import DataCustomization from './components/DataCustomization';
import PreviewSection from './components/PreviewSection';
import ChatAssistant from './components/ChatAssistant';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#2196f3',
    },
    secondary: {
      main: '#f50057',
    },
  },
});

const steps = ['Upload Files', 'Customize Data', 'Preview & Generate'];

function App() {
  const [activeStep, setActiveStep] = useState(0);
  const [sessionId, setSessionId] = useState(null);
  const [fileData, setFileData] = useState(null);
  const [config, setConfig] = useState({});

  const handleNext = () => {
    setActiveStep((prevStep) => prevStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleUploadComplete = (data) => {
    setSessionId(data.session_id);
    setFileData(data);
    handleNext();
  };

  const handleConfigUpdate = (newConfig) => {
    setConfig({ ...config, ...newConfig });
  };

  const getStepContent = (step) => {
    switch (step) {
      case 0:
        return <UploadSection onComplete={handleUploadComplete} />;
      case 1:
        return (
          <DataCustomization
            sessionId={sessionId}
            fileData={fileData}
            onConfigUpdate={handleConfigUpdate}
            onNext={handleNext}
            onBack={handleBack}
          />
        );
      case 2:
        return (
          <PreviewSection
            sessionId={sessionId}
            config={config}
            onBack={handleBack}
          />
        );
      default:
        return 'Unknown step';
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <div className="App">
        <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
          <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
          
          <AnimatePresence mode="wait">
            <motion.div
              key={activeStep}
              initial={{ opacity: 0, x: activeStep > 0 ? 50 : -50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: activeStep > 0 ? -50 : 50 }}
              transition={{ duration: 0.3 }}
            >
              {getStepContent(activeStep)}
            </motion.div>
          </AnimatePresence>
        </Container>
        
        <ChatAssistant />
      </div>
    </ThemeProvider>
  );
}

export default App;