import React from 'react';
import {
  Box,
  Paper,
  Typography,
  Button,
  Grid
} from '@mui/material';
import { motion } from 'framer-motion';

const PreviewSection = ({ sessionId, config, onBack }) => {
  const handleGeneratePPT = async () => {
    alert('PPT generation would happen here! This is the final step.');
    // In the full version, this would call the backend to generate the PowerPoint
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Preview & Generate
      </Typography>
      
      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Configuration Summary
            </Typography>
            <Typography variant="body2" gutterBottom>
              <strong>Selected Columns:</strong> {config.selectedColumns?.join(', ')}
            </Typography>
            <Typography variant="body2" gutterBottom>
              <strong>Output Type:</strong> {config.outputType}
            </Typography>
            <Typography variant="body2" gutterBottom>
              <strong>Charts:</strong> {config.charts?.length || 0}
            </Typography>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h6" gutterBottom>
              Ready to Generate!
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              Click the button below to generate your PowerPoint presentation.
            </Typography>
            
            <Button
              variant="contained"
              size="large"
              onClick={handleGeneratePPT}
              component={motion.button}
              whileHover={{ scale: 1.05 }}
            >
              Generate PowerPoint
            </Button>
          </Paper>
          
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
            <Button onClick={onBack} variant="outlined">
              Back to Customization
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default PreviewSection;