import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Switch,
  FormControlLabel,
  Card,
  CardContent
} from '@mui/material';
import { motion } from 'framer-motion';

const DataCustomization = ({ sessionId, fileData, onConfigUpdate, onNext, onBack }) => {
  const [selectedColumns, setSelectedColumns] = useState([]);
  const [outputType, setOutputType] = useState('charts_content');
  const [analysisResult, setAnalysisResult] = useState(null);

  useEffect(() => {
    if (fileData && fileData.columns) {
      // Auto-select all columns initially
      setSelectedColumns(fileData.columns);
      analyzeColumns();
    }
  }, [fileData]);

  const analyzeColumns = async () => {
    try {
      const response = await fetch(`http://localhost:8000/api/analyze-columns/${sessionId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        setAnalysisResult(data);
        onConfigUpdate({
          selectedColumns: data.selected_columns,
          outputType: 'charts_content',
          charts: data.chart_suggestions
        });
      }
    } catch (error) {
      console.error('Analysis error:', error);
    }
  };

  const handleColumnToggle = (column) => {
    if (selectedColumns.includes(column)) {
      setSelectedColumns(selectedColumns.filter(col => col !== column));
    } else {
      setSelectedColumns([...selectedColumns, column]);
    }
  };

  const handleNextStep = () => {
    onConfigUpdate({
      selectedColumns,
      outputType,
      charts: analysisResult?.chart_suggestions || []
    });
    onNext();
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Customize Your Presentation
      </Typography>
      
      <Grid container spacing={4}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Data Columns ({selectedColumns.length} selected)
            </Typography>
            
            <Box sx={{ my: 2, maxHeight: '300px', overflow: 'auto' }}>
              {fileData && fileData.columns.map((column) => (
                <Chip
                  key={column}
                  label={column}
                  onClick={() => handleColumnToggle(column)}
                  color={selectedColumns.includes(column) ? 'primary' : 'default'}
                  variant={selectedColumns.includes(column) ? 'filled' : 'outlined'}
                  sx={{ m: 0.5 }}
                  component={motion.div}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                />
              ))}
            </Box>
          </Paper>
          
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Presentation Type
            </Typography>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel>Output Type</InputLabel>
              <Select
                value={outputType}
                label="Output Type"
                onChange={(e) => setOutputType(e.target.value)}
              >
                <MenuItem value="charts_only">Charts Only</MenuItem>
                <MenuItem value="charts_content">Charts + Content</MenuItem>
                <MenuItem value="content_only">Content Only</MenuItem>
                <MenuItem value="dashboard">Dashboard</MenuItem>
              </Select>
            </FormControl>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Data Preview
            </Typography>
            
            <Box sx={{ maxHeight: '400px', overflow: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
                <thead>
                  <tr style={{ backgroundColor: '#f5f5f5' }}>
                    {selectedColumns.map(column => (
                      <th key={column} style={{ padding: '8px', border: '1px solid #ddd', textAlign: 'left' }}>
                        {column}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {fileData && fileData.preview_data.slice(0, 5).map((row, i) => (
                    <tr key={i}>
                      {selectedColumns.map(column => (
                        <td key={column} style={{ padding: '8px', border: '1px solid #eee' }}>
                          {row[column]}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </Box>
          </Paper>
          
          {analysisResult && (
            <Paper sx={{ p: 3, mb: 3 }}>
              <Typography variant="h6" gutterBottom>
                Analysis Results
              </Typography>
              <Typography>
                Suggested slides: {analysisResult.slide_count_suggestion}
              </Typography>
              <Typography>
                Chart suggestions: {analysisResult.chart_suggestions.length}
              </Typography>
            </Paper>
          )}
          
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
            <Button onClick={onBack} variant="outlined">
              Back
            </Button>
            <Button 
              onClick={handleNextStep} 
              variant="contained"
              disabled={selectedColumns.length === 0}
            >
              Continue to Preview
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default DataCustomization;