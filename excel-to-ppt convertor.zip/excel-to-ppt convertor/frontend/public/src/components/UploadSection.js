import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Button,
  Grid,
  Card,
  CardMedia,
  CardActions,
  Fade,
  TextField
} from '@mui/material';
import { motion } from 'framer-motion';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import DescriptionIcon from '@mui/icons-material/Description';
import ImageIcon from '@mui/icons-material/Image';

const UploadSection = ({ onComplete }) => {
  const [excelFile, setExcelFile] = useState(null);
  const [title, setTitle] = useState('My Presentation');
  const [isLoading, setIsLoading] = useState(false);

  const handleFileChange = (event) => {
    setExcelFile(event.target.files[0]);
  };

  const handleSubmit = async () => {
    if (!excelFile) {
      alert('Please select an Excel file first');
      return;
    }

    setIsLoading(true);
    const formData = new FormData();
    formData.append('excel_file', excelFile);

    try {
      const response = await fetch('http://localhost:8000/api/upload/', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        onComplete(data);
      } else {
        alert('Upload failed. Please try again.');
      }
    } catch (error) {
      alert('Error uploading file. Make sure backend is running.');
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const sampleTemplates = [
    { id: 1, name: 'Corporate Blue', image: '/templates/template1.jpg' },
    { id: 2, name: 'Modern Red', image: '/templates/template2.jpg' },
    { id: 3, name: 'Creative Green', image: '/templates/template3.jpg' },
    { id: 4, name: 'Minimalist Gray', image: '/templates/template4.jpg' },
  ];

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Upload Your Excel File
      </Typography>
      
      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, mb: 3, textAlign: 'center' }}>
            <CloudUploadIcon sx={{ fontSize: 48, color: 'primary.main', mb: 2 }} />
            <Typography variant="h6" gutterBottom>
              Upload Excel File
            </Typography>
            
            <Button
              variant="contained"
              component="label"
              sx={{ mb: 2 }}
            >
              Choose File
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileChange}
                hidden
              />
            </Button>
            
            {excelFile && (
              <Fade in={true}>
                <Paper sx={{ p: 1, bgcolor: 'success.light' }}>
                  <DescriptionIcon sx={{ mr: 1 }} />
                  {excelFile.name}
                </Paper>
              </Fade>
            )}
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Presentation Title
            </Typography>
            <TextField
              fullWidth
              label="Presentation Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              sx={{ mb: 3 }}
            />
          </Paper>
          
          <Button
            variant="contained"
            size="large"
            fullWidth
            onClick={handleSubmit}
            disabled={!excelFile || isLoading}
            component={motion.button}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {isLoading ? 'Processing...' : 'Process Data & Continue'}
          </Button>
        </Grid>
      </Grid>
    </Box>
  );
};

export default UploadSection;